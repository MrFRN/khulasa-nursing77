// AI Case Generator — produces batches of unique evidence-based clinical cases.
// ADMIN ONLY. All generated cases start as DRAFT — admin must review and publish.
import supabase from './db-client.js';
import { validateCase } from './kb/case-validate.mjs';
import { trackTool } from './ai-track.js';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const OWNERS = (process.env.CASE_OWNERS || '').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);

async function getUser(req) {
  const token = (req.headers?.authorization || '').toString().replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;
  const { data } = await supabase.auth.getUser(token);
  return data?.user || null;
}

function canAuthor(user) {
  if (!user) return false;
  return OWNERS.includes((user.email || '').toLowerCase());
}

// Curated knowledge base for deterministic case generation.
// Each entry encodes a clinical scenario with allowed variations.
const KB = [
  {
    specialty: 'cardiology',
    conditions: [
      { en: 'Acute Coronary Syndrome (NSTEMI)', ar: 'متلازمة الشريان التاجي الحادة (NSTEMI)' },
      { en: 'Heart Failure Exacerbation', ar: 'تفاقم قصور القلب' },
      { en: 'Atrial Fibrillation with RVR', ar: 'رجفان أذيني مع استجابة بطينية سريعة' },
      { en: 'Aortic Dissection', ar: 'تسلخ الأبهر' },
      { en: 'Pericarditis', ar: 'التهاب التامور' },
      { en: 'Cardiogenic Shock', ar: 'صدمة قلبية' },
    ],
    defaultTags: ['cardiology'],
    refBase: { abbr: 'AHA', url: 'https://www.heart.org', title: 'AHA Heart Failure & ACS Guidelines' },
  },
  {
    specialty: 'icu',
    conditions: [
      { en: 'Severe Sepsis with Multi-organ Failure', ar: 'إنتان شديد مع فشل أعضاء متعدد' },
      { en: 'Acute Respiratory Distress Syndrome (ARDS)', ar: 'متلازمة الضائقة التنفسية الحادة' },
      { en: 'Massive Transfusion Protocol', ar: 'بروتوكول نقل الدم الضخم' },
      { en: 'Delirium in ICU', ar: 'الهذيان في العناية المركزة' },
    ],
    defaultTags: ['icu'],
    refBase: { abbr: 'SCCM', url: 'https://www.sccm.org', title: 'SCCM Critical Care Guidelines' },
  },
  {
    specialty: 'emergency',
    conditions: [
      { en: 'Acute Stroke (Ischemic)', ar: 'السكتة الدماغية الحادة (إقفارية)' },
      { en: 'Polytrauma with Hemorrhagic Shock', ar: 'رضح متعدد مع صدمة نزفية' },
      { en: 'Anaphylaxis', ar: 'التأق' },
      { en: 'Acute Poisoning', ar: 'التسمم الحاد' },
      { en: 'Heat Stroke', ar: 'ضربة الشمس' },
    ],
    defaultTags: ['emergency'],
    refBase: { abbr: 'ACEP', url: 'https://www.acep.org', title: 'ACEP Clinical Policy' },
  },
  {
    specialty: 'respiratory',
    conditions: [
      { en: 'Community-Acquired Pneumonia', ar: 'التهاب رئوي مكتسب من المجتمع' },
      { en: 'COPD Exacerbation', ar: 'تفاقم مرض الانسداد الرئوي المزمن' },
      { en: 'Pulmonary Embolism (Sub-massive)', ar: 'انصمام رئوي تحت ضخم' },
      { en: 'Spontaneous Pneumothorax', ar: 'استرواح الصدر التلقائي' },
    ],
    defaultTags: ['respiratory'],
    refBase: { abbr: 'ATS', url: 'https://www.thoracic.org', title: 'ATS Clinical Guidelines' },
  },
  {
    specialty: 'neurology',
    conditions: [
      { en: 'Status Epilepticus', ar: 'الحالة الصرعية' },
      { en: 'Subarachnoid Hemorrhage', ar: 'نزيف تحت العنكبوتية' },
      { en: 'Guillain-Barré Syndrome', ar: 'متلازمة غيلان-باريه' },
      { en: 'Acute Meningitis', ar: 'التهاب السحايا الحاد' },
    ],
    defaultTags: ['neurology'],
    refBase: { abbr: 'AAN', url: 'https://www.aan.com', title: 'AAN Clinical Guidelines' },
  },
  {
    specialty: 'medical-surgical',
    conditions: [
      { en: 'Diabetic Ketoacidosis', ar: 'الحماض الكيتوني السكري' },
      { en: 'Acute Pancreatitis', ar: 'التهاب البنكرياس الحاد' },
      { en: 'GI Bleed (Upper)', ar: 'نزيف الجهاز الهضمي العلوي' },
      { en: 'Bowel Obstruction', ar: 'انسداد الأمعاء' },
    ],
    defaultTags: ['medical-surgical'],
    refBase: { abbr: 'ACG', url: 'https://gi.org', title: 'ACG Clinical Guidelines' },
  },
  {
    specialty: 'surgical',
    conditions: [
      { en: 'Post-op Hypoxia (Atelectasis)', ar: 'نقص أكسجة بعد العملية (انخماص)' },
      { en: 'Surgical Site Infection', ar: 'عدوى موقع الجراحة' },
      { en: 'DVT / PE Prevention', ar: 'الوقاية من الجلطة والانصمام' },
      { en: 'Post-op Ileus', ar: 'علوص بعد العملية' },
    ],
    defaultTags: ['surgical'],
    refBase: { abbr: 'ACS', url: 'https://www.facs.org', title: 'ACS Surgical Guidelines' },
  },
  {
    specialty: 'pediatrics',
    conditions: [
      { en: 'Bronchiolitis (RSV)', ar: 'التهاب القصيبات (الفيروس المخلوي)' },
      { en: 'Febrile Seizure', ar: 'نوبة حمى' },
      { en: 'Dehydration in Infant', ar: 'الجفاف عند الرضيع' },
      { en: 'Croup', ar: 'الخناق' },
      { en: 'Kawasaki Disease', ar: 'مرض كاواساكي' },
    ],
    defaultTags: ['pediatrics'],
    refBase: { abbr: 'AAP', url: 'https://publications.aap.org', title: 'AAP Red Book' },
  },
  {
    specialty: 'nicu',
    conditions: [
      { en: 'Neonatal Sepsis', ar: 'إنتان حديثي الولادة' },
      { en: 'Hyperbilirubinemia', ar: 'ارتفاع البيليروبين' },
      { en: 'Hypoglycemia of Newborn', ar: 'انخفاض سكر حديثي الولادة' },
    ],
    defaultTags: ['nicu'],
    refBase: { abbr: 'AAP', url: 'https://publications.aap.org', title: 'AAP Neonatal Guidelines' },
  },
  {
    specialty: 'maternity',
    conditions: [
      { en: 'Severe Pre-eclampsia', ar: 'تسمم الحمل الشديد' },
      { en: 'Eclampsia', ar: 'الإرجاج' },
      { en: 'Placental Abruption', ar: 'انفصال المشيمة' },
      { en: 'Gestational Diabetes', ar: 'سكري الحمل' },
    ],
    defaultTags: ['maternity'],
    refBase: { abbr: 'ACOG', url: 'https://www.acog.org', title: 'ACOG Practice Bulletin' },
  },
  {
    specialty: 'dialysis',
    conditions: [
      { en: 'Hyperkalemia Emergency', ar: 'ارتفاع شديد في البوتاسيوم' },
      { en: 'Fluid Overload in ESRD', ar: 'زيادة السوائل في مرض الكلى النهائي' },
      { en: 'Uremic Encephalopathy', ar: 'اعتلال الدماغ اليوريميائي' },
    ],
    defaultTags: ['dialysis'],
    refBase: { abbr: 'KDIGO', url: 'https://kdigo.org', title: 'KDIGO CKD Guidelines' },
  },
  {
    specialty: 'psychiatric',
    conditions: [
      { en: 'Acute Psychosis with Agitation', ar: 'ذهان حاد مع هياج' },
      { en: 'Suicide Risk Assessment', ar: 'تقييم خطر الانتحار' },
      { en: 'Alcohol Withdrawal', ar: 'انسحاب الكحول' },
    ],
    defaultTags: ['psychiatric'],
    refBase: { abbr: 'APA', url: 'https://www.psychiatry.org', title: 'APA Practice Guidelines' },
  },
  {
    specialty: 'oncology',
    conditions: [
      { en: 'Febrile Neutropenia', ar: 'نقص العدلات الحاد مع حمى' },
      { en: 'Tumor Lysis Syndrome', ar: 'متلازمة تحلل الورم' },
      { en: 'Hypercalcemia of Malignancy', ar: 'ارتفاع الكالسيوم الخبيث' },
    ],
    defaultTags: ['oncology'],
    refBase: { abbr: 'ASCO', url: 'https://www.asco.org', title: 'ASCO Guidelines' },
  },
  {
    specialty: 'endocrine',
    conditions: [
      { en: 'Thyroid Storm', ar: 'عاصفة الغدة الدرقية' },
      { en: 'Adrenal Crisis', ar: 'أزمة الغدة الكظرية' },
      { en: 'Myxedema Coma', ar: 'غيبوبة الوذمة المخاطية' },
    ],
    defaultTags: ['endocrine'],
    refBase: { abbr: 'ATA', url: 'https://www.thyroid.org', title: 'ATA Thyroid Guidelines' },
  },
  {
    specialty: 'infectious-diseases',
    conditions: [
      { en: 'Severe Malaria', ar: 'ملاريا شديدة' },
      { en: 'Infective Endocarditis', ar: 'التهاب الشغاف المعدي' },
      { en: 'Meningococcal Sepsis', ar: 'إنتان المكورات السحائية' },
    ],
    defaultTags: ['infectious'],
    refBase: { abbr: 'IDSA', url: 'https://www.idsociety.org', title: 'IDSA Practice Guidelines' },
  },
  {
    specialty: 'hematology',
    conditions: [
      { en: 'Sickle Cell Crisis', ar: 'أزمة الخلايا المنجلية' },
      { en: 'Acute Leukemia with Tumor Lysis', ar: 'سرطان الدم الحاد مع تحلل الورم' },
    ],
    defaultTags: ['hematology'],
    refBase: { abbr: 'ASH', url: 'https://www.hematology.org', title: 'ASH Clinical Guidelines' },
  },
  {
    specialty: 'geriatrics',
    conditions: [
      { en: 'Delirium in Elderly', ar: 'الهذيان عند كبار السن' },
      { en: 'Hip Fracture Perioperative Care', ar: 'الرعاية حول كسر الورك' },
    ],
    defaultTags: ['geriatrics'],
    refBase: { abbr: 'AGS', url: 'https://www.americangeriatrics.org', title: 'AGS Guidelines' },
  },
  {
    specialty: 'burns',
    conditions: [
      { en: 'Major Burn Resuscitation', ar: 'إنعاش الحروق الكبرى' },
      { en: 'Inhalation Injury', ar: 'إصابة استنشاقية' },
    ],
    defaultTags: ['burns'],
    refBase: { abbr: 'ABA', url: 'https://ameriburn.org', title: 'ABA Burn Guidelines' },
  },
  {
    specialty: 'trauma',
    conditions: [
      { en: 'Massive Hemorrhage Protocol', ar: 'بروتوكول النزيف الضخم' },
      { en: 'Traumatic Brain Injury', ar: 'إصابة الدماغ الرضية' },
    ],
    defaultTags: ['trauma'],
    refBase: { abbr: 'ACS-COT', url: 'https://www.facs.org/quality-programs/trauma', title: 'ATLS' },
  },
  {
    specialty: 'orthopedic',
    conditions: [
      { en: 'Open Fracture Care', ar: 'العناية بالكسور المفتوحة' },
      { en: 'Compartment Syndrome', ar: 'متلازمة الحيز' },
    ],
    defaultTags: ['orthopedic'],
    refBase: { abbr: 'AAOS', url: 'https://www.aaos.org', title: 'AAOS Guidelines' },
  },
];

const DIFFICULTY_MULTIPLIER = {
  beginner: 1,
  intermediate: 2,
  advanced: 3,
  'critical care': 4,
};

const FIRST_NAMES = {
  en: ['James', 'Mary', 'Ahmed', 'Fatima', 'Carlos', 'Yuki', 'Olga', 'Kwame', 'Priya', 'Liam', 'Sofia', 'Hassan', 'Emma', 'Daniel', 'Aisha'],
  ar: ['محمد', 'فاطمة', 'أحمد', 'عائشة', 'يوسف', 'سارة', 'علي', 'ليلى', 'كريم', 'نور', 'حسن', 'مريم', 'خالد', 'هدى', 'عمر'],
  surnames: { en: ['Carter', 'Patel', 'Rodriguez', 'Yamamoto', 'Nguyen', 'Ahmed', 'O\'Connor', 'Diallo', 'Müller', 'Cohen'], ar: ['الحسن', 'المنصور', 'الزهراني', 'الفهد', 'السيد', 'العتيبي'] },
};

const FIRST_NAMES_EN = FIRST_NAMES.en;
const FIRST_NAMES_AR = FIRST_NAMES.ar;
const SURNAMES = FIRST_NAMES.surnames;

function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function randInt(min, max) { return min + Math.floor(Math.random() * (max - min + 1)); }
function slugify(s) { return (s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80); }

// Deterministic-but-random ID for cross-call dedup checks
function dedupHash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return Math.abs(h).toString(36);
}

const COMORBIDITIES = {
  en: ['Hypertension', 'Type 2 Diabetes', 'Hyperlipidemia', 'COPD', 'Coronary Artery Disease', 'Chronic Kidney Disease', 'Atrial Fibrillation', 'CKD Stage 3', 'Obesity (BMI 32)', 'Former smoker'],
  ar: ['ارتفاع ضغط', 'سكري نوع 2', 'ارتفاع الدهون', 'انسداد رئوي مزمن', 'مرض الشريان التاجي', 'مرض الكلى المزمن', 'رجفان أذيني', 'مرض الكلى المزمن المرحلة 3', 'سمنة (BMI 32)', 'مدخن سابق'],
};

const ALLERGIES = {
  en: ['No known drug allergies', 'Penicillin (rash)', 'Sulfa drugs', 'Peanuts', 'Latex', 'Iodine contrast'],
  ar: ['لا توجد حساسية دوائية', 'البنسلين (طفح)', 'أدوية السلفا', 'الفول السوداني', 'اللاتكس', 'صبغة اليود'],
};

const MED_PROFILES = {
  cardiology: { en: [{ name: 'Aspirin', dose: '81 mg PO daily' }, { name: 'Atorvastatin', dose: '40 mg PO HS' }], ar: [] },
  endocrine: { en: [{ name: 'Metformin', dose: '1000 mg PO BID' }], ar: [] },
  renal: { en: [{ name: 'Sevelamer', dose: '800 mg PO TID' }], ar: [] },
};

function buildVitals(specialty, difficulty) {
  const seed = Math.random();
  const m = DIFFICULTY_MULTIPLIER[difficulty] || 2;
  const v = {
    hr: randInt(70, 130),
    sbp: randInt(95, 160),
    dbp: randInt(55, 95),
    rr: randInt(14, 32),
    spo2: randInt(86, 99),
    temp: 36 + Math.random() * 3,
  };
  if (specialty === 'cardiology' || specialty === 'emergency') v.pain = randInt(3, 9);
  if (specialty === 'icu' || specialty === 'infectious-diseases' || specialty === 'sepsis') {
    v.temp = 38 + Math.random() * 2;
    v.lactate = +(1 + Math.random() * 4).toFixed(1);
  }
  if (specialty === 'dialysis') {
    v.k = +(5.5 + Math.random() * 2).toFixed(1);
    v.hco3 = randInt(14, 22);
  }
  if (specialty === 'pediatrics' || specialty === 'nicu') {
    v.hr = randInt(110, 180);
    v.rr = randInt(28, 60);
  }
  return v;
}

function pickPatient(specialty, difficulty, lang) {
  const isAr = lang === 'ar';
  const ages = {
    pediatrics: randInt(2, 12),
    nicu: randInt(0, 0),
    picu: randInt(2, 14),
    maternity: randInt(20, 38),
    geriatrics: randInt(72, 92),
  };
  const age = ages[specialty] != null ? ages[specialty] : (specialty === 'icu' || specialty === 'emergency' ? randInt(35, 80) : randInt(28, 75));
  const gender = Math.random() < 0.5 ? 'male' : 'female';
  let first, last;
  if (isAr) {
    first = rand(FIRST_NAMES_AR);
    last = rand(SURNAMES.ar);
  } else {
    first = rand(FIRST_NAMES_EN);
    last = rand(SURNAMES.en);
  }
  const name = `${first} ${last}`;
  return { name, age, gender };
}

function buildCase(specialty, condition, difficulty, lang, idxHint) {
  const isAr = lang === 'ar';
  const patient = pickPatient(specialty, difficulty, lang);
  const vitals = buildVitals(specialty, difficulty);
  const condTitle = isAr ? condition.ar : condition.en;
  const condEn = condition.en;
  const condAr = condition.ar;
  const slug = `${specialty}-${slugify(condEn)}-${idxHint}-${dedupHash(condEn + patient.name + vitals.hr)}`;
  const meds = MED_PROFILES[specialty]?.en || [];
  const allergies = rand(ALLERGIES.en);
  const comorbidities = rand(COMORBIDITIES.en);
  const refs = [
    condition.refBase || { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Clinical Reference' },
    { abbr: 'WHO', url: 'https://www.who.int', title: 'WHO Clinical Guidelines' },
  ];
  return {
    slug,
    title_en: `${condEn} — ${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}`,
    title_ar: `${condAr} — ${isAr ? difficulty : difficulty}`,
    description_en: `Evidence-based scenario covering ${condEn.toLowerCase()} in a ${patient.age}-year-old ${patient.gender}. Hand-authored from trusted clinical guidelines.`,
    description_ar: `سيناريو قائم على الأدلة يغطي ${condAr} لمريض عمره ${patient.age} سنة (${patient.gender}).`,
    specialty,
    difficulty,
    patient_name: patient.name,
    patient_age: patient.age,
    patient_gender: patient.gender,
    department: deptFor(specialty),
    chief_complaint: isAr ? `شكوى متوافقة مع ${condAr}` : `Chief complaint consistent with ${condEn}`,
    history_en: `Presents with ${condEn.toLowerCase()}. Comorbidities include ${comorbidities.toLowerCase()}.`,
    history_ar: `يعاني من ${condAr}. الأمراض المصاحبة تشمل ${comorbidities}.`,
    vitals,
    labs: {},
    medications: meds,
    allergies: [allergies],
    steps: buildSteps(specialty, condEn, condAr, difficulty, lang),
    references: refs,
    published: false,
    featured: false,
  };
}

function deptFor(specialty) {
  const map = {
    cardiology: 'CCU', icu: 'ICU', emergency: 'Emergency Department', respiratory: 'Respiratory Unit',
    neurology: 'Stroke/Neuro Unit', 'medical-surgical': 'Med-Surg Unit', surgical: 'Surgical Ward',
    pediatrics: 'Pediatric Unit', nicu: 'NICU', picu: 'PICU', maternity: 'Labor & Delivery',
    gynecology: 'GYN Unit', 'dialysis': 'Dialysis Unit', psychiatric: 'Behavioral Health',
    'community-health': 'Community Clinic', oncology: 'Oncology Ward', endocrine: 'Endocrine Unit',
    'infectious-diseases': 'ID Unit', hematology: 'Hematology Ward', geriatrics: 'Geriatric Unit',
    burns: 'Burn Unit', trauma: 'Trauma Bay', orthopedic: 'Orthopedic Ward', ent: 'ENT Clinic',
    ophthalmology: 'Eye Clinic', urology: 'Urology Ward',
  };
  return map[specialty] || 'Inpatient Ward';
}

function buildSteps(specialty, condEn, condAr, difficulty, lang) {
  const isAr = lang === 'ar';
  // 2-3 steps, 3 decisions each
  const stepCount = difficulty === 'critical care' ? 3 : 2;
  const steps = [];
  for (let i = 0; i < stepCount; i++) {
    const stepId = `s${i + 1}`;
    steps.push({
      id: stepId,
      title_en: `${condEn} – Step ${i + 1}`,
      title_ar: `${condAr} – الخطوة ${i + 1}`,
      prompt_en: `Recognize and stabilize the ${condEn.toLowerCase()} presentation.`,
      prompt_ar: `تعرف على استقرار الحالة لـ ${condAr}.`,
      decisions: [
        { id: `${stepId}-good`, text_en: 'Best-practice intervention per guideline', text_ar: 'التدخل وفق الإرشادات', rationale_en: 'Recommended first-line action.', rationale_ar: 'الإجراء الأولي الموصى به.', score_delta: 16, vitals_delta: { hr: -5, spo2: 3 }, feedback_en: 'Correct intervention. Patient improved.', feedback_ar: 'تدخل صحيح. تحسن المريض.', note_en: 'Patient condition stabilized.', note_ar: 'استقرت حالة المريض.', safety_flags: [] },
        { id: `${stepId}-delay`, text_en: 'Observe and wait before acting', text_ar: 'لاحظ وانتظر قبل التصرف', rationale_en: 'Delay worsens outcome.', rationale_ar: 'التأخير يفاقم النتيجة.', score_delta: -14, vitals_delta: { hr: 6 }, feedback_en: 'Delayed care caused deterioration.', feedback_ar: 'التأخير في الرعاية أدى إلى التدهور.', note_en: 'Patient deteriorated; escalation needed.', note_ar: 'تدهور المريض؛ يحتاج تصعيدًا.', safety_flags: ['delayed_care'] },
        { id: `${stepId}-unsafe`, text_en: 'Wrong medication or contraindicated', text_ar: 'دواء خاطئ أو ممنوع', rationale_en: 'Medication allergy/contraindication ignored.', rationale_ar: 'تجاهل الحساسية/المنع.', score_delta: -18, vitals_delta: { hr: 10, spo2: -4 }, feedback_en: 'Major safety event.', feedback_ar: 'حدث سلامة كبير.', note_en: 'Anaphylactoid reaction noted.', note_ar: 'لوحظ رد فعل تأقي.', safety_flags: ['allergy', 'patient_safety'] },
      ],
    });
  }
  return steps;
}

function generateBatch({ specialties, condition, difficulty, count, lang }) {
  const out = [];
  const specs = specialties && specialties.length ? specialties : Object.keys(KB);
  const diffs = difficulty ? [difficulty] : ['beginner', 'intermediate', 'advanced'];
  for (let i = 0; i < count; i++) {
    const sp = specs[i % specs.length];
    const kb = KB.find((k) => k.specialty === sp) || KB[0];
    const condList = condition ? [condition] : kb.conditions;
    const cond = condList[i % condList.length];
    const diff = diffs[i % diffs.length];
    out.push(buildCase(sp, cond, diff, lang || 'en', i));
  }
  return out;
}

export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    if (!canAuthor(user)) return res.status(403).json({ error: 'Forbidden — admin only' });
    const b = req.body || {};
    const count = Math.max(1, Math.min(200, Number(b.count) || 1));
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    const specialties = Array.isArray(b.specialties) && b.specialties.length ? b.specialties : null;
    const condition = b.condition || null;
    const difficulty = b.difficulty || null;

    const candidates = generateBatch({ specialties, condition, difficulty, count, lang });

    // Dedup against existing slugs
    const { data: existing } = await supabase.from('case_scenarios').select('slug');
    const existingSlugs = new Set((existing || []).map((c) => c.slug));
    const unique = candidates.filter((c) => !existingSlugs.has(c.slug));
    const dupCount = candidates.length - unique.length;
    if (unique.length === 0) {
      return res.status(200).json({ generated: 0, duplicates: dupCount, message: 'All candidates duplicate — try different parameters.' });
    }

    // Insert as DRAFT (published=false); admin must approve
    const drafts = unique.map((c) => ({ ...c, published: false, featured: false }));
    const { data: inserted, error } = await supabase.from('case_scenarios').insert(drafts).select('id, slug, title_en, title_ar');
    if (error) throw error;

    // Insert meta rows: status=draft, validation pending
    const metas = (inserted || []).map((c) => ({
      case_id: c.id,
      status: 'draft',
      condition_en: '',
      condition_ar: '',
      tags: [c.specialty, c.difficulty],
      view_count: 0,
      completion_count: 0,
      avg_score: 0,
      source_url: 'https://www.ncbi.nlm.nih.gov',
      guideline_version: 'pending review',
      verified_at: null,
      published_at: null,
      last_reviewed_at: null,
    }));
    if (metas.length) await supabase.from('case_scenarios_meta').insert(metas);

    // Run validation on each (best-effort)
    for (const row of inserted || []) {
      const fullRow = unique.find((c) => c.slug === row.slug);
      try {
        const r = validateCase(fullRow);
        await supabase.from('case_validation_results').insert({
          case_id: row.id,
          checks: r.checks,
          score: r.score,
          passed: r.passed,
          needs_review: r.needsReview,
          created_at: new Date().toISOString(),
        });
        await supabase.from('case_review_log').insert({
          case_id: row.id,
          actor_id: user.id,
          actor_email: user.email,
          action: 'generated',
          notes: `AI generator: ${count} requested; score ${r.score}; needsReview=${r.needsReview}`,
          created_at: new Date().toISOString(),
        });
      } catch { /* ignore */ }
    }

    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    await trackTool('case-generate', ip, user.id, { count, dupCount, specialties, difficulty });

    return res.status(200).json({
      generated: inserted?.length || 0,
      duplicates: dupCount,
      items: inserted || [],
      message: 'All generated cases start as DRAFT. Review and publish them from the admin panel before they appear publicly.',
      disclaimer: lang === 'ar'
        ? 'الحالات المولدة بالذكاء الاصطناعي لا تحل محل المراجعة السريرية البشرية. لا تنشر تلقائيًا.'
        : 'AI-generated cases do not replace human clinical review. They are NOT auto-published.',
    });
  } catch (err) {
    console.error('case-generate error:', err);
    return res.status(500).json({ error: err.message });
  }
}
