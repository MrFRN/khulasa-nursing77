// AI Case Simulation — generates an interactive clinical vignette.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';
import { analyzeCase } from './kb/engine.mjs';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

function pickN(arr, n) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, n);
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const category = (b.category || '').toString().toLowerCase();
    // pick a KB condition based on system
    const sysMap = { cardiovascular: 'cardio', respiratory: 'resp', gi: 'gi', neuro: 'neuro', renal: 'renal', endo: 'endo', emergency: 'general', ob: 'ob', peds: 'peds', mental: 'psych', infectious: 'general' };
    const sys = sysMap[category] || 'general';
    const { data: conds } = await supabase.from('ai_dictionary').select('term,abbr,category,definition').limit(1);
    // Use the engine to find a good condition (we'll fake a relevant case)
    const report = analyzeCase({
      chiefComplaint: 'chest pain case',
      symptoms: [],
      vitals: {},
      age: 50, gender: 'male', lang,
    });
    const top = (report.differentials || [])[0] || { name: 'Pneumonia', name_en: 'Pneumonia' };
    const vignette = lang === 'ar'
      ? `مريض عمره ${50} سنة، ذكر، يشكو من ${top.name} مع ارتفاع حرارة، سعال، ضيق نفس خفيف. العلامات: حرارة 38.5، نبض 102، ضغط 130/80، تشبع 95%.`
      : `A 50-year-old man presents with ${top.name_en}. Symptoms include fever, productive cough, mild dyspnea. Vitals: T 38.5°C, HR 102, BP 130/80, SpO₂ 95%.`;
    const questions = lang === 'ar'
      ? [
          'ما هي الفحوصات الأولية المطلوبة؟',
          'ما هي الخطوة العلاجية التالية؟',
          'ما هي الأعلام الحمراء التي تستدعي دخول ICU؟',
        ]
      : [
          'What initial investigations are warranted?',
          'What is the next therapeutic step?',
          'What red flags would warrant ICU admission?',
        ];
    const reveal = {
      diagnosis: top.name,
      rationale: report.differentials[0]?.reasoning || '',
      initial_workup: report.sections.investigations || [],
      treatment: report.sections.treatment || {},
      redflags: report.sections.redFlags || [],
      references: report.sections.references || [],
    };
    await trackTool('case', ip, user?.id || null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'لأغراض تعليمية فقط.' : 'For educational purposes only.',
      lang,
      vignette,
      questions,
      reveal,
    });
  } catch (err) {
    console.error('ai-case error:', err);
    return res.status(500).json({ error: err.message });
  }
}
