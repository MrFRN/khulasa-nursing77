// Evidence-based Clinical Decision Support engine (educational use only).
import { CONDITIONS } from './conditions.mjs';
import { findSymptom } from './symptoms.mjs';

const VITAL_RANGES = {
  temp: [36, 37.8], hr: [60, 100], sbp: [90, 140], dbp: [60, 90], rr: [12, 20], spo2: [95, 100], glucose: [70, 140],
};

function scoreCondition(c, caseData) {
  const symSet = new Set(caseData.symptoms || []);
  const matchedSymptoms = c.symptoms.filter((s) => symSet.has(s));
  const matchedVitals = [];
  let score = 0;
  for (const s of matchedSymptoms) score += 2;
  if (c.vitals) {
    const vit = caseData.vitals || {};
    for (const k of Object.keys(c.vitals)) {
      const v = vit[k];
      if (v == null) continue;
      const [lo, hi] = c.vitals[k];
      if (v < lo || v > hi) { score += 1.5; matchedVitals.push(k); }
    }
  }
  const rf = caseData.riskFactors || [];
  const matchedRisk = (c.riskFactors || []).filter((r) => rf.includes(r));
  score += matchedRisk.length;
  if (c.ageBand) {
    const a = Number(caseData.age);
    if (a && a >= c.ageBand[0] && a <= c.ageBand[1]) { score += 1; matchedRisk.push('age'); }
  }
  if (c.pregnancyOnly && !caseData.pregnancy) score -= 5;
  const maxScore = c.symptoms.length * 2 + (c.vitals ? Object.keys(c.vitals).length * 1.5 : 0) + (c.riskFactors ? c.riskFactors.length : 0) + (c.ageBand ? 1 : 0);
  const confidence = Math.min(95, Math.round((score / Math.max(maxScore, 1)) * 100) + (matchedSymptoms.length ? 4 : 0));
  const lang = (caseData.lang || 'en');
  const ar = c.ar || {};
  const symNames = matchedSymptoms.map((id) => (lang === 'ar' ? (findSymptom(id)?.ar || id) : (findSymptom(id)?.en || id)));
  let reasoning = (lang === 'ar' && ar.reasoning) ? ar.reasoning : c.reasoning;
  reasoning += (symNames.length ? ` ${lang === 'ar' ? 'الأعراض المطابقة: ' : 'Matched symptoms: '}${symNames.join(lang === 'ar' ? '، ' : ', ')}.` : '');
  const name = (lang === 'ar' && ar.name) ? ar.name : c.name;
  const redFlags = (lang === 'ar' && ar.redFlags) ? ar.redFlags : c.redFlags;
  return { id: c.id, name, name_en: c.name_en, confidence, score, maxScore, matchedSymptoms, matchedRisk, matchedVitals, reasoning, redFlags };
}

export function carePlanTool(caseData) {
  const lang = (caseData && caseData.lang) || 'en';
  const r = analyzeCase(caseData);
  if (!r || r.error || !r.sections || !r.sections.nursing) {
    return { error: lang === 'ar' ? 'لا توجد خطة رعاية متاحة.' : 'No care plan available.', carePlan: null };
  }
  const n = r.sections.nursing;
  return {
    carePlan: {
      diagnosis: (r.differentials || [])[0]?.name || '',
      nanda: n.nanda || [],
      nic: n.nic || [],
      goals: n.goals || [],
      evaluation: n.evaluation || [],
      interventions: n.assessment || [],
      education: n.education || [],
      discharge: n.discharge || [],
    },
  };
}

export function analyzeCase(caseData, relatedPdfs = []) {
  const lang = (caseData && caseData.lang) || 'en';
  if (!caseData || !Array.isArray(caseData.symptoms) || caseData.symptoms.length === 0) {
    return { error: lang === 'ar' ? 'أدخل الأعراض على الأقل لتحليل الحالة.' : 'Enter at least the symptoms to analyze the case.', differentials: [], sections: { investigations: [], treatment: {}, nursing: {}, drugs: [], redFlags: [], references: [] }, relatedPdfs: [] };
  }
  const scored = CONDITIONS.map((c) => scoreCondition(c, caseData))
    .sort((a, b) => b.score - a.score || b.confidence - a.confidence)
    .slice(0, 8);
  const top = scored[0] ? CONDITIONS.find((c) => c.id === scored[0].id) : null;
  if (!top) {
    return { error: lang === 'ar' ? 'لا توجد تطابقات كافية.' : 'No sufficient matches found.', differentials: [], sections: { investigations: [], treatment: {}, nursing: {}, drugs: [], redFlags: [], references: [] }, relatedPdfs: [] };
  }
  const ar = top.ar || {};

  // Build NANDA diagnoses in "related to ... as evidenced by ..." form from the
  // TOP condition's own risk factors and the patient's matched symptoms.
  const riskLabels = (top.riskFactors || []).map((r) => {
    if (r === 'age>50' || r === 'age>65') return lang === 'ar' ? 'كبر السن' : 'older adult';
    if (r === 'age<5') return lang === 'ar' ? 'الأطفال' : 'young child';
    return r.replace(/_/g, ' ');
  });
  const evid = scored[0].matchedSymptoms.map((id) => (lang === 'ar' ? (findSymptom(id)?.ar || id) : (findSymptom(id)?.en || id)));
  const nandaFull = (top.nursing?.nanda || []).map((d) => {
    const rel = riskLabels.length ? (lang === 'ar' ? `مرتبط بـ ${riskLabels.join('، ')}` : `related to ${riskLabels.join(', ')}`) : '';
    const ev = evid.length ? (lang === 'ar' ? `مُدعوم بـ ${evid.join('، ')}` : `as evidenced by ${evid.join(', ')}`) : '';
    return [d, rel, ev].filter(Boolean).join(lang === 'ar' ? ' ' : ' ');
  });

  const nursingOut = {
    assessment: top.nursing?.assessment || [],
    nanda: nandaFull,
    nic: top.nursing?.nic || [],
    goals: (top.nursing?.goals || []).map((g) => (lang === 'ar' ? g : `The patient will ${g.charAt(0).toLowerCase()}${g.slice(1)}`)),
    education: top.nursing?.education || [],
    discharge: top.nursing?.discharge || [],
    evaluation: top.nursing?.evaluation || [],
  };

  const disclaimer = lang === 'ar'
    ? 'هذه الأداة لأغراض تعليمية فقط ولا تستبدل التقييم الطبي المهني.'
    : 'This tool is for educational purposes only and does not replace professional medical evaluation.';
  return {
    disclaimer,
    generatedAt: new Date().toISOString(),
    differentials: scored,
    sections: {
      investigations: top.investigations,
      treatment: top.treatment,
      nursing: nursingOut,
      drugs: top.drugs,
      redFlags: (lang === 'ar' && ar.redFlags) ? ar.redFlags : top.redFlags,
      references: top.refs,
    },
    relatedPdfs,
  };
}
