import supabase from './db-client.js';
import { cors } from './_auth.js';

// Public analytics event logger (visits, views, newsletter signups).
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { type, path, resource_id } = req.body || {};
    if (!type) return res.status(400).json({ error: 'type required' });
    await supabase.from('events').insert({
      type,
      path: path || null,
      resource_id: resource_id || null,
    });
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('track error:', err);
    return res.status(500).json({ error: err.message });
  }
}
