// AI Chat Bot — general medical chat using the existing analysis engine as a fallback.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';
import { analyzeCase } from './kb/engine.mjs';


const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

// Simple educational medical chat. Detects clinical intent and runs the KB engine;
// otherwise returns a structured educational reply with relevant guideline links.
const GREETING = {
  en: 'Hello! I am an evidence-based clinical chat assistant. Describe a case, ask me a clinical question, or say "help".',
  ar: 'مرحباً! أنا مساعد سريري تعليمي قائم على الأدلة. صف لي حاله، أو اسألني سؤالا سريريا، أو اكتب "مساعده".',
};

const DISCLAIMER = {
  en: 'Educational only. Does not replace professional medical evaluation.',
  ar: 'للأغراض التعليمية فقط. لا يستبدل التقييم الطبي المهني.',
};

const SUGGESTIONS = {
  en: [
    'Generate a nursing care plan for a 65-year-old with community-acquired pneumonia.',
    'Differential for chest pain in a 45-year-old smoker.',
    'Likelihood of PE using Wells score for a 60-year-old.',
    'Complications of diabetic ketoacidosis in a 22-year-old with T1DM.',
  ],
  ar: [
    'ضع لي خطة رعاية تمريضية لمريض 65 سنة بالتهاب رئوي مجتمعي.',
    'تشخيص تفريقي لألم صدري لرجل 45 سنة مدخن.',
    'احتمال انصمام رئوي باستخدام مقياس ويلز لمريض 60 سنة.',
    'مضاعفات الحماض الكيتوني السكري لمريض 22 سنة بالنوع الأول.',
  ],
};

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const message = (b.message || '').toString().trim();
    if (message.length < 2) await trackTool('chat', ip, user?.id || null, { ok: true });
    return res.status(200).json({ reply: lang === 'ar' ? GREETING.ar : GREETING.en, suggestions: SUGGESTIONS[lang], disclaimer: DISCLAIMER[lang] });
    const t = message.toLowerCase();
    // Detect clinical intent with simple keywords
    const clinical = ['pain', 'fever', 'cough', 'short of breath', 'dyspnea', 'nausea', 'vomit', 'chest', 'abdominal', 'headache', 'seizure', 'syncope', 'palpitation', 'diarrhea', 'دم', 'ألم', 'حمى', 'سعال', 'ضيق', 'غثيان', 'قيء', 'صدري', 'بطن', 'صداع', 'تشنج', 'إغماء', 'خفقان', 'إسهال'];
    let reply;
    if (clinical.some((k) => t.includes(k))) {
      const report = analyzeCase({
        chiefComplaint: message,
        symptoms: [],
        vitals: {},
        age: undefined, gender: undefined, lang,
      });
      const top = (report.differentials || [])[0];
      const assess = (report.sections && report.sections.assessment) || [];
      const nursing = (report.sections && report.sections.nursing && report.sections.nursing.nanda) || [];
      const evals = (report.sections && report.sections.evaluation && report.sections.nursing.evaluation) || [];
      const firstAssess = assess[0] || (lang === 'ar' ? 'تقييم سريري عام' : 'General clinical assessment');
      const plannedDx = top ? top.name : (lang === 'ar' ? 'تشخيص تفريقي أوسع' : 'Broader differential');
      const primaryNursing = nursing[0] || (lang === 'ar' ? 'تنفس / تروية / ألم' : 'Breathing/perfusion/pain');
      const plan = (lang === 'ar' ? 'الخطة: ' : 'Plan: ') + firstAssess + ' · ' + primaryNursing;
      const lowSalt = (lang === 'ar' ? 'تنبيه: ' : 'Note: ') + (lang === 'ar' ? 'هذا عرض مبدئي ولا يحل محل التقييم السريري الكامل.' : 'This is preliminary and does not replace full clinical assessment.');
      const goals = (lang === 'ar' ? 'الأهداف: ' : 'Goals: ');
      const goalsList = (lang === 'ar' ? 'سيتم حفظ ثبات العلامات الحيوية' : 'Vital signs will remain stable');
      const ev = (lang === 'ar' ? 'تقييم: ' : 'Evaluation: ');
      reply = `${plan}\n${lowSalt}\n${goals}${goalsList}.\n${ev}${evals[0] || (lang === 'ar' ? 'لا توجد علامات تدهور' : 'No signs of deterioration')}.`;
    } else {
      // Non-clinical: educational fallback
      reply = lang === 'ar'
        ? 'للأغراض التعليمية فقط، يمكنني تحليل الحالات السريرية، اقتراح التشخيص التفريقي، أو توليد خطة رعاية تمريضية. اسألني عن حالة مريض أو اشرح الأعراض.'
        : 'For educational purposes only, I can analyze clinical cases, suggest differentials, or generate a nursing care plan. Describe a patient case or list symptoms/age/sex.';
    }
    return res.status(200).json({
      reply,
      suggestions: SUGGESTIONS[lang],
      disclaimer: DISCLAIMER[lang],
    });
  } catch (err) {
    console.error('ai-chat error:', err);
    return res.status(500).json({ error: err.message });
  }
}
