// AI Medical Dictionary — search the seeded dictionary.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const q = (req.query?.q || '').toString().trim();
    const lang = (req.query?.lang === 'ar' || req.query?.lang === 'en' ? req.query.lang : 'en');
    if (q.length < 2) { await trackTool('dictionary', ip, user?.id || null, { ok: true }); return res.status(200).json({ results: [], total: 0 }); }
    const { data: results } = await supabase.from('ai_dictionary')
      .select('term,abbr,ar,en,definition,category')
      .or(`term.ilike.%${q}%,en.ilike.%${q}%,definition.ilike.%${q}%,abbr.ilike.%${q}%`)
      .order('term', { ascending: true })
      .limit(20);
    const localized = (results || []).map((r) => ({
      term: lang === 'ar' ? r.term : r.term,
      translation: lang === 'ar' ? r.ar : r.en,
      definition: r.definition,
      category: r.category,
      abbr: r.abbr,
    }));
    return res.status(200).json({ results: localized, total: (results || []).length });
  } catch (err) {
    console.error('ai-dictionary error:', err);
    return res.status(500).json({ error: err.message });
  }
}
