import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';
import { analyzeCase } from './kb/engine.mjs';

// ---- in-memory rate limiter (per IP, sliding hourly window) ----
const WINDOW_MS = 60 * 60 * 1000;
const hits = new Map(); // ip -> [{t}]
function rateLimited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > (limit || 30);
}
function remaining(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  return Math.max(0, (limit || 30) - arr.length);
}

function num(v, min, max) {
  const n = Number(v);
  if (Number.isNaN(n)) return undefined;
  if (min != null && n < min) return undefined;
  if (max != null && n > max) return undefined;
  return n;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    // enable check
    const { data: cfgRow } = await supabase.from('ai_guidelines').select('description').eq('abbr', 'AI_CONFIG').single();
    let cfg = { enabled: true, rate_limit_per_hour: 30, max_history: 50, require_login_for_history: true, disclaimer: 'هذه الأداة لأغراض تعليمية فقط ولا تستبدل التقييم الطبي المهني.' };
    try { cfg = { ...cfg, ...JSON.parse(cfgRow?.description || '{}') }; } catch {}
    if (!cfg.enabled) return res.status(403).json({ error: 'الذكاء الاصطناعي معطّل حالياً.' });

    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (rateLimited(ip, cfg.rate_limit_per_hour)) {
      return res.status(429).json({ error: 'تم تجاوز حد الطلبات المسموح. حاول لاحقاً.', retryAfter: 3600 });
    }

    const b = req.body || {};
    const age = num(b.age, 0, 130);
    const gender = ['male', 'female', 'other'].includes(b.gender) ? b.gender : undefined;
    const chief = (b.chiefComplaint || '').toString().trim();

    if (age == null || !gender || !chief) {
      return res.status(400).json({ error: (caseData.lang === 'ar' ? 'الرجاء إدخال العمر والجنس والشكوى الرئيسية على الأقل.' : 'Please provide age, gender and chief complaint at minimum.') });
    }

    const caseData = {
      age,
      gender,
      height: num(b.height, 20, 260),
      weight: num(b.weight, 1, 400),
      chiefComplaint: chief.slice(0, 400),
      duration: (b.duration || '').toString().slice(0, 200),
      presentIllness: (b.presentIllness || '').toString().slice(0, 2000),
      history: Array.isArray(b.history) ? b.history.slice(0, 30) : [],
      medications: (b.medications || '').toString().slice(0, 1000),
      allergies: (b.allergies || '').toString().slice(0, 1000),
      familyHistory: (b.familyHistory || '').toString().slice(0, 1000),
      smoking: ['never', 'current', 'former'].includes(b.smoking) ? b.smoking : undefined,
      pregnancy: !!b.pregnancy,
      vitals: {},
      symptoms: Array.isArray(b.symptoms) ? b.symptoms.slice(0, 200) : [],
      labs: {},
      imaging: Array.isArray(b.imaging) ? b.imaging.slice(0, 30) : [],
      lang: (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en',
    };

    // vitals
    const vmap = { temp: [30, 45], sbp: [40, 300], dbp: [20, 200], hr: [20, 250], rr: [4, 80], spo2: [50, 100], glucose: [20, 1000] };
    for (const k of Object.keys(vmap)) {
      const n = num(b.vitals?.[k], vmap[k][0], vmap[k][1]);
      if (n != null) caseData.vitals[k] = n;
    }
    // labs
    const labKeys = ['wbc', 'hgb', 'plt', 'crp', 'esr', 'troponin', 'lactate', 'd_dimer', 'hba1c', 'glucose', 'creatinine', 'sodium', 'potassium', 'inr', 'amylase', 'lipase', 'uric_acid', 'bilirubin', 'alt', 'ast'];
    for (const k of labKeys) {
      const n = num(b.labs?.[k]?.value, -50, 5000);
      if (n != null) caseData.labs[k] = { value: n, unit: b.labs?.[k]?.unit || '' };
    }

    // related PDFs from the library
    let relatedPdfs = [];
    try {
      const { data: top } = await supabase.from('resources').select('id, title, file_url, cover_image_url, tags, category').eq('status', 'published').limit(8);
      const all = top || [];
      // score by keyword overlap with selected symptom names + chief complaint
      const hay = (chief + ' ' + (caseData.symptoms || []).join(' ')).toLowerCase();
      relatedPdfs = all
        .map((r) => {
          const text = ((r.title || '') + ' ' + (r.tags || []).join(' ') + ' ' + (r.category || '')).toLowerCase();
          let s = 0;
          if (text.includes(hay.slice(0, 12))) s += 3;
          for (const w of hay.split(/\s+/).filter((x) => x.length > 3)) if (text.includes(w)) s += 1;
          return { s, r };
        })
        .filter((x) => x.s > 0)
        .sort((a, b) => b.s - a.s)
        .slice(0, 5)
        .map((x) => ({ id: x.r.id, title: x.r.title, url: x.r.file_url, cover: x.r.cover_image_url }));
    } catch (e) { console.error('related pdfs error', e.message); }

    const report = analyzeCase(caseData, relatedPdfs);

    // auth (optional) for history
    const user = await getUser(req);
    let savedId = null;
    if (user) {
      try {
        // enforce max history
        const { count } = await supabase.from('ai_analyses').select('*', { count: 'exact', head: true }).eq('user_id', user.id);
        if (count >= (cfg.max_history || 50)) {
          await supabase.from('ai_analyses').delete().eq('user_id', user.id).order('created_at', { ascending: true }).limit(1);
        }
        const { data: ins } = await supabase.from('ai_analyses').insert({
          user_id: user.id,
          title: (chief || 'تحليل').slice(0, 120),
          case_data: caseData,
          report,
          top_diagnosis: report.differentials[0]?.name || null,
        }).select('id').single();
        savedId = ins?.id || null;
      } catch (e) { console.error('save history error', e.message); }
    }

    // analytics event
    try {
      await supabase.from('events').insert({
        type: 'ai_analysis',
        path: '/clinical-assistant',
        meta: { top: report.differentials[0]?.id, symptoms: (caseData.symptoms || []).length, saved: !!savedId },
        created_at: new Date().toISOString(),
      });
    } catch {}

    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json({ report, savedId, remaining: remaining(ip, cfg.rate_limit_per_hour), disclaimer: cfg.disclaimer });
  } catch (err) {
    console.error('ai-analyze error:', err);
    return res.status(500).json({ error: err.message });
  }
}
