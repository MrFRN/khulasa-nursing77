// AI ECG Interpreter — interprets a free-text ECG description.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const lite = {
  ar: { disclaimer: 'هذه الأداة لأغراض تعليمية فقط.',
    bad: 'لم أفهم ECG المقدم. أرجو تقديم مثال منظم: معدل، نظم، PR، QRS، QT، ST (في أي تسميات)، T.',
    rate: 'معدل النبض: ', rhythm: 'النظم: ', pr: 'PR: ', qrs: 'QRS: ', qt: 'QT/QTc: ', st: 'ST: ', twave: 'موجة T: ', summary: 'الملخص', redflags: 'علامات حمراء', recommendations: 'التوصيات', answer: 'التفسير' },
  en: { disclaimer: 'This tool is for educational purposes only.', bad: 'Could not parse ECG description. Please provide structured ECG data: rate, rhythm, PR, QRS, QT, ST (in any lead), T wave.', rate: 'Rate: ', rhythm: 'Rhythm: ', pr: 'PR: ', qrs: 'QRS: ', qt: 'QT/QTc: ', st: 'ST: ', twave: 'T wave: ', summary: 'Summary', redflags: 'Red flags', recommendations: 'Recommendations', answer: 'Interpretation' },
};

function interpret(desc, lang) {
  const d = desc.toLowerCase();
  const lines = [];
  const flags = [];

  // Rate
  const rateMatch = d.match(/(\d{2,3})\s*(bpm|\/min|beats)/);
  const rate = rateMatch ? parseInt(rateMatch[1]) : null;
  lines.push((lang === 'ar' ? lite.ar.rate : lite.en.rate) + (rate ? `${rate} bpm` : '—'));

  // Rhythm
  let rhythm = '—';
  if (/af|atrial fibrillation/.test(d)) rhythm = 'Atrial fibrillation (irregularly irregular)';
  else if (/aflutter|atrial flutter/.test(d)) rhythm = 'Atrial flutter';
  else if (/svt|supravent/.test(d)) rhythm = 'SVT (narrow complex tachycardia)';
  else if (/vt|ventricular tach/.test(d)) rhythm = 'Ventricular tachycardia';
  else if (/sinus/.test(d)) rhythm = 'Sinus rhythm';
  else if (/junctional|av block|heart block|1st degree|2nd degree|3rd degree|mobitz|wenckebach/.test(d)) rhythm = 'AV block';
  else if (/vf|fibrillation/.test(d)) rhythm = 'Ventricular fibrillation';
  lines.push((lang === 'ar' ? lite.ar.rhythm : lite.en.rhythm) + rhythm);

  // Intervals
  const prMatch = d.match(/pr\s*[:=]?\s*(\d{2,3})/);
  const qrsMatch = d.match(/qrs\s*[:=]?\s*(\d{2,3})/);
  const qtMatch = d.match(/qt[c]?\s*[:=]?\s*(\d{2,3})/);
  lines.push((lang === 'ar' ? lite.ar.pr : lite.en.pr) + (prMatch ? prMatch[1] + ' ms' : '—'));
  lines.push((lang === 'ar' ? lite.ar.qrs : lite.en.qrs) + (qrsMatch ? qrsMatch[1] + ' ms' : '—'));
  lines.push((lang === 'ar' ? lite.ar.qt : lite.en.qt) + (qtMatch ? qtMatch[1] + ' ms' : '—'));

  // ST / T
  const stMatch = d.match(/st\s*[:=]?\s*([a-z0-9 \-]+)/);
  const tMatch = d.match(/t\s*[:=]?\s*([a-z0-9 \-]+)/);
  lines.push((lang === 'ar' ? lite.ar.st : lite.en.st) + (stMatch ? stMatch[1] : '—'));
  lines.push((lang === 'ar' ? lite.ar.twave : lite.en.twave) + (tMatch ? tMatch[1] : '—'));

  // Red flags
  if (rate !== null) {
    if (rate > 130) flags.push(lang === 'ar' ? 'تسرع شديد: تسرع بطيني VT محتمل إذا كان QRS عريضًا' : 'Marked tachycardia: consider VT if wide QRS');
    if (rate < 40) flags.push(lang === 'ar' ? 'بطء شديد: انسداد AV أو متلازمة الجيب المرضى' : 'Severe bradycardia: consider AV block or sick sinus');
  }
  if (/st elevation|st elevation|st\s*\+|stemi/.test(d)) flags.push(lang === 'ar' ? 'ارتفاع ST: متلازمة تاجية حادة حتى يثبت العكس' : 'ST elevation: acute coronary syndrome until proven otherwise');
  if (/st depression|st depression/.test(d)) flags.push(lang === 'ar' ? 'انخفاض ST: نقص تروية / اختبار إجهاد إيجابي' : 'ST depression: ischemia / positive stress test');
  if (/t inversion|t-wave inversion/.test(d)) flags.push(lang === 'ar' ? 'انقلاب T: نقص تروية / تضخم / انصمام' : 'T-wave inversion: ischemia / hypertrophy / embolism');
  if (/q wave|q-wave|pathologic q/.test(d)) flags.push(lang === 'ar' ? 'موجة Q مرضية: احتشاء قديم' : 'Pathologic Q wave: old infarction');
  if (/long qt|prolonged qt|qt \u003e 500/.test(d)) flags.push(lang === 'ar' ? 'QT طويل > 500ms: خطر torsades de pointes' : 'Long QT > 500 ms: risk of torsades de pointes');
  if (/(lvh|left ventricular hypertrophy)/.test(d)) flags.push(lang === 'ar' ? 'تضخم بطين أيسر' : 'Left ventricular hypertrophy');
  if (/(rvh|right ventricular hypertrophy)/.test(d)) flags.push(lang === 'ar' ? 'تضخم بطين أيمن' : 'Right ventricular hypertrophy');
  if (/pe\b|pulmonary embolism|s1q3/.test(d)) flags.push(lang === 'ar' ? 'نمط S1Q3T3: انصمام رئوي محتمل' : 'S1Q3T3 pattern: possible pulmonary embolism');
  if (/hyperkalemia|peaked t|tall t/.test(d)) flags.push(lang === 'ar' ? 'قمة T عالية: اشتباه فرط بوتاسيوم' : 'Peaked T waves: suspect hyperkalemia');
  if (/widened qrs|bundle branch block|bbb/.test(d)) flags.push(lang === 'ar' ? 'توسيع QRS: انسداد فرع حزمة' : 'Wide QRS: bundle branch block');
  if (/low voltage/.test(d)) flags.push(lang === 'ar' ? 'جهد منخفض: انصباب تاموري / سمنة / قصور درقية' : 'Low voltage: pericardial effusion / obesity / hypothyroidism');

  const red = flags.length ? flags.join(' | ') : (lang === 'ar' ? 'لا توجد علامات حمراء واضحة' : 'No obvious red flags');
  const summary = lang === 'ar'
    ? 'بناءً على الوصف المقدم، راجع البنود أعلاه وقيّم في السياق السريري.'
    : 'Based on the description provided, review the items above and interpret in clinical context.';
  const recommendations = lang === 'ar'
    ? 'قارن بقراءة سابقة؛ احسب QTc (Bazett: QT / √RR)؛ ارجع لطبيب قلب إذا كان هناك شك. لا تستبدل هذا التفسير بإكلينيكية كاملة.'
    : 'Compare to prior ECG; calculate QTc (Bazett: QT / √RR); refer to cardiology if uncertain. Do not replace this interpretation with full clinical correlation.';

  return {
    answer: '',
    summary: lang === 'ar' ? lite.ar.answer : lite.en.answer,
    lines,
    redflags: red,
    summary_text: summary,
    recommendations,
  };
}

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const desc = (b.description || '').toString().slice(0, 2000).trim();
    if (desc.length < 10) return res.status(400).json({ error: lang === 'ar' ? 'الرجاء إدخال وصف ECG (على الأقل 10 أحرف).' : 'Please enter an ECG description (at least 10 characters).' });
    const out = interpret(desc, lang);
    if (out.answer) {
      // unstructured fallback
      out.answer = out.answer;
    }
    await trackTool('ecg', ip, user?.id || null, { ok: true });
    return res.status(200).json({ disclaimer: lang === 'ar' ? lite.ar.disclaimer : lite.en.disclaimer, lang, report: out });
  } catch (err) {
    console.error('ai-ecg error:', err);
    return res.status(500).json({ error: err.message });
  }
}
