// AI PDF Chat — extract text from a stored PDF and answer a question.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

function extractTextFromPdfBytes(bytes) {
  // Minimal PDF text extraction: capture text inside parentheses (the most common
  // pattern used for human-readable PDF strings). Robust enough for indexed notes.
  const text = new TextDecoder('latin1').decode(bytes);
  const texts = [];
  const re = /\(([^()\\]{2,500})\)\s*Tj/g;
  let m;
  while ((m = re.exec(text)) !== null) texts.push(m[1]);
  return texts.join(' ').replace(/\\([0-3])/g, ' ').replace(/\\['/g, '(').replace(/\\]/g, ')').replace(/\\\$/g, '\\$').replace(/\\\\/g, '\\').replace(/\\([0-3])/g, ' ');
}

function answerFromText(question, text) {
  if (!text || text.length < 50) return { answer: 'Unable to extract text from this PDF.', matches: [] };
  const sentences = text.split(/(?<=[.!?])\s+/).filter((s) => s.length > 30).slice(0, 50);
  const q = (question || '').toLowerCase().split(/\W+/).filter((w) => w.length > 3);
  const matches = sentences.map((s) => {
    const score = q.reduce((acc, w) => acc + (s.toLowerCase().includes(w) ? 1 : 0), 0);
    return { s, score };
  }).filter((m) => m.score > 0).sort((a, b) => b.score - a.score).slice(0, 3);
  return {
    answer: matches.length ? matches.map((m) => m.s).join(' ') : 'No relevant passages found in this PDF.',
    matches: matches.map((m) => m.s.slice(0, 200)),
  };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const id = Number(b.id);
    const question = (b.question || '').toString().trim();
    if (!id) return res.status(400).json({ error: lang === 'ar' ? 'الرجاء تحديد ملف PDF.' : 'Please select a PDF.' });
    if (!question) return res.status(400).json({ error: lang === 'ar' ? 'الرجاء كتابة سؤالك.' : 'Please enter your question.' });
    const { data: resource } = await supabase.from('resources').select('id,title,file_url').eq('id', id).single();
    if (!resource) return res.status(404).json({ error: 'PDF not found.' });
    let text = '';
    let fetchError = null;
    try {
      const user = await getUser(req);
      const r = await fetch(resource.file_url);
      if (r.ok) {
        const ab = await r.arrayBuffer();
        text = extractTextFromPdfBytes(new Uint8Array(ab));
      } else {
        fetchError = `HTTP ${r.status}`;
      }
    } catch (e) { fetchError = e.message; }
    const out = answerFromText(question, text);
    await trackTool('pdf', ip, user?.id || null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'لأغراض تعليمية فقط.' : 'For educational purposes only.',
      lang,
      title: resource.title,
      answer: out.answer,
      matches: out.matches,
      fetchError,
    });
  } catch (err) {
    console.error('ai-pdf-chat error:', err);
    return res.status(500).json({ error: err.message });
  }
}
