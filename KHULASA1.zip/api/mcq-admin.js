// Admin CRUD for MCQ cases. Owner-only.
import supabase from './db-client.js';
const OWNERS = (process.env.CASE_OWNERS || '').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
async function getUser(req) {
  const token = (req.headers?.authorization || '').toString().replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;
  const { data } = await supabase.auth.getUser(token);
  return data?.user || null;
}
function canAuthor(user) {
  if (!user) return false;
  return OWNERS.includes((user.email || '').toLowerCase());
}
export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const user = await getUser(req);
    if (!canAuthor(user)) return res.status(403).json({ error: 'Forbidden' });
    if (req.method === 'GET') {
      const { status } = req.query || {};
      let q = supabase.from('case_mcq_cases').select('*').order('id', { ascending: false }).limit(200);
      if (status) q = q.eq('status', status);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json({ cases: data || [] });
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.title_en || !b.slug) return res.status(400).json({ error: 'title_en and slug required' });
      const row = {
        slug: b.slug,
        title_en: b.title_en, title_ar: b.title_ar || b.title_en,
        specialty: b.specialty || 'general',
        condition_en: b.condition_en || null, condition_ar: b.condition_ar || null,
        difficulty: b.difficulty || 'intermediate',
        patient_age: b.patient_age || null, patient_gender: b.patient_gender || null,
        chief_complaint_en: b.chief_complaint_en || null, chief_complaint_ar: b.chief_complaint_ar || null,
        history_en: b.history_en || null, history_ar: b.history_ar || null,
        symptoms: b.symptoms || [],
        allergies: b.allergies || [],
        medications: b.medications || [],
        vitals: b.vitals || {},
        labs: b.labs || {},
        physical_exam: b.physical_exam || null,
        learning_points: b.learning_points || [],
        references: b.references || [],
        status: b.status || 'draft',
        featured: !!b.featured,
        source_url: b.source_url || null,
        guideline_version: b.guideline_version || null,
      };
      const { data, error } = await supabase.from('case_mcq_cases').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const id = req.query?.id || req.body?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const b = req.body || {};
      delete b.id; delete b.created_at;
      const { data, error } = await supabase.from('case_mcq_cases').update(b).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.query?.id || req.body?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      await supabase.from('case_mcq_questions').delete().eq('case_id', id);
      const { error } = await supabase.from('case_mcq_cases').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('mcq-admin error:', err);
    return res.status(500).json({ error: err.message });
  }
}
