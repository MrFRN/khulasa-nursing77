// Case Simulation — admin CRUD for owner (master + meta side-table).
import supabase from './db-client.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const OWNERS = (process.env.CASE_OWNERS || '').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);

async function getUser(req) {
  const token = (req.headers?.authorization || '').toString().replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;
  const { data } = await supabase.auth.getUser(token);
  return data?.user || null;
}

function canAuthor(user) {
  if (!user) return false;
  return OWNERS.includes((user.email || '').toLowerCase());
}

async function mergeMeta(items) {
  if (!items?.length) return items || [];
  const ids = items.map((c) => c.id);
  const { data: metas } = await supabase.from('case_scenarios_meta').select('*').in('case_id', ids);
  const map = new Map((metas || []).map((m) => [m.case_id, m]));
  return items.map((c) => ({ ...c, meta: map.get(c.id) || null }));
}

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const user = await getUser(req);
    if (!canAuthor(user)) return res.status(403).json({ error: 'Forbidden' });

    if (req.method === 'GET') {
      const q = req.query || {};
      const status = q.status || 'all';
      let query = supabase.from('case_scenarios').select('*').order('id', { ascending: false }).limit(500);
      if (status !== 'all') query = query.eq('published', status === 'published');
      const { data } = await query;
      const items = await mergeMeta(data || []);
      // Optional status filter via meta
      const filtered = status === 'all' ? items : items.filter((c) => (c.meta?.status || 'published') === status);
      return res.status(200).json({ cases: filtered });
    }

    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.title_en || !b.slug) return res.status(400).json({ error: 'title_en and slug are required' });
      const row = {
        slug: b.slug,
        title_en: b.title_en,
        title_ar: b.title_ar || b.title_en,
        description_en: b.description_en || null,
        description_ar: b.description_ar || null,
        specialty: b.specialty || 'medical-surgical',
        difficulty: b.difficulty || 'beginner',
        patient_name: b.patient_name || null,
        patient_age: b.patient_age || null,
        patient_gender: b.patient_gender || null,
        department: b.department || null,
        chief_complaint: b.chief_complaint || null,
        history_en: b.history_en || null,
        history_ar: b.history_ar || null,
        vitals: b.vitals || {},
        labs: b.labs || {},
        medications: b.medications || [],
        allergies: b.allergies || [],
        steps: b.steps || [],
        references: b.references || [],
        published: !!b.published,
        featured: !!b.featured,
        created_by: user.id,
        created_at: new Date().toISOString(),
      };
      const { data, error } = await supabase.from('case_scenarios').insert(row).select().single();
      if (error) throw error;
      // Meta row
      if (b.meta) {
        await supabase.from('case_scenarios_meta').upsert({
          case_id: data.id,
          status: b.meta.status || (data.published ? 'published' : 'draft'),
          condition_en: b.meta.condition_en || '',
          condition_ar: b.meta.condition_ar || '',
          tags: b.meta.tags || [],
          source_url: b.meta.source_url || null,
          guideline_version: b.meta.guideline_version || null,
          verified_at: b.meta.verified_at || null,
          published_at: data.published ? new Date().toISOString() : null,
          last_reviewed_at: new Date().toISOString(),
        }, { onConflict: 'case_id' });
      }
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const id = req.query?.id || req.body?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { id: _ignore, created_at: _ca, created_by: _cb, meta, ...patch } = req.body || {};
      const { data, error } = await supabase.from('case_scenarios').update(patch).eq('id', id).select().single();
      if (error) throw error;
      if (meta) {
        await supabase.from('case_scenarios_meta').upsert({
          case_id: id,
          ...meta,
          last_reviewed_at: new Date().toISOString(),
        }, { onConflict: 'case_id' });
      }
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const id = req.query?.id || req.body?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      await supabase.from('case_scenarios_meta').delete().eq('case_id', id);
      const { error } = await supabase.from('case_scenarios').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('case-admin error:', err);
    return res.status(500).json({ error: err.message });
  }
}
