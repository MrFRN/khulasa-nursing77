import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// Generate a signed upload URL so the browser can upload directly to Supabase
// Storage (bypassing the serverless body-size limit) while tracking progress.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { bucket, path, upsert } = req.body || {};
    if (!bucket || !path) return res.status(400).json({ error: 'bucket and path are required' });
    if (!['files', 'covers', 'media'].includes(bucket)) return res.status(400).json({ error: 'Invalid bucket' });

    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUploadUrl(path, { upsert: !!upsert });
    if (error) throw error;

    const { data: pub } = supabase.storage.from(bucket).getPublicUrl(path);

    return res.status(200).json({
      signedUrl: data.signedUrl,
      token: data.token,
      path: data.path,
      publicUrl: pub.publicUrl,
    });
  } catch (err) {
    console.error('sign-upload error:', err);
    return res.status(500).json({ error: err.message });
  }
}
