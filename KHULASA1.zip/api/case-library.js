// Case library — paginated browse with filters and sorts.
import supabase from './db-client.js';
import { trackTool } from './ai-track.js';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const q = req.query || {};
    const lang = q.lang === 'ar' ? 'ar' : 'en';
    const sort = (q.sort || 'newest').toString();
    const page = Math.max(1, Number(q.page) || 1);
    const pageSize = Math.max(1, Math.min(50, Number(q.pageSize) || 24));
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    // Allow admins to view drafts via ?status=all|draft|published
    const status = (q.status || 'published').toString();

    // Two-step query: pull from case_scenarios + LEFT-join meta via in-clause
    let query = supabase.from('case_scenarios').select('id, slug, title_en, title_ar, description_en, description_ar, specialty, difficulty, patient_age, patient_gender, department, chief_complaint, published, featured').limit(1000);
    if (q.specialty && q.specialty !== 'all') query = query.eq('specialty', q.specialty);
    if (q.difficulty && q.difficulty !== 'all') query = query.eq('difficulty', q.difficulty);
    if (q.featured === '1') query = query.eq('featured', true);

    // Random: pull up to 50 then shuffle server-side
    if (sort === 'random') {
      const all = await query;
      const list = all.data || [];
      for (let i = list.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [list[i], list[j]] = [list[j], list[i]];
      }
      const items = list.slice(0, pageSize);
      const metaIds = items.map((c) => c.id);
      const { data: metas } = await supabase.from('case_scenarios_meta').select('case_id, status, condition_en, condition_ar, tags, view_count, completion_count, avg_score').in('case_id', metaIds.length ? metaIds : [0]);
      const metaMap = new Map((metas || []).map((m) => [m.case_id, m]));
      const filtered = items.filter((c) => {
        const m = metaMap.get(c.id);
        if (!m) return status === 'published' ? c.published : false;
        if (status === 'published') return m.status === 'published' && c.published;
        if (status === 'draft') return m.status === 'draft' || m.status === 'pending_review';
        if (status === 'all') return true;
        return m.status === status;
      });
      const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
      await trackTool('case-library', ip, null, { sort: 'random' });
      return res.status(200).json({ items: filtered.map(decorate), page, pageSize, hasMore: list.length > pageSize });
    }

    // Sort handling
    const allRes = await query;
    let list = allRes.data || [];
    if (status === 'published') list = list.filter((c) => c.published);

    const metaIds = list.map((c) => c.id);
    const { data: metas } = await supabase.from('case_scenarios_meta').select('case_id, status, condition_en, condition_ar, tags, view_count, completion_count, avg_score').in('case_id', metaIds.length ? metaIds : [0]);
    const metaMap = new Map((metas || []).map((m) => [m.case_id, m]));

    // Apply status + condition filter
    list = list.filter((c) => {
      const m = metaMap.get(c.id);
      if (!m) return status === 'published' ? c.published : false;
      if (status === 'published') return m.status === 'published' && c.published;
      if (status === 'draft') return m.status === 'draft' || m.status === 'pending_review';
      if (status === 'all') return true;
      return m.status === status;
    });

    if (q.condition) {
      const cq = q.condition.toString().toLowerCase();
      list = list.filter((c) => {
        const m = metaMap.get(c.id);
        const cond = lang === 'ar' ? m?.condition_ar : m?.condition_en;
        return cond && cond.toLowerCase().includes(cq);
      });
    }
    if (q.search) {
      const sq = q.search.toString().toLowerCase();
      list = list.filter((c) => {
        const m = metaMap.get(c.id);
        const hay = [
          c.title_en, c.title_ar, c.description_en, c.description_ar,
          m?.condition_en, m?.condition_ar,
          ...(m?.tags || []),
        ].filter(Boolean).join(' ').toLowerCase();
        return hay.includes(sq);
      });
    }
    if (q.tags) {
      const tags = String(q.tags).split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
      list = list.filter((c) => {
        const m = metaMap.get(c.id);
        const tagList = (m?.tags || []).map((t) => (t || '').toLowerCase());
        return tags.every((t) => tagList.includes(t));
      });
    }
    if (q.completed === '1' && q.userId) {
      const { data: attempts } = await supabase.from('case_attempts').select('case_id').eq('user_id', q.userId).limit(500);
      const ids = new Set((attempts || []).map((a) => a.case_id));
      list = list.filter((c) => ids.has(c.id));
    }

    if (sort === 'popular') {
      list.sort((a, b) => (metaMap.get(b.id)?.completion_count || 0) - (metaMap.get(a.id)?.completion_count || 0));
    } else if (sort === 'featured') {
      list = list.filter((c) => c.featured).concat(list.filter((c) => !c.featured));
    } else {
      // newest (default)
      list.sort((a, b) => (b.id || 0) - (a.id || 0));
    }

    const slice = list.slice(from, to + 1);
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    await trackTool('case-library', ip, null, { sort, status });

    return res.status(200).json({
      items: slice.map(decorate),
      page,
      pageSize,
      total: list.length,
      hasMore: list.length > to + 1,
    });
  } catch (err) {
    console.error('case-library error:', err);
    return res.status(500).json({ error: err.message });
  }
}

function decorate(c) {
  return {
    id: c.id,
    slug: c.slug,
    title_en: c.title_en,
    title_ar: c.title_ar,
    description_en: c.description_en,
    description_ar: c.description_ar,
    specialty: c.specialty,
    difficulty: c.difficulty,
    patient_age: c.patient_age,
    patient_gender: c.patient_gender,
    department: c.department,
    chief_complaint: c.chief_complaint,
    featured: c.featured,
    published: c.published,
    meta: c.meta || null,
  };
}
