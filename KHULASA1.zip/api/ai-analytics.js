import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// Admin analytics: AI usage, most-searched diseases, common symptoms, guidelines.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const { data: events } = await supabase.from('events').select('meta, created_at').eq('type', 'ai_analysis').gte('created_at', since);
    const ev = events || [];

    const diseaseCount = {};
    const symptomCount = {};
    for (const e of ev) {
      const top = e.meta?.top;
      if (top) diseaseCount[top] = (diseaseCount[top] || 0) + 1;
      const syms = e.meta?.symptoms || 0;
      // we only stored count; approximate common symptoms via saved analyses
    }

    // Pull top diagnoses + symptom frequency from saved analyses for richer stats.
    const { data: analyses } = await supabase.from('ai_analyses').select('top_diagnosis, case_data').order('created_at', { ascending: false }).limit(500);
    const a = analyses || [];
    const diseaseByName = {};
    const symById = {};
    for (const row of a) {
      if (row.top_diagnosis) diseaseByName[row.top_diagnosis] = (diseaseByName[row.top_diagnosis] || 0) + 1;
      const syms = row.case_data?.symptoms || [];
      for (const s of syms) symById[s] = (symById[s] || 0) + 1;
    }

    // merge event-based disease counts
    for (const k of Object.keys(diseaseCount)) diseaseByName[k] = (diseaseByName[k] || 0) + diseaseCount[k];

    const topDiseases = Object.entries(diseaseByName).sort((x, y) => y[1] - x[1]).slice(0, 10).map(([name, count]) => ({ name, count }));
    const commonSymptoms = Object.entries(symById).sort((x, y) => y[1] - x[1]).slice(0, 15).map(([id, count]) => ({ id, count }));

    const { data: guidelines } = await supabase.from('ai_guidelines').select('id, abbr, name, name_en, url, description, category, enabled, sort').order('sort', { ascending: true });
    const { count: totalAnalyses } = await supabase.from('ai_analyses').select('*', { count: 'exact', head: true });

    // Tool usage breakdown (events type='ai_tool')
    const { data: tools } = await supabase.from('events').select('meta, created_at, ip, user_id').eq('type', 'ai_tool').gte('created_at', since);
    const toolCount = {};
    const today = new Date().toISOString().slice(0, 10);
    const toolToday = {};
    const toolUsers = new Map();
    for (const e of tools || []) {
      const t = e.meta?.tool;
      if (!t) continue;
      toolCount[t] = (toolCount[t] || 0) + 1;
      if (e.created_at?.slice(0, 10) === today) toolToday[t] = (toolToday[t] || 0) + 1;
      if (e.user_id) toolUsers.set(`${t}:${e.user_id}`, (toolUsers.get(`${t}:${e.user_id}`) || 0) + 1);
    }
    const toolByName = Object.create(null);
    for (const [k] of toolUsers) {
      const t = k.split(':')[0];
      toolByName[t] = (toolByName[t] || 0) + 1;
    }
    const toolStats = Object.keys(toolCount).map((t) => ({
      tool: t,
      total: toolCount[t],
      today: toolToday[t] || 0,
      dau: toolByName[t] || 0,
    })).sort((a, b) => b.total - a.total);

    return res.status(200).json({
      totalAnalyses: totalAnalyses || 0,
      periodAnalyses: ev.length,
      topDiseases,
      commonSymptoms,
      guidelines: guidelines || [],
      tools: toolStats,
    });
  } catch (err) {
    console.error('ai-analytics error:', err);
    return res.status(500).json({ error: err.message });
  }
}
