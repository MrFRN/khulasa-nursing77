// Case Simulation — evaluate a decision and return updated state.
import supabase from './db-client.js';
import { trackTool } from './ai-track.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    if (!b.caseId || b.stepIndex == null || !b.decisionId) {
      return res.status(400).json({ error: lang === 'ar' ? 'بيانات القرار ناقصة.' : 'Missing decision data.' });
    }
    const { data: c, error } = await supabase.from('case_scenarios').select('*').eq('id', b.caseId).maybeSingle();
    if (error || !c) return res.status(404).json({ error: lang === 'ar' ? 'الحالة غير موجودة.' : 'Case not found.' });

    const step = (c.steps || [])[b.stepIndex];
    if (!step) return res.status(400).json({ error: lang === 'ar' ? 'خطوة غير صحيحة.' : 'Invalid step.' });

    const decision = (step.decisions || []).find((d) => d.id === b.decisionId);
    if (!decision) return res.status(400).json({ error: lang === 'ar' ? 'قرار غير صحيح.' : 'Invalid decision.' });

    // Apply consequences to current vitals
    const baseVitals = b.currentVitals || c.vitals || {};
    const nextVitals = applyDelta(baseVitals, decision.vitals_delta || {});
    const nextStatus = decision.next_status || step.next_status || step.status || 'stable';
    const scoreDelta = Number(decision.score_delta ?? decision.points ?? 0);
    const feedback = {
      en: decision.feedback_en || decision.feedback || '',
      ar: decision.feedback_ar || decision.feedback || '',
    };
    const clinicalNote = {
      en: decision.note_en || decision.note || '',
      ar: decision.note_ar || decision.note || '',
    };
    const safetyFlags = decision.safety_flags || []; // e.g. ['wrong_dose', 'allergy']

    // Advance to next step (if any)
    let nextStepIndex = b.stepIndex + 1;
    if (decision.next_step != null) nextStepIndex = decision.next_step;
    const finished = decision.finish || nextStepIndex >= (c.steps || []).length;
    const nextStep = finished ? null : (c.steps || [])[nextStepIndex];

    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    await trackTool('case-decide', ip, null, { case: c.slug, decision: b.decisionId });

    return res.status(200).json({
      scoreDelta,
      feedback,
      clinicalNote,
      safetyFlags,
      nextVitals,
      nextStatus,
      patientCondition: decision.patient_condition || null,
      nextStepIndex: finished ? null : nextStepIndex,
      finished,
      nextStep: finished ? null : (nextStep ? {
        title_en: nextStep.title_en || nextStep.title,
        title_ar: nextStep.title_ar || nextStep.title_en || nextStep.title,
        prompt_en: nextStep.prompt_en || nextStep.prompt,
        prompt_ar: nextStep.prompt_ar || nextStep.prompt,
        decisions: (nextStep.decisions || []).map((d) => ({
          id: d.id,
          text_en: d.text_en || d.text,
          text_ar: d.text_ar || d.text_en || d.text,
          rationale_en: d.rationale_en || d.rationale,
          rationale_ar: d.rationale_ar || d.rationale,
        })),
      } : null),
    });
  } catch (err) {
    console.error('case-decide error:', err);
    return res.status(500).json({ error: err.message });
  }
}

function applyDelta(vitals, delta) {
  const out = { ...vitals };
  for (const k of Object.keys(delta)) {
    const cur = Number(out[k]);
    const d = Number(delta[k]);
    if (!isFinite(cur) || !isFinite(d)) {
      out[k] = delta[k];
    } else {
      out[k] = Math.round((cur + d) * 100) / 100;
    }
  }
  return out;
}
