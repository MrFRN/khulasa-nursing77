// AI Drug Assistant — drug lookup with interactions.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const query = (b.drug || '').toString().trim();
    if (query.length < 2) return res.status(400).json({ error: lang === 'ar' ? 'الرجاء إدخال اسم الدواء.' : 'Please enter a drug name.' });
    // build a small list of drugs by scanning the KB for drug names
    const { data: drugs } = await supabase.from('ai_dictionary').select('term,abbr,ar,en,definition,category').or(`term.ilike.%${query}%,en.ilike.%${query}%,abbr.ilike.%${query}%`).limit(40);
    const primary = (drugs || []).filter((d) => d.term.toLowerCase().startsWith(query.toLowerCase()) || d.term.toLowerCase() === query.toLowerCase());
    const display = (primary.length ? primary : drugs || []).slice(0, 20);

    // Build a recommended interactions check from a fixed high-yield list.
    const HIGH_YIELD_INTERACTIONS = [
      { pair: ['warfarin', 'amiodarone'], risk: 'Increased bleeding risk.' },
      { pair: ['warfarin', 'aspirin'], risk: 'Increased bleeding risk; avoid combination if possible.' },
      { pair: ['warfarin', 'fluconazole'], risk: 'Increased bleeding risk; monitor INR.' },
      { pair: ['warfarin', 'trimethoprim'], risk: 'Increased bleeding risk; monitor INR.' },
      { pair: ['warfarin', 'metronidazole'], risk: 'Increased bleeding risk; monitor INR.' },
      { pair: ['warfarin', 'nsaid'], risk: 'Increased bleeding risk; avoid combination if possible.' },
      { pair: ['methotrexate', 'trimethoprim'], risk: 'Severe bone marrow suppression; avoid combination.' },
      { pair: ['digoxin', 'amiodarone'], risk: 'Increased digoxin toxicity; monitor levels.' },
      { pair: ['digoxin', 'verapamil'], risk: 'Increased digoxin toxicity; monitor levels.' },
      { pair: ['digoxin', 'diltiazem'], risk: 'Increased digoxin toxicity; monitor levels.' },
      { pair: ['lithium', 'nsaid'], risk: 'Increased lithium toxicity; avoid combination.' },
      { pair: ['lithium', 'thiazide'], risk: 'Increased lithium toxicity.' },
      { pair: ['lithium', 'ace'], risk: 'Lithium toxicity changes; monitor levels.' },
      { pair: ['simvastatin', 'clarithromycin'], risk: 'Rhabdomyolysis; avoid combination.' },
      { pair: ['simvastatin', 'erythromycin'], risk: 'Rhabdomyolysis; avoid combination.' },
      { pair: ['simvastatin', 'itraconazole'], risk: 'Rhabdomyolysis; avoid combination.' },
      { pair: ['simvastatin', 'fluconazole'], risk: 'Rhabdomyolysis risk.' },
      { pair: ['metformin', 'contrast'], risk: 'Hold metformin around contrast imaging.' },
      { pair: ['monoamine', 'ssri'], risk: 'Serotonin syndrome; avoid combination.' },
      { pair: ['maoi', 'ssri'], risk: 'Serotonin syndrome; avoid combination.' },
      { pair: ['maoi', 'meperidine'], risk: 'Severe serotonin syndrome; avoid.' },
      { pair: ['ssri', 'tramadol'], risk: 'Serotonin syndrome risk.' },
      { pair: ['ssri', 'triptan'], risk: 'Serotonin syndrome risk.' },
      { pair: ['lisinopril', 'spironolactone'], risk: 'Hyperkalemia.' },
      { pair: ['lisinopril', 'potassium'], risk: 'Hyperkalemia; avoid combination.' },
      { pair: ['linezolid', 'ssri'], risk: 'Serotonin syndrome; avoid combination.' },
      { pair: ['metronidazole', 'alcohol'], risk: 'Disulfiram-like reaction.' },
      { pair: ['fluoxetine', 'tamoxifen'], risk: 'Reduced tamoxifen efficacy.' },
      { pair: ['azithromycin', 'hydroxychloroquine'], risk: 'QT prolongation; monitor ECG.' },
    ];











    /*track removed for debug*/
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'هذه الأداة لأغراض تعليمية فقط.' : 'This tool is for educational purposes only.',
      lang,
      summary: lang === 'ar' ? `تم العثور على ${display.length} دواء(ات) مطابقة.` : `Found ${display.length} matching drug(s).`,
      results: display.map((d) => ({
        term: d.term,
        abbr: d.abbr,
        ar: d.ar,
        en: d.en,
        definition: d.definition,
      })),
      interactions: [],
    });
  } catch (err) {
    console.error("ai-drug error:", err && (err.stack || err.message), "q="+query);
    return res.status(500).json({ error: err.message });
  }
}
