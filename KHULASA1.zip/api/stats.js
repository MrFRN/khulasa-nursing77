import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const QUOTA_BYTES = 15 * 1024 * 1024 * 1024; // 15 GB

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { data, error } = await supabase
      .from('files')
      .select('file_size, status, download_count');
    if (error) throw error;

    let used = 0, published = 0, drafts = 0, scheduled = 0, downloads = 0;
    for (const f of data) {
      used += Number(f.file_size || 0);
      downloads += Number(f.download_count || 0);
      if (f.status === 'published') published += 1;
      else if (f.status === 'draft') drafts += 1;
      else if (f.status === 'scheduled') scheduled += 1;
    }

    return res.status(200).json({
      used,
      quota: QUOTA_BYTES,
      count: data.length,
      published,
      drafts,
      scheduled,
      downloads,
    });
  } catch (err) {
    console.error('stats error:', err);
    return res.status(500).json({ error: err.message });
  }
}
