import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const FIELDS = [
  'title', 'description', 'section', 'category', 'year', 'subject', 'author', 'edition',
  'tags', 'file_name', 'file_path', 'file_url', 'file_size', 'file_type',
  'cover_image_url', 'cover_path', 'status', 'featured', 'popular',
  'download_count', 'view_count', 'scheduled_at',
];

function pick(body) {
  const out = {};
  for (const k of FIELDS) if (body[k] !== undefined) out[k] = body[k];
  return out;
}
function sani(s) { return String(s).replace(/[,()%]/g, ' ').trim(); }

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const q = req.query || {};
      const view = q.view === 'admin' ? 'admin' : 'public';

      // Edge caching: public reads are served from Vercel's CDN so traffic
      // spikes never hit the database. Admin reads are never cached.
      res.setHeader(
        'Cache-Control',
        view === 'public'
          ? 'public, s-maxage=30, stale-while-revalidate=300'
          : 'private, no-store'
      );

      if (q.id) {
        const { data, error } = await supabase.from('resources').select('*').eq('id', q.id).single();
        if (error || !data) return res.status(404).json({ error: '\u063a\u064a\u0631 \u0645\u0648\u062c\u0648\u062f' });
        if (view === 'public') {
          const visible = data.status === 'published' ||
            (data.status === 'scheduled' && data.scheduled_at && new Date(data.scheduled_at) <= new Date());
          if (!visible) return res.status(404).json({ error: '\u063a\u064a\u0631 \u0645\u0648\u062c\u0648\u062f' });
        } else {
          const u = await getUser(req);
          if (!u) return res.status(401).json({ error: 'Unauthorized' });
        }
        return res.status(200).json(data);
      }

      let query = supabase.from('resources').select('*');
      if (view === 'public') {
        const now = new Date().toISOString();
        query = query.or(`status.eq.published,and(status.eq.scheduled,scheduled_at.lte.${now})`);
      } else {
        const u = await getUser(req);
        if (!u) return res.status(401).json({ error: 'Unauthorized' });
        if (q.status) query = query.eq('status', q.status);
      }
      if (q.section) query = query.eq('section', q.section);
      if (q.category) query = query.eq('category', q.category);
      if (q.year) query = query.eq('year', q.year);
      if (q.subject) query = query.eq('subject', q.subject);
      if (q.featured === 'true') query = query.eq('featured', true);
      if (q.popular === 'true') query = query.eq('popular', true);
      if (q.search) {
        const s = sani(q.search);
        if (s) query = query.or(`title.ilike.%${s}%,description.ilike.%${s}%,subject.ilike.%${s}%,author.ilike.%${s}%`);
      }
      const allowed = ['created_at', 'updated_at', 'title', 'file_size', 'download_count', 'view_count'];
      const sort = allowed.includes(q.sort) ? q.sort : 'created_at';
      query = query.order(sort, { ascending: q.order === 'asc' });
      // Always bound the payload so a huge library can never blow up a response
      query = query.limit(q.limit ? Math.min(Number(q.limit) || 500, 1000) : 500);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (req.method === 'POST') {
      const body = req.body || {};
      const b = pick(body);
      if (!b.title) return res.status(400).json({ error: '\u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0645\u0637\u0644\u0648\u0628' });
      if (!b.file_path) return res.status(400).json({ error: '\u0627\u0644\u0645\u0644\u0641 \u0645\u0637\u0644\u0648\u0628' });
      b.user_id = user.id;
      b.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('resources').insert(b).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const body = req.body || {};
      const b = pick(body);
      b.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('resources').update(b).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data: rec } = await supabase.from('resources').select('file_path, cover_path').eq('id', id).single();
      const { data: delChunks } = await supabase.from('resource_chunks').select('path').eq('resource_id', id);
      if (delChunks && delChunks.length) {
        await supabase.storage.from('files').remove(delChunks.map((c) => c.path)).catch(() => {});
        await supabase.from('resource_chunks').delete().eq('resource_id', id);
      }
      if (rec) {
        if (rec.file_path) await supabase.storage.from('files').remove([rec.file_path]).catch(() => {});
        if (rec.cover_path) await supabase.storage.from('covers').remove([rec.cover_path]).catch(() => {});
      }
      const { error } = await supabase.from('resources').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('resources API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
