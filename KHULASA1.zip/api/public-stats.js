import supabase from './db-client.js';
import { cors } from './_auth.js';

// Public homepage statistics.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
    const { data: resources } = await supabase
      .from('resources')
      .select('download_count, section, status');
    const published = (resources || []).filter((r) => r.status === 'published');
    const downloads = published.reduce((s, r) => s + (r.download_count || 0), 0);
    const books = published.filter((r) => r.section === 'books').length;

    const { count: categories } = await supabase
      .from('nursing_categories')
      .select('*', { count: 'exact', head: true });
    const { count: visitors } = await supabase
      .from('events')
      .select('*', { count: 'exact', head: true })
      .eq('type', 'visit');

    return res.status(200).json({
      resources: published.length,
      downloads,
      books,
      categories: categories || 0,
      visitors: visitors || 0,
    });
  } catch (err) {
    console.error('public-stats error:', err);
    return res.status(500).json({ error: err.message });
  }
}
