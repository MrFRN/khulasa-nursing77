// Admin review workflow: approve, reject, request-changes, regenerate.
// All actions write to case_review_log + update status in case_scenarios_meta.
import supabase from './db-client.js';
import { trackTool } from './ai-track.js';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const OWNERS = (process.env.CASE_OWNERS || '').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);

async function getUser(req) {
  const token = (req.headers?.authorization || '').toString().replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;
  const { data } = await supabase.auth.getUser(token);
  return data?.user || null;
}

function canAuthor(user) {
  if (!user) return false;
  return OWNERS.includes((user.email || '').toLowerCase());
}

export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    if (!canAuthor(user)) return res.status(403).json({ error: 'Forbidden — admin only' });

    const b = req.body || {};
    const { caseId, action, notes } = b;
    if (!caseId || !action) return res.status(400).json({ error: 'caseId and action required' });

    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    const ts = new Date().toISOString();

    // Always write the audit log
    await supabase.from('case_review_log').insert({
      case_id: caseId,
      actor_id: user.id,
      actor_email: user.email,
      action,
      notes: notes || null,
      created_at: ts,
    });

    let newStatus = null;
    if (action === 'approve' || action === 'publish') {
      newStatus = 'published';
      // Update published + published_at on the case
      await supabase.from('case_scenarios').update({ published: true, published_at: ts }).eq('id', caseId);
      await supabase.from('case_scenarios_meta').update({
        status: 'published', published_at: ts, last_reviewed_at: ts,
        verified_at: ts, guideline_version: notes || 'admin-approved',
      }).eq('case_id', caseId);
    } else if (action === 'reject') {
      newStatus = 'rejected';
      await supabase.from('case_scenarios_meta').update({ status: 'rejected', last_reviewed_at: ts }).eq('case_id', caseId);
      await supabase.from('case_scenarios').update({ published: false }).eq('id', caseId);
    } else if (action === 'request_changes') {
      newStatus = 'pending_review';
      await supabase.from('case_scenarios_meta').update({ status: 'pending_review', last_reviewed_at: ts }).eq('case_id', caseId);
    } else if (action === 'unpublish' || action === 'archive') {
      newStatus = 'archived';
      await supabase.from('case_scenarios').update({ published: false }).eq('id', caseId);
      await supabase.from('case_scenarios_meta').update({ status: 'archived', last_reviewed_at: ts }).eq('case_id', caseId);
    } else if (action === 'feature') {
      await supabase.from('case_scenarios').update({ featured: true }).eq('id', caseId);
    } else if (action === 'unfeature') {
      await supabase.from('case_scenarios').update({ featured: false }).eq('id', caseId);
    } else if (action === 'regenerate') {
      // Mark for regeneration; admin should delete + regenerate externally
      await supabase.from('case_scenarios_meta').update({ status: 'pending_review', last_reviewed_at: ts }).eq('case_id', caseId);
      newStatus = 'pending_review';
    } else {
      return res.status(400).json({ error: 'Unknown action' });
    }

    await trackTool('case-review', ip, user.id, { caseId, action });
    return res.status(200).json({ ok: true, caseId, action, status: newStatus });
  } catch (err) {
    console.error('case-review error:', err);
    return res.status(500).json({ error: err.message });
  }
}
