import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// List supported medical guidelines (public) + admin update of a guideline.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
      const { data, error } = await supabase.from('ai_guidelines').select('id, abbr, name, name_en, url, description, category, enabled, sort').order('sort', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'PUT') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Unauthorized' });
      const body = req.body || {};
      const id = Number(body.id);
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = {};
      if (typeof body.enabled === 'boolean') patch.enabled = body.enabled;
      if (typeof body.url === 'string') patch.url = body.url.slice(0, 500);
      if (typeof body.description === 'string') patch.description = body.description.slice(0, 500);
      const { data, error } = await supabase.from('ai_guidelines').update(patch).eq('id', id).select('*').single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('ai-guidelines error:', err);
    return res.status(500).json({ error: err.message });
  }
}
