// AI Care Plan history - per-user storage of saved care plans.
import { createClient } from '@supabase/supabase-js';
import supabase from './db-client.js';

function getToken(req) {
  const h = req.headers?.authorization || req.headers?.Authorization || '';
  return h.toString().replace(/^Bearer\s+/i, '').trim();
}

async function userClient(req) {
  const token = getToken(req);
  if (!token) return null;
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const client = await userClient(req);
    if (!client) return res.status(401).json({ error: 'Unauthorized' });
    const { data: userData } = await client.auth.getUser();
    const user = userData?.user;
    if (!user) return res.status(401).json({ error: 'Invalid token' });

    if (req.method === 'GET') {
      const id = req.query?.id;
      if (id) {
        const { data, error } = await client.from('ai_care_plans').select('*').eq('id', id).eq('user_id', user.id).single();
        if (error || !data) return res.status(404).json({ error: 'Not found' });
        return res.status(200).json(data);
      }
      const { data, error } = await client.from('ai_care_plans').select('id, title, lang, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(100);
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.plan) return res.status(400).json({ error: 'Plan data required' });
      const title = (b.title || (b.caseData?.diagnosis ? `${b.caseData.diagnosis} (${b.caseData.age || '—'}y, ${b.caseData.gender || '—'})` : `Care Plan ${new Date().toLocaleString()}`)).slice(0, 200);
      const { data, error } = await client.from('ai_care_plans').insert({
        user_id: user.id,
        title,
        case_data: b.caseData || null,
        plan: b.plan,
        lang: b.lang || 'en',
        created_at: new Date().toISOString(),
      }).select('id, title, lang, created_at').single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.query?.id || req.body?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await client.from('ai_care_plans').delete().eq('id', id).eq('user_id', user.id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('ai-careplan-history error:', err);
    return res.status(500).json({ error: err.message });
  }
}
