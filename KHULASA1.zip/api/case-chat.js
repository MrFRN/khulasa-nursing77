// Case Simulation — AI patient chat constrained to the case data.
import supabase from './db-client.js';
import { trackTool } from './ai-track.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    if (!b.caseId) return res.status(400).json({ error: lang === 'ar' ? 'حدد الحالة.' : 'Specify a case.' });
    const message = String(b.message || '').trim();
    if (!message) return res.status(400).json({ error: lang === 'ar' ? 'أدخل رسالة.' : 'Enter a message.' });

    const { data: c, error } = await supabase.from('case_scenarios').select('*').eq('id', b.caseId).maybeSingle();
    if (error || !c) return res.status(404).json({ error: lang === 'ar' ? 'الحالة غير موجودة.' : 'Case not found.' });

    const lower = message.toLowerCase();
    const ar = lang === 'ar';
    const chiefComplaint = c.chief_complaint || '';
    const history = ar ? (c.history_ar || '') : (c.history_en || '');
    const allergies = (c.allergies || []).join(', ');
    const meds = (c.medications || []).map((m) => (typeof m === 'string' ? m : `${m.name || ''} ${m.dose || ''}`)).join(', ');

    // Heuristic intent matching — never invent findings, only echo from case data.
    let reply = '';

    if (/(pain|ألم|وجع)/i.test(message)) {
      const pain = (c.vitals || {})['pain'] || (c.labs || {})['pain'] || null;
      reply = ar
        ? (pain != null ? `نعم، أشعر بألم. مستوى الألم: ${pain} من 10.` : `أشعر ببعض الألم وعدم الراحة.`)
        : (pain != null ? `Yes, I have pain. Pain level: ${pain}/10.` : `I feel some pain and discomfort.`);
    } else if (/(breathe|breathing|تنفس|تنفسي)/i.test(message)) {
      const rr = (c.vitals || {})['rr'];
      const spo2 = (c.vitals || {})['spo2'];
      reply = ar
        ? (rr ? `معدل تنفسي حوالي ${rr} في الدقيقة. أكاد ألهث.` : `أشعر بصعوبة في التنفس.`)
        : (rr ? `My breathing feels fast, about ${rr}/min.` : `I feel short of breath.`);
      if (spo2 != null) reply += (ar ? ` تشبع الأكسجين تقريبًا ${spo2}%.` : ` My oxygen is around ${spo2}%.`);
    } else if (/(allergy|حساسية)/i.test(message)) {
      reply = allergies
        ? (ar ? `حساسيتي: ${allergies}.` : `My allergies: ${allergies}.`)
        : (ar ? 'لا أعرف حساسية معينة.' : `I don't have any known allergies.`);
    } else if (/(medicine|medication|drug|دواء|أدوية|علاج)/i.test(message)) {
      reply = meds
        ? (ar ? `أتناول: ${meds}.` : `I am taking: ${meds}.`)
        : (ar ? 'لا أتذكر أدويتي حاليًا.' : `I don't remember my medications right now.`);
    } else if (/(history|ماضي|سابق)/i.test(message) || /(disease|مرض)/i.test(message)) {
      reply = history || (ar ? 'لا أتذكر التاريخ المرضي بدقة.' : `I don't remember my medical history in detail.`);
    } else if (/(name|اسمك|اسمك إيه)/i.test(message)) {
      reply = ar ? `اسمي ${c.patient_name}.` : `My name is ${c.patient_name}.`;
    } else if (/(age|عمر)/i.test(message)) {
      reply = ar ? `عمري ${c.patient_age} سنة.` : `I am ${c.patient_age} years old.`;
    } else if (/(why|come|سبب|أتيت|أتيت لـ|ليش)/i.test(message) || /(happened|ماذا حدث|ماذا يحصل)/i.test(message)) {
      reply = chiefComplaint || (ar ? 'لا أتذكر التفاصيل.' : `I don't remember the details.`);
    } else if (/(hurt|تؤلم|يؤلم)/i.test(message)) {
      reply = ar ? `نعم، هذا الجزء يؤلمني.` : `Yes, that hurts.`;
    } else if (/(better|تحسن|أحسن)/i.test(message)) {
      reply = ar ? 'لا أزال أشعر بنفس الشعور.' : `I still feel the same.`;
    } else {
      // Generic fallback: restate known info so we never invent
      const bits = [];
      if (c.chief_complaint) bits.push(ar ? `الشكوى: ${c.chief_complaint}` : `My complaint: ${c.chief_complaint}`);
      if (history) bits.push(ar ? `التاريخ: ${history}` : `History: ${history}`);
      if (meds) bits.push(ar ? `الأدوية: ${meds}` : `Medications: ${meds}`);
      if (allergies) bits.push(ar ? `الحساسية: ${allergies}` : `Allergies: ${allergies}`);
      reply = bits.length ? bits.join(' | ') : (ar ? 'لا أملك معلومة عن ذلك.' : `I don't have that information.`);
    }

    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    await trackTool('case-chat', ip, null, { case: c.slug });

    return res.status(200).json({
      reply,
      patientName: c.patient_name,
      disclaimer: ar ? 'ردود المريض مبنية على بيانات الحالة فقط ولا تُخترع.' : 'Patient replies are sourced from case data only and are not invented.',
    });
  } catch (err) {
    console.error('case-chat error:', err);
    return res.status(500).json({ error: err.message });
  }
}
