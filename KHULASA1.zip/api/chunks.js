import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// Manages multipart file chunks for large uploads (> Supabase per-object limit).
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
      const { resource_id } = req.query || {};
      if (!resource_id) return res.status(400).json({ error: 'resource_id required' });
      const { data, error } = await supabase
        .from('resource_chunks')
        .select('idx, url, path, size')
        .eq('resource_id', resource_id)
        .order('idx', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }

    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (req.method === 'POST') {
      const { resource_id, chunks } = req.body || {};
      if (!resource_id || !Array.isArray(chunks)) return res.status(400).json({ error: 'resource_id and chunks required' });

      // Replace mode: remove existing chunks (rows + storage objects) first
      const { data: old } = await supabase.from('resource_chunks').select('path').eq('resource_id', resource_id);
      if (old && old.length) {
        await supabase.storage.from('files').remove(old.map((o) => o.path)).catch(() => {});
        await supabase.from('resource_chunks').delete().eq('resource_id', resource_id);
      }

      const rows = chunks.map((c) => ({
        resource_id, idx: c.idx, url: c.url, path: c.path, size: c.size || 0,
      }));
      const { data, error } = await supabase.from('resource_chunks').insert(rows).select();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { resource_id } = req.body || {};
      if (!resource_id) return res.status(400).json({ error: 'resource_id required' });
      const { data: old } = await supabase.from('resource_chunks').select('path').eq('resource_id', resource_id);
      if (old && old.length) await supabase.storage.from('files').remove(old.map((o) => o.path)).catch(() => {});
      const { error } = await supabase.from('resource_chunks').delete().eq('resource_id', resource_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('chunks API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
