// Case Simulation — user stats (XP, level, streak, badges, completed cases).
import { createClient } from '@supabase/supabase-js';
import supabase from './db-client.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function getToken(req) {
  return (req.headers?.authorization || '').toString().replace(/^Bearer\s+/i, '').trim();
}

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const token = getToken(req);
    if (!token) return res.status(200).json({ stats: null });
    const { data: ud } = await supabase.auth.getUser(token);
    const user = ud?.user;
    if (!user) return res.status(200).json({ stats: null });

    const userClient = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
    const { data: stats } = await userClient.from('case_user_stats').select('*').eq('user_id', user.id).maybeSingle();
    const { data: attempts } = await userClient.from('case_attempts').select('id, case_slug, score, xp_earned, completed_at, badges').eq('user_id', user.id).order('completed_at', { ascending: false }).limit(20);
    return res.status(200).json({ stats: stats || null, attempts: attempts || [] });
  } catch (err) {
    console.error('case-stats error:', err);
    return res.status(500).json({ error: err.message });
  }
}
