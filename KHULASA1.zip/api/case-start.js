// Case Simulation — start a case (returns initial state + meta).
import supabase from './db-client.js';
import { trackTool } from './ai-track.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

async function fetchMeta(caseId) {
  const { data } = await supabase.from('case_scenarios_meta').select('*').eq('case_id', caseId).maybeSingle();
  return data || null;
}

async function incrementViewCount(caseId) {
  try {
    const { data: meta } = await supabase.from('case_scenarios_meta').select('view_count').eq('case_id', caseId).maybeSingle();
    const next = (meta?.view_count || 0) + 1;
    await supabase.from('case_scenarios_meta').update({ view_count: next }).eq('case_id', caseId);
  } catch { /* ignore */ }
}

function serializeCase(c, lang, meta) {
  return {
    id: c.id,
    slug: c.slug,
    title: lang === 'ar' ? c.title_ar : c.title_en,
    description: lang === 'ar' ? c.description_ar : c.description_en,
    specialty: c.specialty,
    difficulty: c.difficulty,
    patient: {
      name: c.patient_name,
      age: c.patient_age,
      gender: c.patient_gender,
      department: c.department,
    },
    chief_complaint: c.chief_complaint,
    history: lang === 'ar' ? c.history_ar : c.history_en,
    vitals: c.vitals || {},
    labs: c.labs || {},
    medications: c.medications || [],
    allergies: c.allergies || [],
    steps: c.steps || [],
    references: c.references || [],
    condition: meta ? (lang === 'ar' ? meta.condition_ar : meta.condition_en) : null,
    tags: meta?.tags || [],
    status: meta?.status || 'published',
  };
}

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();

    if (b.random) {
      const all = await supabase.from('case_scenarios').select('*').eq('published', true).limit(500);
      const list = all.data || [];
      if (!list.length) return res.status(404).json({ error: lang === 'ar' ? 'لا توجد حالات متاحة.' : 'No cases available.' });
      const chosen = list[Math.floor(Math.random() * list.length)];
      const meta = await fetchMeta(chosen.id);
      await incrementViewCount(chosen.id);
      await trackTool('case-start', ip, null, { case: chosen.slug });
      return res.status(200).json({ case: serializeCase(chosen, lang, meta), startedAt: new Date().toISOString() });
    }

    let query = supabase.from('case_scenarios').select('*').eq('published', true);
    if (b.slug) query = query.eq('slug', b.slug);
    else if (b.caseId) query = query.eq('id', b.caseId);
    else return res.status(400).json({ error: lang === 'ar' ? 'حدد حالة.' : 'Specify a case.' });

    const { data, error } = await query.maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: lang === 'ar' ? 'الحالة غير موجودة.' : 'Case not found.' });

    const meta = await fetchMeta(data.id);
    await incrementViewCount(data.id);
    await trackTool('case-start', ip, null, { case: data.slug });

    return res.status(200).json({ case: serializeCase(data, lang, meta), startedAt: new Date().toISOString() });
  } catch (err) {
    console.error('case-start error:', err);
    return res.status(500).json({ error: err.message });
  }
}
