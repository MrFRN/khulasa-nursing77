import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// AI Assistant settings are stored as a dedicated row in ai_guidelines (abbr = 'AI_CONFIG').
const DEFAULTS = {
  enabled: true,
  disclaimer: 'هذه الأداة لأغراض تعليمية فقط ولا تستبدل التقييم الطبي المهني.',
  rate_limit_per_hour: 30,
  max_history: 50,
  require_login_for_history: true,
};

async function readConfig() {
  const { data } = await supabase.from('ai_guidelines').select('description').eq('abbr', 'AI_CONFIG').single();
  try {
    const parsed = data?.description ? JSON.parse(data.description) : {};
    return { ...DEFAULTS, ...parsed };
  } catch {
    return DEFAULTS;
  }
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      // Public: only reveal whether AI is enabled + the disclaimer.
      res.setHeader('Cache-Control', 'public, s-maxage=30, stale-while-revalidate=120');
      const cfg = await readConfig();
      return res.status(200).json({ enabled: !!cfg.enabled, disclaimer: cfg.disclaimer });
    }

    if (req.method === 'PUT') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Unauthorized' });
      const cfg = await readConfig();
      const body = req.body || {};
      const next = {
        enabled: typeof body.enabled === 'boolean' ? body.enabled : cfg.enabled,
        disclaimer: body.disclaimer || cfg.disclaimer,
        rate_limit_per_hour: Number(body.rate_limit_per_hour) || cfg.rate_limit_per_hour,
        max_history: Number(body.max_history) || cfg.max_history,
        require_login_for_history: typeof body.require_login_for_history === 'boolean' ? body.require_login_for_history : cfg.require_login_for_history,
      };
      const { error } = await supabase.from('ai_guidelines').update({ description: JSON.stringify(next) }).eq('abbr', 'AI_CONFIG');
      if (error) throw error;
      return res.status(200).json({ ok: true, config: next });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('ai-settings error:', err);
    return res.status(500).json({ error: err.message });
  }
}
