// AI Interview Simulator — clinical role-play (e.g., ICU interview).
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

const SCENARIOS = {
  en: [
    {
      id: 'icu',
      title: 'ICU Interview',
      context: 'You are applying for a senior ICU nursing position. The interviewer asks about managing a hemodynamically unstable patient on vasopressors.',
      questions: [
        'How do you assess a patient on multiple vasopressors?',
        'What parameters guide your titration of norepinephrine?',
        'When would you escalate to vasopressin or add an inotrope?',
        'How do you hand off to the oncoming shift?',
      ],
    },
    {
      id: 'er',
      title: 'Emergency Room Interview',
      context: 'You are interviewing for an ER position. The interviewer asks about triage and shock management.',
      questions: [
        'How do you triage a patient with chest pain and hypotension?',
        'What are the first steps in undifferentiated shock?',
        'When do you activate a code?',
        'How do you communicate with a family in crisis?',
      ],
    },
    {
      id: 'hr',
      title: 'HR Interview',
      context: 'You are in an HR interview. The interviewer asks about teamwork, conflict, and strengths.',
      questions: [
        'Tell me about a time you had a conflict with a coworker.',
        'What are your strengths and weaknesses?',
        'Where do you see yourself in five years?',
        'Why should we hire you?',
      ],
    },
  ],
  ar: [
    {
      id: 'icu',
      title: 'مقابلة ICU',
      context: 'أنت تتقدم لوظيفة ممرض/ة ICU أول. يسألك المحاور عن مريض غير مستقر هيموديناميكياً على رافعات الضغط.',
      questions: [
        'كيف تقيّم مريضاً على عدة رافعات ضغط؟',
        'ما المعايير التي توجه تعديل نورإبينفرين؟',
        'متى تتجه لفازوبريسين أو تضيف Inotrope؟',
        'كيف تنقل الحالة للفترة التالية؟',
      ],
    },
    {
      id: 'er',
      title: 'مقابلة طوارئ',
      context: 'أنت في مقابلة طوارئ. يسألك المحاور عن الفرز وإدارة الصدمة.',
      questions: [
        'كيف تفرز مريضاً بألم صدري وهبوط ضغط؟',
        'ما الخطوات الأولى في صدمة غير متمايزة؟',
        'متى تفعّل كود؟',
        'كيف تتواصل مع أسرة في أزمة؟',
      ],
    },
    {
      id: 'hr',
      title: 'مقابلة موارد بشرية',
      context: 'أنت في مقابلة HR. يسألك عن العمل الجماعي وحل النزعات ونقاط القوة.',
      questions: [
        'حدث عن موقف حدثت بينك فيه خلاف مع زميل.',
        'ما نقاط قوتك وضعفك؟',
        'أين ترى نفسك بعد خمس سنوات؟',
        'لماذا يجب أن نوظفك؟',
      ],
    },
  ],
};

function scoreAnswer(answer, lang) {
  const a = (answer || '').toLowerCase().trim();
  if (a.length < 10) return { score: 0, feedback: lang === 'ar' ? 'إجابة قصيرة جداً' : 'Too short' };
  const keywords = ['patient', 'safety', 'team', 'assess', 'monitor', 'document', 'priority', 'مريض', 'سلامة', 'فريق', 'تقييم', 'مراقبة', 'توثيق'];
  const hits = keywords.filter((k) => a.includes(k)).length;
  const score = Math.min(100, Math.round(20 + hits * 15 + Math.min(a.length / 3, 30)));
  const feedback = lang === 'ar'
    ? `أظهرت ${hits} مؤشر مهني. استخدم مثالاً STAR (موقف، مهمة، إجراء، نتيجة) وتحدث عن أمان المريض والنتائج القابلة للقياس.`
    : `You showed ${hits} professional cues. Try a STAR example (Situation, Task, Action, Result) emphasizing patient safety and measurable outcomes.`;
  return { score, feedback };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const scenario = (b.scenario || 'icu').toString();
    const sc = (SCENARIOS[lang] || SCENARIOS.en).find((s) => s.id === scenario) || (SCENARIOS[lang] || SCENARIOS.en)[0];
    const mode = (b.mode || 'interview').toString();
    const answer = (b.answer || '').toString();
    let result = null;
    if (mode === 'answer' && answer) {
      result = scoreAnswer(answer, lang);
    }
    await trackTool('interview', ip, user?.id || null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'لأغراض تعليمية فقط.' : 'For educational purposes only.',
      lang,
      scenario: sc,
      result,
    });
  } catch (err) {
    console.error('ai-interview error:', err);
    return res.status(500).json({ error: err.message });
  }
}
