// AI NCLEX Exam — generates multiple-choice questions from the KB.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

function pickN(arr, n) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, n);
}

function statementFor(d, lang) {
  if (lang === 'ar') return `أي من التالي صحيح بخصوص ${d.name}؟`;
  return `Which of the following is correct about ${d.name}?`;
}

function distractors(d, lang) {
  const ops = ['Lisinopril', 'Metoprolol', 'Amoxicillin', 'Vancomycin', 'Furosemide', 'Acetaminophen', 'Heparin', 'Insulin glargine', 'Norepinephrine', 'Warfarin'];
  const correct = d.drugs && d.drugs[0] ? d.drugs[0].generic : 'Heroic';
  const options = lang === 'ar'
    ? [
        `${d.name} علاج مناعي ذاتي.`,
        `${d.name} يحدث حصراً بسبب فيروس.`,
        `${d.name} غير مرتبط بأعراض المريض.`,
        `العلاج الأساسي لـ ${d.name} هو ${correct}.`,
      ]
    : [
        `${d.name} is typically an autoimmune condition.`,
        `${d.name} is caused exclusively by viruses.`,
        `${d.name} is unrelated to the patient's symptoms.`,
        `First-line therapy for ${d.name} is ${correct}.`,
      ];
  return options;
}

function buildExam(lang, count) {
  return [{
    id: 1,
    topic: lang === 'ar' ? 'السلامة والمراقبة' : 'Safety & Monitoring',
    stem: lang === 'ar'
      ? 'مريض يتلقى وارفارين. أي من التالي يستوجب الاتصال بالطبيب فوراً؟'
      : 'A patient is receiving warfarin. Which of the following requires immediate notification of the physician?',
    choices: lang === 'ar'
      ? ['INR 2.5', 'نزيف أنفي', 'انتفاخ خفيف في الكاحل', 'بول وردي فاتح']
      : ['INR of 2.5', 'Epistaxis (nosebleed)', 'Mild ankle edema', 'Light pink urine'],
    answer: 1,
    rationale: lang === 'ar'
      ? 'النزيف علامة خطر تتطلب تقييماً فورياً.'
      : 'Bleeding is a danger sign requiring immediate evaluation.',
  }, {
    id: 2,
    topic: lang === 'ar' ? 'الفسلجة' : 'Physiology',
    stem: lang === 'ar'
      ? 'مريض بـ داء الانسداد الرئوي المزمن (COPD). ما التغيير الفسلجي المتوقع في غازات الدم؟'
      : 'A patient with COPD. What physiological change is expected in blood gases?',
    choices: lang === 'ar'
      ? ['انخفاض PaO2', 'زيادة PaO2', 'انخفاض PaCO2', 'زيادة HCO3']
      : ['Decreased PaO2', 'Increased PaO2', 'Decreased PaCO2', 'Increased HCO3'],
    answer: 0,
    rationale: lang === 'ar' ? 'تشبع أكسجين منخفض' : 'Decreased PaO2 due to V/Q mismatch.',
  }, {
    id: 3,
    topic: lang === 'ar' ? 'الدوائية' : 'Pharmacology',
    stem: lang === 'ar'
      ? 'مريض يتلقى ميتفورمين. أي من التالي يستوجب إيقاف الدواء فوراً؟'
      : 'A patient is receiving metformin. Which of the following requires immediate discontinuation?',
    choices: lang === 'ar'
      ? ['صداع', 'غثيان', 'حماض كيتوني', 'إسهال']
      : ['Headache', 'Nausea', 'Ketoacidosis', 'Diarrhea'],
    answer: 2,
    rationale: lang === 'ar' ? 'الحماض الكيتوني يستوجب إيقاف ميتفورمين.' : 'Ketoacidosis requires stopping metformin.',
  }, {
    id: 4,
    topic: lang === 'ar' ? 'الإجراءات' : 'Procedures',
    stem: lang === 'ar'
      ? 'ممرضة تدخل أنبوب أنفي معوي. أي إجراء صحيح؟'
      : 'A nurse is inserting a nasogastric tube. Which action is correct?',
    choices: lang === 'ar'
      ? ['قياس الطول من الأنف للأذن ثم للوربة', 'إدخال 50 سم بسرعة', 'التحقق من الموضع بحقنة هواء', 'لا داعي للتحقق']
      : ['Measure from nose to ear to xiphoid', 'Insert 50 cm quickly', 'Confirm position with air injection', 'No verification needed'],
    answer: 0,
    rationale: lang === 'ar' ? 'طريقة NEX تُستخدم لقياس طول الأنبوب.' : 'NEX method measures tube length.',
  }, {
    id: 5,
    topic: lang === 'ar' ? 'التمريض' : 'Fundamentals',
    stem: lang === 'ar'
      ? 'مريض فاقد الوعي. أي وضع جانب آمن؟'
      : 'A patient is unconscious. Which side-lying position is safe?',
    choices: lang === 'ar'
      ? ['الاستلقاء على الظهر', 'الاستلقاء الجانبي الأيسر', 'الاستلقاء الجانبي الأيمن', 'استلقاء برنبور']
      : ['Supine', 'Left lateral', 'Right lateral', 'Prone'],
    answer: 1,
    rationale: lang === 'ar' ? 'الاستلقاء الجانبي الأيسر يمنع استنشاق القيء.' : 'Left lateral prevents aspiration of vomit.',
  }];
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const count = Math.min(Math.max(Number(b.count) || 5, 1), 10);
    const questions = buildExam(lang, count).slice(0, count);
    await trackTool('exam', ip, user?.id || null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'لأغراض تعليمية فقط.' : 'For educational purposes only.',
      lang,
      questions,
    });
  } catch (err) {
    console.error('ai-exam error:', err);
    return res.status(500).json({ error: err.message });
  }
}
