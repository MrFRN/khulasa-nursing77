import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// List / search the authenticated user's saved AI analyses.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });
    const id = req.query?.id;
    if (id) {
      const { data, error } = await supabase.from('ai_analyses').select('*').eq('user_id', user.id).eq('id', id).single();
      if (error) return res.status(404).json({ error: 'غير موجود' });
      return res.status(200).json(data);
    }
    const q = (req.query?.q || '').toString().trim();
    let query = supabase.from('ai_analyses').select('id, title, top_diagnosis, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(100);
    if (q) query = query.ilike('title', `%${q}%`);
    const { data, error } = await query;
    if (error) throw error;
    return res.status(200).json(data || []);
  } catch (err) {
    console.error('ai-history error:', err);
    return res.status(500).json({ error: err.message });
  }
}

// NOTE: GET /api/ai-history/:id to fetch a single saved analysis is handled by the
// same file via req.query when ?id= is provided in the frontend.
