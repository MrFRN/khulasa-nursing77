// AI Lab Interpretation — flags out-of-range results and explains clinical significance.
import { trackTool } from './ai-track.js';
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const RANGES = {
  hb: [13, 17, 'g/dL', 'Hemoglobin (adult male).'],
  hgb: [13, 17, 'g/dL', 'Hemoglobin (adult male).'],
  wbc: [4, 11, '10³/µL', 'White blood cell count.'],
  plt: [150, 400, '10³/µL', 'Platelets.'],
  sodium: [135, 145, 'mmol/L', 'Serum sodium.'],
  na: [135, 145, 'mmol/L', 'Serum sodium.'],
  potassium: [3.5, 5.0, 'mmol/L', 'Serum potassium.'],
  k: [3.5, 5.0, 'mmol/L', 'Serum potassium.'],
  chloride: [98, 106, 'mmol/L', 'Serum chloride.'],
  cl: [98, 106, 'mmol/L', 'Serum chloride.'],
  bicarb: [22, 28, 'mmol/L', 'Serum bicarbonate (HCO3-).'],
  hco3: [22, 28, 'mmol/L', 'Serum bicarbonate.'],
  glucose: [70, 100, 'mg/dL', 'Fasting glucose.'],
  urea: [15, 45, 'mg/dL', 'Blood urea nitrogen.'],
  bun: [7, 20, 'mg/dL', 'Blood urea nitrogen.'],
  creatinine: [0.7, 1.3, 'mg/dL', 'Serum creatinine (adult male).'],
  cr: [0.7, 1.3, 'mg/dL', 'Serum creatinine (adult male).'],
  sodium: [135, 145, 'mmol/L', 'Serum sodium.'],
  potassium: [3.5, 5.0, 'mmol/L', 'Serum potassium.'],
  calcium: [8.5, 10.5, 'mg/dL', 'Total calcium.'],
  ca: [8.5, 10.5, 'mg/dL', 'Total calcium.'],
  magnesium: [1.7, 2.2, 'mg/dL', 'Serum magnesium.'],
  mg: [1.7, 2.2, 'mg/dL', 'Serum magnesium.'],
  phosphorus: [2.5, 4.5, 'mg/dL', 'Serum phosphorus.'],
  phos: [2.5, 4.5, 'mg/dL', 'Serum phosphorus.'],
  troponin: [0, 0.04, 'ng/mL', 'High-sensitivity troponin.'],
  ck_mb: [0, 5, 'ng/mL', 'Creatine kinase-MB.'],
  alt: [7, 56, 'U/L', 'Alanine aminotransferase.'],
  ast: [10, 40, 'U/L', 'Aspartate aminotransferase.'],
  alp: [44, 147, 'U/L', 'Alkaline phosphatase.'],
  ggt: [0, 30, 'U/L', 'Gamma-glutamyl transferase.'],
  bilirubin: [0.1, 1.2, 'mg/dL', 'Total bilirubin.'],
  direct_bilirubin: [0, 0.3, 'mg/dL', 'Direct bilirubin.'],
  albumin: [3.5, 5.0, 'g/dL', 'Serum albumin.'],
  total_protein: [6.0, 8.3, 'g/dL', 'Total protein.'],
  crp: [0, 5, 'mg/L', 'C-reactive protein (low risk <5).'],
  esr: [0, 20, 'mm/h', 'Erythrocyte sedimentation rate (adult male).'],
  d_dimer: [0, 0.5, 'µg/mL FEU', 'D-dimer (VTE workup).'],
  lactate: [0.5, 1.6, 'mmol/L', 'Venous lactate.'],
  hba1c: [4, 5.6, '%', 'HbA1c (normal).'],
  inr: [0.8, 1.2, '', 'INR (normal).'],
  ptt: [25, 35, 'sec', 'aPTT.'],
  pt: [11, 13.5, 'sec', 'Prothrombin time.'],
  ferritin: [30, 400, 'ng/mL', 'Ferritin (adult male).'],
  iron: [60, 170, 'µg/dL', 'Serum iron.'],
  tibc: [240, 450, 'µg/dL', 'Total iron-binding capacity.'],
  vitamin_d: [30, 100, 'ng/mL', '25-hydroxyvitamin D.'],
  vitamin_b12: [200, 900, 'pg/mL', 'Vitamin B12.'],
  folate: [2.7, 17, 'ng/mL', 'Serum folate.'],
  tsh: [0.4, 4.0, 'mIU/L', 'Thyroid-stimulating hormone.'],
  free_t4: [0.8, 1.8, 'ng/dL', 'Free thyroxine.'],
  free_t3: [2.3, 4.2, 'pg/mL', 'Free triiodothyronine.'],
  ph: [7.35, 7.45, '', 'Arterial pH.'],
  pco2: [35, 45, 'mmHg', 'PaCO2.'],
  po2: [80, 100, 'mmHg', 'PaO2.'],
  hco3: [22, 26, 'mmol/L', 'Bicarbonate.'],
  lactate: [0.5, 1.6, 'mmol/L', 'Venous lactate.'],
  magnesium: [1.7, 2.2, 'mg/dL', 'Magnesium.'],
  uric_acid: [3.5, 7.2, 'mg/dL', 'Uric acid (adult male).'],
  anion_gap: [8, 12, 'mmol/L', 'Anion gap.'],
  osmolality: [275, 295, 'mOsm/kg', 'Serum osmolality.'],
  ammonia: [15, 45, 'µmol/L', 'Venous ammonia.'],
  lactate: [0.5, 1.6, 'mmol/L', 'Venous lactate.'],
  lipase: [0, 160, 'U/L', 'Lipase.'],
  amylase: [30, 110, 'U/L', 'Amylase.'],
  cortisol: [5, 23, 'µg/dL', 'AM cortisol.'],
  acth: [10, 60, 'pg/mL', 'ACTH.'],
  amylase: [30, 110, 'U/L', 'Amylase.'],
  lipase: [0, 160, 'U/L', 'Lipase.'],
};

const NOTES = {
  hb: { hi: 'Polycythemia: dehydration, polycythemia vera, COPD, high altitude.',
         lo: 'Anemia: consider iron deficiency, B12/folate deficiency, hemolysis, chronic disease.' },
  hgb: { hi: 'Polycythemia.', lo: 'Anemia.' },
  wbc: { hi: 'Leukocytosis: infection, inflammation, steroids, hematologic malignancy.',
         lo: 'Leukopenia: viral infection, bone marrow suppression, autoimmune.' },
  plt: { hi: 'Thrombocytosis: reactive (infection, iron deficiency) or essential thrombocythemia.',
         lo: 'Thrombocytopenia: ITP, drugs, sepsis, marrow failure — risk of bleeding.' },
  sodium: { hi: 'Hypernatremia: dehydration, diabetes insipidus, salt overload.',
            lo: 'Hyponatremia: hypovolemic, euvolemic (SIADH), hypervolemic (CHF, cirrhosis).' },
  na: { hi: 'Hypernatremia.', lo: 'Hyponatremia.' },
  potassium: { hi: 'Hyperkalemia: renal failure, K-sparing diuretics, acidosis, rhabdomyolysis.',
               lo: 'Hypokalemia: diuretics, vomiting, diarrhea, alkalosis.' },
  k: { hi: 'Hyperkalemia.', lo: 'Hypokalemia.' },
  chloride: { hi: 'Hyperchloremia.', lo: 'Hypochloremia.' },
  cl: { hi: 'Hyperchloremia.', lo: 'Hypochloremia.' },
  bicarb: { hi: 'Metabolic alkalosis.', lo: 'Metabolic acidosis.' },
  hco3: { hi: 'Metabolic alkalosis.', lo: 'Metabolic acidosis.' },
  glucose: { hi: 'Hyperglycemia: diabetes, stress, steroids.',
             lo: 'Hypoglycemia: insulin, sulfonylureas, sepsis, adrenal insufficiency.' },
  urea: { hi: 'Prerenal azotemia.', lo: 'Low-protein diet, liver disease.' },
  bun: { hi: 'Prerenal azotemia.', lo: 'Low-protein diet, liver disease.' },
  creatinine: { hi: 'AKI / CKD.', lo: 'Low muscle mass, advanced liver disease.' },
  cr: { hi: 'AKI / CKD.', lo: 'Low muscle mass.' },
  calcium: { hi: 'Hypercalcemia: hyperparathyroidism, malignancy, vitamin D excess.',
             lo: 'Hypocalcemia: hypoparathyroidism, vitamin D deficiency, CKD.' },
  ca: { hi: 'Hypercalcemia.', lo: 'Hypocalcemia.' },
  magnesium: { hi: 'Hypermagnesemia: renal failure, Mg-containing antacids.',
               lo: 'Hypomagnesemia: diuretics, alcoholism, malabsorption.' },
  mg: { hi: 'Hypermagnesemia.', lo: 'Hypomagnesemia.' },
  phosphorus: { hi: 'Hyperphosphatemia: renal failure, hypoparathyroidism.',
                lo: 'Hypophosphatemia: refeeding, vitamin D deficiency, hyperparathyroidism.' },
  phos: { hi: 'Hyperphosphatemia.', lo: 'Hypophosphatemia.' },
  troponin: { hi: 'Myocardial injury: acute coronary syndrome; consider NSTEMI/MI.', lo: 'Normal.' },
  ck_mb: { hi: 'Myocardial injury.', lo: 'Normal.' },
  alt: { hi: 'Hepatocellular injury, hepatitis, fatty liver, drugs.', lo: 'Vitamin B6 deficiency, advanced liver disease.' },
  ast: { hi: 'Hepatocellular injury, also muscle/cardiac.', lo: 'Liver disease, malnutrition.' },
  alp: { hi: 'Cholestasis, bone disease, infiltrative.', lo: 'Hypophosphatasia, zinc deficiency.' },
  ggt: { hi: 'Cholestasis, alcohol.', lo: 'Normal.' },
  bilirubin: { hi: 'Hemolysis, cholestasis, hepatitis.',
                lo: 'Anemia, low production.' },
  direct_bilirubin: { hi: 'Cholestasis.', lo: 'Normal.' },
  albumin: { hi: 'Dehydration.', lo: 'Malnutrition, liver disease, nephrotic, sepsis.' },
  total_protein: { hi: 'Chronic inflammation, paraproteinemia.', lo: 'Malnutrition, liver disease.' },
  crp: { hi: 'Inflammation, infection, malignancy.', lo: 'Normal.' },
  esr: { hi: 'Inflammation, infection, malignancy.', lo: 'Normal.' },
  d_dimer: { hi: 'VTE, DIC, infection, pregnancy, malignancy.',
             lo: 'Normal.' },
  lactate: { hi: 'Lactic acidosis: sepsis, hypoperfusion, metformin, cyanide.',
             lo: 'Normal.' },
  hba1c: { hi: 'Diabetes mellitus (≥6.5%).', lo: 'Normal.' },
  inr: { hi: 'Liver disease, warfarin, DIC.', lo: 'Normal.' },
  ptt: { hi: 'Heparin effect, factor deficiency, antiphospholipid.', lo: 'Factor deficiency, hypercoagulable.' },
  pt: { hi: 'Liver disease, warfarin, vitamin K deficiency.', lo: 'Normal/vitamin K excess.' },
  ferritin: { hi: 'Acute phase, hemochromatosis, malignancy.', lo: 'Iron deficiency, anemia of chronic disease.' },
  iron: { hi: 'Hemochromatosis, iron overload.', lo: 'Iron deficiency.' },
  tibc: { hi: 'Iron overload.', lo: 'Iron deficiency.' },
  vitamin_d: { hi: 'Vitamin D toxicity.', lo: 'Vitamin D deficiency; osteomalacia, rickets.' },
  vitamin_b12: { hi: 'Hepatitis, leukemia.', lo: 'B12 deficiency: macrocytic anemia, neuropathy.' },
  folate: { hi: 'B12 deficiency (compensatory).', lo: 'Folate deficiency: macrocytic anemia.' },
  tsh: { hi: 'Hypothyroidism (TSH high).', lo: 'Hyperthyroidism (TSH low; consider subclinical).' },
  free_t4: { hi: 'Hyperthyroidism.', lo: 'Hypothyroidism.' },
  free_t3: { hi: 'Hyperthyroidism.', lo: 'Hypothyroidism.' },
  ph: { hi: 'Alkalosis.', lo: 'Acidosis.' },
  pco2: { hi: 'Respiratory acidosis, metabolic alkalosis.', lo: 'Respiratory alkalosis, metabolic acidosis.' },
  po2: { hi: 'High FiO2, hyperventilation.', lo: 'Hypoxemia, respiratory failure, V/Q mismatch.' },
  magnesium: { hi: 'Hypermagnesemia.', lo: 'Hypomagnesemia.' },
  uric_acid: { hi: 'Gout, renal failure, tumor lysis.', lo: 'Uricosuric therapy, Wilson disease.' },
  anion_gap: { hi: 'High AG metabolic acidosis (MUDPILES).', lo: 'Hyperchloremic acidosis.' },
  osmolality: { hi: 'Dehydration, hyperglycemia, ingestion of osmoles.', lo: 'Hyponatremia, ADH excess.' },
  ammonia: { hi: 'Liver failure, inborn errors.', lo: 'Normal.' },
  lipase: { hi: 'Acute pancreatitis, biliary obstruction.', lo: 'Normal.' },
  amylase: { hi: 'Acute pancreatitis, salivary gland disease.', lo: 'Normal.' },
  cortisol: { hi: 'Cushing, stress response.', lo: 'Addison, adrenal insufficiency.' },
  acth: { hi: 'Cushing disease, ectopic ACTH.', lo: 'Secondary adrenal insufficiency.' },
};

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const user = await getUser(req);
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const labs = b.labs || {};
    const results = [];
    for (const key of Object.keys(labs)) {
      const k = key.toLowerCase();
      const range = RANGES[k];
      if (!range) continue;
      const value = parseFloat(labs[key]);
      if (Number.isNaN(value)) continue;
      const [lo, hi, unit, desc] = range;
      let flag = 'normal';
      let note = '';
      if (value < lo) flag = 'low';
      else if (value > hi) flag = 'high';
      const n = NOTES[k];
      if (n) note = flag === 'high' ? n.hi : (flag === 'low' ? n.lo : lang === 'ar' ? 'طبيعي' : 'Normal');
      results.push({
        name: k,
        value,
        unit,
        range: `${lo}-${hi} ${unit || ''}`.trim(),
        flag,
        note,
        description: desc,
      });
    }
    const summary = lang === 'ar'
      ? 'مراجعة دقيقة في السياق السريري. لا يستبدل التحليل الكامل.'
      : 'Carefully interpret in clinical context. This does not replace full clinical correlation.';
    await trackTool('lab', ip, user?.id || null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'هذه الأداة لأغراض تعليمية فقط.' : 'This tool is for educational purposes only.',
      lang, summary, results,
    });
  } catch (err) {
    console.error('ai-lab error:', err);
    return res.status(500).json({ error: err.message });
  }
}
