import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import PublicLayout from '../components/PublicLayout';
import Breadcrumb from '../components/Breadcrumb';
import FilterBar from '../components/FilterBar';
import ResourceCard from '../components/ResourceCard';
import Pagination from '../components/Pagination';
import { SkeletonGrid } from '../components/CardSkeleton';
import { SearchX } from 'lucide-react';
import { fetchResources } from '../lib/api';
import { SECTIONS } from '../lib/constants';
import type { Resource } from '../types';

const PER_PAGE = 12;

export default function SearchResults() {
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const [input, setInput] = useState(q);
  const [all, setAll] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [sectionFilter, setSectionFilter] = useState('');
  const [sort, setSort] = useState('popular');
  const [page, setPage] = useState(1);

  useEffect(() => { setInput(q); }, [q]);
  useEffect(() => {
    setLoading(true);
    fetchResources(q ? { search: q } : {})
      .then(setAll).catch(() => {}).finally(() => setLoading(false));
  }, [q]);
  useEffect(() => { setPage(1); }, [sectionFilter, sort, q]);

  const filtered = useMemo(() => {
    let r = all;
    if (sectionFilter) r = r.filter((x) => x.section === sectionFilter);
    r = [...r].sort((a, b) => {
      switch (sort) {
        case 'newest': return +new Date(b.created_at) - +new Date(a.created_at);
        case 'title': return a.title.localeCompare(b.title, 'ar');
        default: return b.download_count - a.download_count;
      }
    });
    return r;
  }, [all, sectionFilter, sort]);

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const pageItems = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <PublicLayout>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Breadcrumb items={[{ label: 'البحث' }]} />
        <h1 className="mb-6 mt-6 text-2xl font-extrabold text-slate-900 dark:text-white sm:text-3xl">
          {q ? <>نتائج البحث عن: <span className="text-primary">{q}</span></> : 'ابحث في المكتبة'}
        </h1>

        <FilterBar
          search={input}
          onSearch={(v) => { setInput(v); setParams(v ? { q: v } : {}); }}
          filters={[{ key: 'section', placeholder: 'كل الأقسام', value: sectionFilter, options: Object.values(SECTIONS).map((s) => ({ value: s.key, label: s.label })), onChange: setSectionFilter }]}
          sort={sort}
          onSort={setSort}
          sortOptions={[
            { value: 'popular', label: 'الأكثر تحميلًا' },
            { value: 'newest', label: 'الأحدث' },
            { value: 'title', label: 'الاسم' },
          ]}
        />

        <div className="mt-6">
          {loading ? <SkeletonGrid count={8} /> : filtered.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 py-20 text-center text-slate-500 dark:border-white/10">
              <SearchX className="h-12 w-12 text-slate-300" />
              <p className="font-semibold text-slate-700 dark:text-slate-200">لا توجد نتائج</p>
              <p className="text-sm">جرّب كلمات مفتاحية أخرى.</p>
            </div>
          ) : (
            <>
              <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">{filtered.length} نتيجة</p>
              <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
                {pageItems.map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
              </div>
              <Pagination page={page} totalPages={totalPages} onChange={(p) => { setPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />
            </>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}
