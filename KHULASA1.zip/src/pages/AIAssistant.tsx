import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowRight, Check, ClipboardList, FileText,
  FlaskConical, GraduationCap, MessageSquare, Pill, BookOpen,
  Sparkles, Stethoscope, Calculator,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const TOOLS = [
  { num: 1, key: 'clinical', icon: Activity, title_en: 'AI Clinical Assistant', title_ar: 'المساعد السريري بالذكاء الاصطناعي', desc_en: 'Full clinical case analysis (NANDA, drugs, lab, ECG, evidence).', desc_ar: 'تحليل سريري شامل.', to: '/clinical-assistant', accent: 'from-sky-500 to-indigo-600', tag_en: 'Clinical Reasoning' },
  { num: 2, key: 'care-plan', icon: ClipboardList, title_en: 'AI Care Plan Generator', title_ar: 'مولِّد خطة الرعاية', desc_en: 'Structured nursing care plan (NANDA + Goals + NIC + Evaluation).', to: '/ai-assistant/care-plan', accent: 'from-primary to-primary-600', tag_en: 'Care Planning' },
  { num: 3, key: 'calculator', icon: Calculator, title_en: 'Nursing Calculator', title_ar: 'حاسبات التمريض', desc_en: 'BMI, eGFR, CHA2DS2-VASc, HAS-BLED, Wells, CURB-65, qSOFA, MAP and more.', to: '/ai-assistant/calculator', accent: 'from-secondary to-secondary-600', tag_en: 'Clinical Calculations' },
  { num: 4, key: 'interview', icon: MessageSquare, title_en: 'Interview Simulator', title_ar: 'محاكي المقابلات', desc_en: 'ICU / ER / HR role-play with STAR feedback scoring.', to: '/ai-assistant/interview', accent: 'from-indigo-500 to-purple-600', tag_en: 'Behavioral' },
  { num: 5, key: 'pdf', icon: FileText, title_en: 'AI PDF Chat', title_ar: 'محادثة PDF', desc_en: 'Ask questions about any PDF from your library.', to: '/ai-assistant/pdf', accent: 'from-rose-500 to-pink-600', tag_en: 'Document AI' },
  { num: 6, key: 'chat', icon: MessageSquare, title_en: 'AI Chat Bot', title_ar: 'روبوت الدردشة', desc_en: 'Evidence-based medical chat with clinical analysis.', to: '/ai-assistant/chat', accent: 'from-amber-500 to-orange-500', tag_en: 'Conversational AI' },
  { num: 7, key: 'dictionary', icon: BookOpen, title_en: 'AI Medical Dictionary', title_ar: 'القاموس الطبي', desc_en: 'Bilingual medical dictionary with abbreviations.', to: '/ai-assistant/dictionary', accent: 'from-cyan-500 to-sky-600', tag_en: 'Reference' },
  { num: 8, key: 'ecg', icon: Activity, title_en: 'AI ECG Interpreter', title_ar: 'مفسر تخطيط القلب', desc_en: 'Free-text ECG interpretation with red flags.', to: '/ai-assistant/ecg', accent: 'from-red-500 to-rose-600', tag_en: 'Cardiac' },
  { num: 9, key: 'lab', icon: FlaskConical, title_en: 'AI Lab Interpretation', title_ar: 'مفسر التحاليل', desc_en: 'Batch-flag and explain out-of-range lab results.', to: '/ai-assistant/lab', accent: 'from-purple-500 to-fuchsia-600', tag_en: 'Diagnostics' },
  { num: 10, key: 'drug', icon: Pill, title_en: 'AI Drug Assistant', title_ar: 'مساعد الأدوية', desc_en: 'Drug lookup with high-yield interaction checking.', to: '/ai-assistant/drug', accent: 'from-teal-500 to-emerald-600', tag_en: 'Pharmacology' },
  { num: 11, key: 'exam', icon: GraduationCap, title_en: 'NCLEX Exam', title_ar: 'امتحان NCLEX', desc_en: 'AI-generated NCLEX-style MCQs with rationale and answers.', to: '/ai-assistant/exam', accent: 'from-pink-500 to-rose-500', tag_en: 'Board Review' },
];

const FEATURES: Record<string, string[]> = {
  clinical: [
    'Comprehensive case analysis (NANDA, drugs, labs, ECG, evidence)',
    'Real-time grading with red-flag alerts',
    'Evidence-graded recommendations with citations',
  ],
  'care-plan': [
    'NANDA-I diagnosis + Goals + NIC interventions + Evaluation',
    'Patient safety + reassessment framework',
    'Printable PDF + copy to clipboard',
  ],
  calculator: [
    'BMI, eGFR (CKD-EPI), CHA2DS2-VASc, HAS-BLED',
    'Wells (DVT/PE), CURB-65, qSOFA, MAP',
    'Drug-dose, fluid-balance, corrected Na+/Ca2+',
  ],
  case: [
    '40+ specialties × 20 cases each (800+ clinical scenarios)',
    '8-10 evidence-based MCQs per case with instant feedback',
    'Instant feedback + mistake review + final score',
  ],
  interview: [
    'ICU, ER, HR scenarios with role-play',
    'STAR-method feedback and scoring',
    'Random scenario picker for varied practice',
  ],
  pdf: [
    'Ask any PDF from your library',
    'Server-side text extraction + in-memory retrieval',
    'Evidence-cited answers from the source document',
  ],
  chat: [
    'Evidence-based medical chat with clinical analysis',
    'Bilingual EN/AR with full Arabic medical content',
    'Drug interaction awareness + safety flags',
  ],
  dictionary: [
    '649 bilingual medical terms + abbreviations',
    'Definitions with context and usage',
    'Cross-reference with related terms',
  ],
  ecg: [
    'Free-text ECG description analysis',
    'Systematic red-flag identification',
    'Real-time warnings for dangerous patterns',
  ],
  lab: [
    'Batch interpretation of out-of-range labs',
    'Clinical significance and next steps',
    'Pediatric and adult reference ranges',
  ],
  drug: [
    'Comprehensive drug lookup',
    'High-yield interaction checking',
    'Pediatric and adult dosing',
  ],
  exam: [
    'NCLEX-RN style MCQs across categories',
    'Instant rationale + citations',
    'Score tracking and review',
  ],
};

export default function AIAssistant() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy">
      <Navbar />

      <section id="top" className="border-b border-slate-200 bg-gradient-to-br from-primary/10 via-white to-secondary/10 dark:border-white/10 dark:from-primary/20 dark:via-navy-800 dark:to-secondary/20">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">
                <Sparkles className="h-3.5 w-3.5" /> AI Assistant Suite
              </span>
              <h1 className="mt-4 text-3xl font-extrabold leading-tight text-slate-900 dark:text-white sm:text-4xl">
                11 Clinical AI Tools
              </h1>
              <p className="mt-3 max-w-xl text-base text-slate-600 dark:text-slate-300">
                Evidence-based clinical tools — care plans, calculators, NCLEX exam, ECG / lab interpreters, drug lookup, PDF chat and interview practice.
              </p>
              <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
                <AlertTriangle className="h-3 w-3" /> Educational only. Does not replace professional medical evaluation.
              </p>
            </div>
            <div className="relative hidden lg:block">
              <div className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-br from-primary/30 to-secondary/30 blur-3xl" />
              <div className="relative grid grid-cols-3 gap-3 rounded-[2rem] border border-white/60 bg-white/40 p-5 shadow-2xl backdrop-blur dark:border-white/10 dark:bg-white/5">
                {TOOLS.map((t) => (
                  <div key={t.key} className="flex items-center gap-2 rounded-xl bg-white/80 p-2 shadow-sm dark:bg-white/10">
                    <span className="text-[10px] font-bold text-slate-400">#{t.num}</span>
                    <span className={`flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br ${t.accent} text-white`}>
                      <t.icon className="h-3 w-3" />
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="space-y-10">
          {TOOLS.map((t, i) => (
            <Section key={t.key} tool={t} index={i} />
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}

function Section({ tool, index }: { tool: any; index: number }) {
  return (
    <motion.section
      id={`section-${tool.num}`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.45, delay: 0.05 }}
      className="scroll-mt-24"
    >
      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl dark:border-white/10 dark:bg-white/5">
        <div className="flex flex-col gap-6 p-6 md:flex-row md:p-8 lg:p-10 lg:gap-10">
          <div className="flex shrink-0 flex-row items-start gap-5 md:flex-col md:items-center md:gap-3 lg:w-56">
            <div className={`flex h-20 w-20 shrink-0 items-center justify-center rounded-3xl bg-gradient-to-br ${tool.accent} text-white shadow-xl lg:h-28 lg:w-28`}>
              <tool.icon className="h-9 w-9 lg:h-12 lg:w-12" />
            </div>
            <div className="flex flex-col">
              <div className="text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                Section {tool.num} of 12
              </div>
              <div className="mt-1 inline-flex items-center gap-1 self-start rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">
                <span className={`h-1.5 w-1.5 rounded-full bg-gradient-to-r ${tool.accent}`} />
                {tool.tag_en}
              </div>
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-extrabold text-slate-300 dark:text-slate-700">
                #{String(tool.num).padStart(2, '0')}
              </span>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white sm:text-2xl">
                {tool.title_en}
              </h2>
            </div>
            <p className="mt-3 text-base leading-relaxed text-slate-600 dark:text-slate-300">
              {tool.desc_en}
            </p>

            {(FEATURES[tool.key] || []).length > 0 && (
              <ul className="mt-4 grid gap-2 sm:grid-cols-3">
                {FEATURES[tool.key].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 rounded-lg bg-slate-50 px-2 py-1.5 text-xs text-slate-700 dark:bg-white/5 dark:text-slate-300">
                    <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                    <span className="leading-tight">{f}</span>
                  </li>
                ))}
              </ul>
            )}

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Link
                to={tool.to}
                className={`inline-flex items-center gap-2 rounded-xl bg-gradient-to-r ${tool.accent} px-5 py-2.5 text-sm font-bold text-white shadow-md transition hover:opacity-95`}
              >
                Open {tool.title_en}
                <ArrowRight className="h-4 w-4" />
              </Link>
              <a
                href={`#section-${tool.num < 12 ? tool.num + 1 : 1}`}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-bold text-slate-700 hover:border-sky-500 hover:text-sky-600 dark:border-white/10 dark:text-slate-200"
              >
                {tool.num < 12 ? 'Next section' : 'Top'}
                <span className="text-xs opacity-70">→ {tool.num < 12 ? `#${tool.num + 1}` : '#1'}</span>
              </a>
              <a href="#top" className="ml-auto text-[10px] font-bold uppercase tracking-wide text-slate-400 hover:text-sky-500">
                ↑ Back to top
              </a>
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  );
}
