// Case-Based Nursing Clinical Judgment - complete rewrite
// NCLEX-style clinical judgment with evidence-based questions
import { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowLeft, ArrowRight, Award, BookOpen,
  Brain, Calculator as CalcIcon, Check, ChevronLeft, ChevronRight,
  ClipboardList, Clock, ExternalLink, Eye, Filter, Flame, Globe, Heart,
  HeartPulse, History as HistoryIcon, Home, Lightbulb, Loader2, Lock,
  MessageSquare, RefreshCw, RotateCcw, Search, Shield, ShieldCheck,
  Sparkles, Stethoscope, Sun, Target, Timer, TrendingUp, Trophy, X, Zap,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useToast } from '../components/Toast';
import { useTheme } from '../contexts/ThemeContext';

type Lang = 'en' | 'ar';

interface MCQQuestion {
  id: number;
  position: number;
  category: string | null;
  stem: string;
  options: { A: string; B: string; C: string; D: string };
  correct: string;
  explanation: string;
  why_wrong: { A: string; B: string; C: string; D: string };
  reference_label: string | null;
  reference_url: string | null;
}

interface MCQCase {
  id: number; slug: string; title: string; condition: string;
  specialty: string; difficulty: string;
  patient: {
    age: number; gender: string;
    chief_complaint: string; history: string;
    symptoms: string[]; allergies: string[]; medications: any[];
    vitals: any; labs: any; physical_exam: string; narrative_intro: string;
  };
  questions: MCQQuestion[];
  references: any[];
  learning_points: string[];
  source_url: string | null; guideline_version: string | null;
}

interface GradeResult {
  case_id: number; case_title: string; condition: string;
  score: number; total: number; percentage: number;
  level_key: string; level: any;
  learning_points: string[]; references: any[];
  source_url: string | null; guideline_version: string | null;
  weak_topics: Record<string, number>;
  correct_count: number; incorrect_count: number;
  mistakes: Array<{
    position: number; stem: string;
    user_answer: string | null; correct_answer: string;
    options: { A: string; B: string; C: string; D: string };
    explanation: string;
    why_wrong: { A: string; B: string; C: string; D: string };
    reference: { label: string | null; url: string | null };
    category: string | null;
  }>;
  disclaimer: string;
}

const SPECIALTY_META: Record<string, { en: string; ar: string; icon: string; gradient: string }> = {
  'medical': { en: 'Medical / Internal Medicine', ar: 'الطب الباطني', icon: 'Stethoscope', gradient: 'from-sky-500 to-indigo-600' },
  'medical-surgical': { en: 'Medical-Surgical', ar: 'الباطنية والجراحية', icon: 'ClipboardList', gradient: 'from-teal-500 to-emerald-600' },
  'emergency': { en: 'Emergency', ar: 'الطوارئ', icon: 'Zap', gradient: 'from-amber-500 to-orange-500' },
  'icu': { en: 'ICU / Critical Care', ar: 'ICU / الحرجة', icon: 'Brain', gradient: 'from-indigo-500 to-purple-600' },
  'cardiology': { en: 'Cardiac / CCU', ar: 'القلب / CCU', icon: 'HeartPulse', gradient: 'from-rose-500 to-red-500' },
  'cardiac-catheterization': { en: 'Cardiac Catheterization', ar: 'قسطرة القلب', icon: 'HeartPulse', gradient: 'from-red-500 to-pink-500' },
  'nephrology': { en: 'Renal / Nephrology', ar: 'الكلى', icon: 'Droplet', gradient: 'from-blue-500 to-cyan-500' },
  'hemodialysis': { en: 'Hemodialysis', ar: 'غسيل الكلى الدموي', icon: 'Droplet', gradient: 'from-violet-500 to-purple-500' },
  'peritoneal-dialysis': { en: 'Peritoneal Dialysis', ar: 'الغسيل البريتوني', icon: 'Droplet', gradient: 'from-purple-500 to-fuchsia-500' },
  'respiratory': { en: 'Respiratory', ar: 'الجهاز التنفسي', icon: 'Activity', gradient: 'from-sky-500 to-blue-500' },
  'neurological': { en: 'Neurology / Stroke', ar: 'الأعصاب / السكتة', icon: 'Brain', gradient: 'from-purple-500 to-indigo-500' },
  'surgical': { en: 'Surgical', ar: 'الجراحة', icon: 'ClipboardList', gradient: 'from-cyan-500 to-teal-500' },
  'operating-room': { en: 'Operating Room', ar: 'غرفة العمليات', icon: 'Stethoscope', gradient: 'from-slate-500 to-zinc-500' },
  'obstetric': { en: 'Obstetrics / Maternity', ar: 'النسائية والتوليد', icon: 'Heart', gradient: 'from-pink-400 to-rose-500' },
  'gynecology': { en: 'Gynecology', ar: 'النسائية', icon: 'Heart', gradient: 'from-rose-400 to-pink-500' },
  'pediatrics': { en: 'Pediatrics', ar: 'الأطفال', icon: 'Heart', gradient: 'from-pink-500 to-rose-500' },
  'nicu': { en: 'NICU', ar: 'NICU', icon: 'Heart', gradient: 'from-fuchsia-500 to-pink-500' },
  'picu': { en: 'PICU', ar: 'PICU', icon: 'Heart', gradient: 'from-fuchsia-500 to-rose-500' },
  'psychiatric': { en: 'Psychiatric', ar: 'الطب النفسي', icon: 'Brain', gradient: 'from-indigo-500 to-purple-500' },
  'geriatrics': { en: 'Geriatric', ar: 'كبار السن', icon: 'Heart', gradient: 'from-amber-400 to-orange-400' },
  'oncology': { en: 'Oncology', ar: 'الأورام', icon: 'ShieldCheck', gradient: 'from-pink-500 to-rose-600' },
  'endocrine': { en: 'Endocrine', ar: 'الغدد الصماء', icon: 'Sparkles', gradient: 'from-emerald-500 to-cyan-500' },
  'gastrointestinal': { en: 'GI', ar: 'الجهاز الهضمي', icon: 'Stethoscope', gradient: 'from-amber-500 to-yellow-500' },
  'infectious-diseases': { en: 'Infectious Disease', ar: 'الأمراض المعدية', icon: 'Shield', gradient: 'from-emerald-600 to-teal-600' },
  'hematology': { en: 'Hematology', ar: 'أمراض الدم', icon: 'Heart', gradient: 'from-red-500 to-rose-500' },
  'orthopedic': { en: 'Orthopedic', ar: 'العظام', icon: 'ClipboardList', gradient: 'from-slate-500 to-blue-500' },
  'trauma': { en: 'Trauma', ar: 'الرضوح', icon: 'ShieldCheck', gradient: 'from-red-600 to-orange-500' },
  'burns': { en: 'Burn Nursing', ar: 'تمريض الحروق', icon: 'Flame', gradient: 'from-orange-500 to-red-600' },
  'community-health': { en: 'Community Health', ar: 'صحة المجتمع', icon: 'Home', gradient: 'from-green-500 to-emerald-500' },
  'wound-care': { en: 'Wound Care', ar: 'العناية بالجروح', icon: 'ShieldCheck', gradient: 'from-pink-400 to-rose-500' },
  'palliative-care': { en: 'Palliative Care', ar: 'الرعاية التلطيفية', icon: 'Heart', gradient: 'from-violet-400 to-purple-500' },
  'home-health': { en: 'Home Health', ar: 'الرعاية المنزلية', icon: 'Home', gradient: 'from-emerald-400 to-teal-500' },
  'rehabilitation': { en: 'Rehabilitation', ar: 'التأهيل', icon: 'Activity', gradient: 'from-cyan-500 to-blue-500' },
  'ccu': { en: 'CCU', ar: 'CCU', icon: 'HeartPulse', gradient: 'from-rose-600 to-red-600' },
  'pain-management': { en: 'Pain Management', ar: 'إدارة الألم', icon: 'Activity', gradient: 'from-orange-500 to-red-500' },
  'infection-control': { en: 'Infection Control', ar: 'مكافحة العدوى', icon: 'Shield', gradient: 'from-cyan-500 to-blue-600' },
  'wound-care': { en: 'Wound Care', ar: 'العناية بالجروح', icon: 'ShieldCheck', gradient: 'from-pink-400 to-rose-500' },
  'palliative-care': { en: 'Palliative Care', ar: 'الرعاية التلطيفية', icon: 'Heart', gradient: 'from-violet-400 to-purple-500' },
  'home-health': { en: 'Home Health', ar: 'الرعاية المنزلية', icon: 'Home', gradient: 'from-emerald-400 to-teal-500' },
};

const ICONS_MAP: Record<string, any> = {
  Activity, AlertTriangle, ArrowLeft, ArrowRight, Award, BookOpen, Brain,
  CalcIcon, Check, ChevronLeft, ChevronRight, ClipboardList, Clock,
  ExternalLink, Eye, Filter, Flame, Globe, Heart, HeartPulse, HistoryIcon,
  Home, Lightbulb, Loader2, Lock, MessageSquare, RefreshCw, RotateCcw,
  Search, Shield, ShieldCheck, Sparkles, Stethoscope, Sun, Target, Timer,
  TrendingUp, Trophy, X, Zap,
};

// =====================================================================
// MAIN PAGE
// =====================================================================
export default function CaseSimulation() {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('cs-lang') as Lang) || 'en');
  const [view, setView] = useState<'lobby' | 'play' | 'result'>('lobby');
  const [cases, setCases] = useState<any[]>([]);
  const [specialtyCounts, setSpecialtyCounts] = useState<Record<string, number>>({});
  const [activeSpecialty, setActiveSpecialty] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [activeCase, setActiveCase] = useState<MCQCase | null>(null);
  const [gradeResult, setGradeResult] = useState<GradeResult | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { dark } = useTheme();
  const isAr = lang === 'ar';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try { localStorage.setItem('cs-lang', lang); } catch { /* ignore */ }
    document.title = isAr
      ? 'الحكم السريري التمريضي القائم على MCQ | الخلاصة'
      : 'Case-Based Nursing Clinical Judgment | Khulasa';
  }, [lang, isAr]);

  useEffect(() => { loadCases(); }, [activeSpecialty, search, lang, view]);

  async function loadCases() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('sort', 'featured');
      params.set('lang', lang);
      params.set('page', '1');
      params.set('pageSize', '50');
      if (activeSpecialty !== 'all') params.set('specialty', activeSpecialty);
      if (search) params.set('search', search);
      const res = await fetch('/api/mcq-list?' + params.toString());
      const data = await res.json();
      setCases(data.items || []);
      if (Object.keys(specialtyCounts).length === 0) {
        try {
          const all = await fetch('/api/mcq-list?sort=featured&pageSize=200&lang=' + lang);
          const d = await all.json();
          const m: Record<string, number> = {};
          for (const c of d.items || []) m[c.specialty] = (m[c.specialty] || 0) + 1;
          setSpecialtyCounts(m);
        } catch { /* ignore */ }
      }
    } catch { /* ignore */ }
    setLoading(false);
  }

  async function startCase(slug: string) {
    try {
      const res = await fetch('/api/mcq-start', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setActiveCase(data.case);
      setGradeResult(null);
      setView('play');
    } catch (e: any) { toast(e.message || 'Failed', 'error'); }
  }

  async function startRandom() {
    try {
      const res = await fetch('/api/mcq-start', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ random: 1, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setActiveCase(data.case);
      setGradeResult(null);
      setView('play');
    } catch (e: any) { toast(e.message || 'Failed', 'error'); }
  }

  if (view === 'play' && activeCase) {
    return (
      <MCQPlayView
        lang={lang} setLang={setLang}
        caseData={activeCase}
        onBack={() => setView('lobby')}
        onComplete={(r) => { setGradeResult(r); setView('result'); }}
        onRandom={startRandom}
      />
    );
  }
  if (view === 'result' && gradeResult) {
    return (
      <MCQResultView
        lang={lang} setLang={setLang}
        result={gradeResult}
        onTryAgain={() => activeCase && startCase(activeCase.slug)}
        onRandom={startRandom}
        onBackToLobby={() => setView('lobby')}
      />
    );
  }
  return (
    <LobbyView
      lang={lang} setLang={setLang}
      cases={cases} loading={loading}
      specialtyCounts={specialtyCounts}
      activeSpecialty={activeSpecialty} setActiveSpecialty={setActiveSpecialty}
      search={search} setSearch={setSearch}
      onStart={startCase}
      onRandom={startRandom}
    />
  );
}

// =====================================================================
// LOBBY: Specialty cards + Cases grid
// =====================================================================
function LobbyView(props: any) {
  const {
    lang, setLang, cases, loading, specialtyCounts,
    activeSpecialty, setActiveSpecialty,
    search, setSearch, onStart, onRandom,
  } = props;
  const isAr = lang === 'ar';

  const sortedSpecialties = Object.entries(specialtyCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 40);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy">
      <Navbar />

      <section id="top" className="border-b border-slate-200 bg-gradient-to-br from-primary/10 via-white to-secondary/10 dark:border-white/10 dark:from-primary/20 dark:via-navy-800 dark:to-secondary/20">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">
                <Sparkles className="h-3.5 w-3.5" /> Case-Based Nursing Clinical Judgment
              </span>
              <h1 className="mt-4 text-3xl font-extrabold leading-tight text-slate-900 dark:text-white sm:text-4xl">
                {isAr ? 'الحكم السريري التمريضي القائم على MCQ' : 'Case-Based Nursing Clinical Judgment'}
              </h1>
              <p className="mt-3 max-w-xl text-base text-slate-600 dark:text-slate-300">
                {isAr
                  ? 'حالات سريرية واقعية مع أسئلة MCQ متصلة على نمط NCLEX، وتعليم فوري قائم على الأدلة.'
                  : 'Realistic clinical cases with connected NCLEX-style MCQs and instant evidence-based teaching.'}
              </p>
              <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
                <AlertTriangle className="h-3 w-3" /> {isAr ? 'للأغراض التعليمية فقط. لا يحل محل الحكم السريري.' : 'Educational use only. Does not replace clinical judgment.'}
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button onClick={onRandom} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-primary to-secondary px-5 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 transition hover:opacity-95">
                  <Sparkles className="h-4 w-4" /> {isAr ? 'حالة عشوائية' : 'Random Case'}
                </button>
                <div className="relative w-full max-w-md">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isAr ? 'ابحث في المكتبة...' : 'Search library...'} className="w-full rounded-2xl border border-slate-200 bg-white/80 px-10 py-3 text-sm shadow-sm backdrop-blur focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30 dark:border-white/10 dark:bg-white/5" />
                </div>
                <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 text-sm font-semibold backdrop-blur hover:border-primary dark:border-white/10 dark:bg-white/5">
                  <Globe className="h-4 w-4" /> {isAr ? 'English' : 'العربية'}
                </button>
              </div>
            </div>
            <div className="relative hidden lg:block">
              <div className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-br from-primary/30 to-secondary/30 blur-3xl" />
              <div className="relative grid grid-cols-3 gap-3 rounded-[2rem] border border-white/60 bg-white/40 p-5 shadow-2xl backdrop-blur dark:border-white/10 dark:bg-white/5">
                {Object.entries(specialtyCounts).slice(0, 9).map(([k, n], i) => {
                  const meta = SPECIALTY_META[k] || { en: k, ar: k, icon: 'Stethoscope', gradient: 'from-slate-500 to-slate-700' };
                  const Icon = ICONS_MAP[meta.icon] || Stethoscope;
                  return (
                    <div key={i} className="flex items-center gap-2 rounded-xl bg-white/80 p-2 shadow-sm dark:bg-white/10">
                      <span className={`flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br ${meta.gradient} text-white`}>
                        <Icon className="h-3 w-3" />
                      </span>
                      <span className="text-[10px] font-bold text-slate-700 dark:text-slate-200">{meta.en.split(' / ')[0]}</span>
                      <span className="text-[10px] text-slate-400">({n})</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveSpecialty('all')}
            className={`rounded-full px-3 py-1.5 text-xs font-bold transition ${activeSpecialty === 'all' ? 'bg-gradient-to-r from-primary to-secondary text-white shadow' : 'border border-slate-200 hover:border-primary dark:border-white/10'}`}
          >
            {isAr ? 'كل التخصصات' : 'All Specialties'} ({Object.values(specialtyCounts).reduce((a: number, b: number) => a + b, 0)})
          </button>
          {sortedSpecialties.slice(0, 14).map(([key, count]) => {
            const meta = SPECIALTY_META[key] || { en: key, ar: key, icon: 'Stethoscope', gradient: 'from-slate-500 to-slate-700' };
            const Icon = ICONS_MAP[meta.icon] || Stethoscope;
            const active = activeSpecialty === key;
            return (
              <button
                key={key}
                onClick={() => setActiveSpecialty(active ? 'all' : key)}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition ${active ? `bg-gradient-to-r ${meta.gradient} text-white shadow` : 'border border-slate-200 hover:border-primary dark:border-white/10'}`}
              >
                <Icon className="h-3.5 w-3.5" /> {meta.en.split(' / ')[0]} <span className="opacity-70">{count}</span>
              </button>
            );
          })}
        </div>

        {loading ? (
          <div className="py-12 text-center text-sm text-slate-500 dark:text-slate-400">
            <Loader2 className="mx-auto mb-2 h-6 w-6 animate-spin" /> {isAr ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : cases.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-sm text-slate-500 dark:border-white/10">
            {isAr ? 'لا توجد حالات تطابق المرشحات.' : 'No cases match the filters.'}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {cases.map((c: any) => {
              const meta = SPECIALTY_META[c.specialty] || { en: c.specialty, ar: c.specialty, icon: 'Stethoscope', gradient: 'from-slate-500 to-slate-700' };
              const Icon = ICONS_MAP[meta.icon] || Stethoscope;
              return (
                <button
                  key={c.id}
                  onClick={() => onStart(c.slug)}
                  className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 text-start shadow-sm backdrop-blur transition hover:-translate-y-1 hover:border-primary/50 hover:shadow-xl dark:border-white/10 dark:bg-white/5"
                >
                  <div className={`absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br ${meta.gradient} opacity-15 blur-2xl transition group-hover:opacity-30`} />
                  <div className="relative mb-3 flex items-center justify-between">
                    <div className={`inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${meta.gradient} text-white shadow`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">
                      {c.difficulty}
                    </span>
                  </div>
                  <div className="relative text-sm font-bold text-slate-900 dark:text-white">{c.title_en}</div>
                  <div className="relative mt-1 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">{c.condition_en}</div>
                  <div className="relative mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-[10px] text-slate-400 dark:border-white/10">
                    <span>{c.patient_age}y · {c.patient_gender}</span>
                    <span className="font-bold text-primary group-hover:translate-x-1 transition">→</span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
}

// =====================================================================
// PLAY VIEW - one question at a time with instant feedback
// =====================================================================
function MCQPlayView({ lang, setLang, caseData, onBack, onComplete, onRandom }: {
  lang: Lang; setLang: (l: Lang) => void;
  caseData: MCQCase; onBack: () => void;
  onComplete: (r: GradeResult) => void;
  onRandom: () => void;
}) {
  const isAr = lang === 'ar';
  const questions = caseData.questions || [];
  const total = questions.length;
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});
  const [submitting, setSubmitting] = useState(false);
  const [startTime] = useState<number>(Date.now());
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 1000)), 1000);
    return () => clearInterval(t);
  }, [startTime]);

  const q = questions[idx];
  const answeredCount = Object.keys(answers).length;

  function pick(qid: number, letter: string) {
    if (revealed[qid]) return;
    setAnswers((a) => ({ ...a, [qid]: letter }));
    setRevealed((r) => ({ ...r, [qid]: true }));
  }

  async function submit() {
    setSubmitting(true);
    try {
      const res = await fetch('/api/mcq-grade', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caseId: caseData.id, answers, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      onComplete(data);
    } catch (e: any) { alert(e.message || 'Failed'); }
    finally { setSubmitting(false); }
  }

  if (!q) {
    return (
      <div className="py-12 text-center text-sm text-slate-500 dark:text-slate-400">
        {isAr ? 'لا توجد أسئلة لهذه الحالة.' : 'No questions for this case.'}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white/80 p-4 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-bold hover:border-rose-500 hover:text-rose-500 dark:border-white/10">
              <ArrowLeft className="h-3.5 w-3.5" /> {isAr ? 'خروج' : 'Exit'}
            </button>
            <div>
              <div className="text-sm font-bold">{isAr ? caseData.title_ar : caseData.title_en}</div>
              <div className="text-[10px] text-slate-500">{isAr ? caseData.condition_ar : caseData.condition_en}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
              {isAr ? `سؤال ${idx + 1} / ${total}` : `Q ${idx + 1} / ${total}`}
            </span>
            <span className="rounded-full bg-violet-100 px-2 py-0.5 font-bold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
              {isAr ? `تم ${answeredCount}` : `${answeredCount} done`}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">
              <Clock className="h-3 w-3" /> {Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, '0')}
            </span>
            <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 font-semibold hover:border-primary dark:border-white/10">
              {isAr ? 'EN' : 'AR'}
            </button>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-12">
          <aside className="space-y-4 lg:col-span-4">
            <PatientCard caseData={caseData} lang={lang} />
          </aside>

          <section className="lg:col-span-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={q.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="rounded-3xl border border-slate-200 bg-white/80 p-5 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5"
              >
                <div className="mb-1 text-[10px] font-bold uppercase tracking-wide text-violet-600 dark:text-violet-400">
                  {isAr ? `السؤال ${idx + 1} من ${total}` : `Question ${idx + 1} of ${total}`}{q.category ? ` · ${q.category}` : ''}
                </div>
                <div className="mb-4 text-base font-bold leading-relaxed">{q.stem}</div>
                <div className="grid gap-2">
                  {(['A', 'B', 'C', 'D'] as const).map((L) => {
                    const isPicked = answers[q.id] === L;
                    const isRevealed = !!revealed[q.id];
                    const isCorrectAnswer = isRevealed && isPicked && q.correct === L;
                    const isWrongAnswer = isRevealed && isPicked && q.correct !== L;
                    const text = q.options[L];
                    return (
                      <button
                        key={L}
                        onClick={() => pick(q.id, L)}
                        disabled={isRevealed}
                        className={`group flex items-start gap-3 rounded-2xl border p-3 text-start text-sm transition ${
                          isCorrectAnswer
                            ? 'border-emerald-500 bg-emerald-50 dark:border-emerald-500/60 dark:bg-emerald-500/10'
                            : isWrongAnswer
                            ? 'border-rose-500 bg-rose-50 dark:border-rose-500/60 dark:bg-rose-500/10'
                            : isPicked
                            ? 'border-sky-500 bg-sky-50 dark:border-sky-500/60 dark:bg-sky-500/10'
                            : 'border-slate-200 bg-white hover:border-sky-500 dark:border-white/10 dark:bg-white/5'
                        } ${isRevealed && !isPicked && !isCorrectAnswer ? 'opacity-80' : ''}`}
                      >
                        <span className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                          isCorrectAnswer ? 'bg-emerald-500 text-white'
                          : isWrongAnswer ? 'bg-rose-500 text-white'
                          : isPicked ? 'bg-sky-500 text-white'
                          : 'bg-slate-200 text-slate-700 dark:bg-white/10 dark:text-slate-300'
                        }`}>{L}</span>
                        <span className="flex-1 pt-1">{text}</span>
                        {isCorrectAnswer && <Check className="mt-1 h-5 w-5 text-emerald-500" />}
                        {isWrongAnswer && <X className="mt-1 h-5 w-5 text-rose-500" />}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {revealed[q.id] && <FeedbackBlock q={q} isAr={isAr} />}

            <div className="mt-4 flex items-center justify-between gap-3">
              <button onClick={() => setIdx(Math.max(0, idx - 1))} disabled={idx === 0} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold disabled:opacity-50 dark:border-white/10">
                <ChevronLeft className="h-4 w-4" /> {isAr ? 'السابق' : 'Previous'}
              </button>
              {idx < total - 1 ? (
                <button onClick={() => setIdx(Math.min(total - 1, idx + 1))} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 px-5 py-2 text-sm font-bold text-white shadow-md">
                  {isAr ? 'التالي' : 'Next'} <ChevronRight className="h-4 w-4" />
                </button>
              ) : (
                <button onClick={submit} disabled={submitting || answeredCount < total} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-2 text-sm font-bold text-white shadow-md disabled:opacity-50">
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trophy className="h-4 w-4" />}
                  {isAr ? 'إنهاء وتقديم' : 'Finish & Submit'}
                </button>
              )}
            </div>
            {answeredCount < total && idx === total - 1 && (
              <p className="mt-2 text-center text-xs text-amber-700 dark:text-amber-300">
                {isAr
                  ? `أجبت على ${answeredCount} من ${total}. أجب على الباقي قبل التقديم.`
                  : `Answered ${answeredCount}/${total}. Answer remaining questions before submitting.`}
              </p>
            )}
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}

function FeedbackBlock({ q, isAr }: { q: MCQQuestion; isAr: boolean }) {
  return (
    <div className="mt-3 rounded-2xl border border-emerald-300 bg-emerald-50/80 p-4 text-sm dark:border-emerald-500/30 dark:bg-emerald-500/10">
      <div className="mb-2 inline-flex items-center gap-1.5 font-bold text-emerald-700 dark:text-emerald-300">
        <Check className="h-4 w-4" /> {isAr ? 'الإجابة الصحيحة' : 'Correct answer'}: <strong className="ms-1">{q.correct}</strong>
        <span className="ms-2 text-xs font-normal text-slate-700 dark:text-slate-300">{q.options[q.correct as keyof typeof q.options]}</span>
      </div>
      {q.explanation && (
        <div className="mb-2">
          <div className="mb-0.5 inline-flex items-center gap-1.5 text-xs font-bold text-sky-700 dark:text-sky-300">
            <Lightbulb className="h-3.5 w-3.5" /> {isAr ? 'الشرح ولماذا هو صحيح' : 'Explanation & why correct'}
          </div>
          <p className="ms-5 text-xs leading-relaxed text-slate-700 dark:text-slate-300">{q.explanation}</p>
        </div>
      )}
      {(q.why_wrong?.A || q.why_wrong?.B || q.why_wrong?.C || q.why_wrong?.D) && (
        <div className="mb-2">
          <div className="mb-1 inline-flex items-center gap-1.5 text-xs font-bold text-rose-700 dark:text-rose-300">
            <AlertTriangle className="h-3.5 w-3.5" /> {isAr ? 'لماذا الخيارات الأخرى أقل ملاءمة' : 'Why other options are less appropriate'}
          </div>
          <div className="ms-5 grid gap-1 text-[11px]">
            {(['A', 'B', 'C', 'D'] as const).filter((L) => L !== q.correct).map((L) => (
              <div key={L} className="rounded-lg bg-rose-50/60 px-2 py-1 dark:bg-rose-500/5">
                <strong className="text-rose-700 dark:text-rose-300">{L}.</strong>{' '}
                <span className="text-slate-700 dark:text-slate-300">{q.options[L]}</span>
                {q.why_wrong[L] && (
                  <div className="ms-4 text-slate-500 dark:text-slate-400">— {q.why_wrong[L]}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
      {q.reference_url && (
        <a href={q.reference_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 hover:underline dark:text-emerald-300">
          <ExternalLink className="h-3 w-3" /> {q.reference_label || 'Source'}
        </a>
      )}
    </div>
  );
}

function PatientCard({ caseData, lang }: { caseData: MCQCase; lang: Lang }) {
  const isAr = lang === 'ar';
  const p = caseData.patient;
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 shadow-lg backdrop-blur dark:border-white/10 dark:bg-white/5">
      <div className="mb-2 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-primary dark:text-primary-300">
        <Heart className="h-3.5 w-3.5" /> {isAr ? 'الحالة السريرية' : 'Clinical Case'}
      </div>
      <div className="text-sm font-bold">{isAr ? 'مريض' : 'Patient'} {p.age}y {p.gender}</div>
      <div className="mt-1 text-xs text-slate-600 dark:text-slate-400"><strong>{isAr ? 'الشكوى' : 'CC'}:</strong> {p.chief_complaint}</div>
      <div className="mt-1 text-xs text-slate-600 dark:text-slate-400"><strong>{isAr ? 'التاريخ' : 'HPI'}:</strong> {p.history}</div>
      {p.symptoms && p.symptoms.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {p.symptoms.map((s: string, i: number) => (
            <span key={i} className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">{s}</span>
          ))}
        </div>
      )}
      {p.vitals && (
        <div className="mt-3 rounded-xl bg-slate-50 p-2 dark:bg-white/5">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-wide text-rose-600 dark:text-rose-400">{isAr ? 'العلامات الحيوية' : 'Vital Signs'}</div>
          <div className="grid grid-cols-3 gap-1 text-[11px]">
            {Object.entries(p.vitals).slice(0, 9).map(([k, v]: any) => (
              <div key={k} className="rounded bg-white px-2 py-0.5 text-center font-bold shadow-sm dark:bg-slate-900">
                <div className="text-[9px] uppercase text-slate-500">{k}</div>
                <div>{String(v)}</div>
              </div>
            ))}
          </div>
        </div>
      )}
      {p.physical_exam && (
        <div className="mt-2 text-[11px] text-slate-600 dark:text-slate-400"><strong>{isAr ? 'الفحص' : 'Exam'}:</strong> {p.physical_exam}</div>
      )}
      {p.labs && Object.keys(p.labs).length > 0 && (
        <div className="mt-2 text-[11px] text-slate-600 dark:text-slate-400"><strong>{isAr ? 'التحاليل' : 'Labs'}:</strong> {Object.entries(p.labs).map(([k, v]: any) => `${k}=${v}`).join(', ')}</div>
      )}
      {p.allergies && p.allergies.length > 0 && (
        <div className="mt-2 text-[11px] text-slate-600 dark:text-slate-400"><strong>{isAr ? 'الحساسية' : 'Allergies'}:</strong> {p.allergies.join(', ')}</div>
      )}
      {p.medications && p.medications.length > 0 && (
        <div className="mt-2 text-[11px] text-slate-600 dark:text-slate-400"><strong>{isAr ? 'الأدوية' : 'Meds'}:</strong> {(p.medications || []).map((m: any) => typeof m === 'string' ? m : `${m.name} ${m.dose || ''}`).join('; ')}</div>
      )}
      {p.narrative_intro && (
        <div className="mt-2 rounded-xl bg-sky-50/70 p-2 text-[11px] italic text-slate-700 dark:bg-sky-500/10 dark:text-slate-200">{p.narrative_intro}</div>
      )}
    </div>
  );
}

// =====================================================================
// RESULT VIEW - score + mistakes + learning points + references
// =====================================================================
function MCQResultView({ lang, setLang, result, onTryAgain, onRandom, onBackToLobby }: {
  lang: Lang; setLang: (l: Lang) => void;
  result: GradeResult;
  onTryAgain: () => void;
  onRandom: () => void;
  onBackToLobby: () => void;
}) {
  const isAr = lang === 'ar';
  const mistakes = result.mistakes || [];
  const strongTopics: string[] = [];
  Object.entries(result.strong_topics || {}).forEach(([k, _v]) => strongTopics.push(k));
  const weakTopicsArr: Array<[string, number]> = Object.entries(result.weak_topics || {});

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />
      <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-2xl backdrop-blur dark:border-white/10 dark:bg-white/5">
          <div className="text-center">
            <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-300">
              <Trophy className="h-3.5 w-3.5" /> {isAr ? 'النتيجة النهائية' : 'Final Result'}
            </div>
            <h1 className="text-2xl font-extrabold sm:text-3xl">{isAr ? result.case_title : result.case_title}</h1>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{isAr ? result.condition : result.condition}</p>

            <div className="mx-auto mt-6 inline-flex items-center gap-4 rounded-3xl bg-gradient-to-br from-sky-50 via-white to-emerald-50 p-6 shadow-lg dark:from-sky-500/10 dark:via-slate-900 dark:to-emerald-500/10">
              <div className="text-center">
                <div className="text-5xl font-extrabold text-sky-600 dark:text-sky-300">{result.percentage}%</div>
                <div className="mt-1 text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'النتيجة' : 'Score'}</div>
              </div>
              <div className="h-12 w-px bg-slate-200 dark:bg-white/10" />
              <div className="text-center">
                <div className="text-2xl font-bold text-slate-700 dark:text-slate-200">{result.score}/{result.total}</div>
                <div className="mt-1 text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'صحيحة' : 'Correct'}</div>
              </div>
              <div className="h-12 w-px bg-slate-200 dark:bg-white/10" />
              <div className="text-center">
                <div className={`text-2xl font-bold ${result.percentage >= 75 ? 'text-emerald-600 dark:text-emerald-300' : result.percentage >= 60 ? 'text-amber-600 dark:text-amber-300' : 'text-rose-600 dark:text-rose-300'}`}>
                  {isAr ? result.level.ar : result.level.en}
                </div>
                <div className="mt-1 text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'المستوى' : 'Level'}</div>
              </div>
            </div>

            <div className="mx-auto mt-3 grid max-w-md grid-cols-2 gap-3 text-xs">
              <div className="rounded-xl bg-emerald-50 p-2 dark:bg-emerald-500/10">
                <div className="font-bold text-emerald-700 dark:text-emerald-300">{isAr ? 'صحيحة' : 'Correct'}: {result.correct_count}</div>
              </div>
              <div className="rounded-xl bg-rose-50 p-2 dark:bg-rose-500/10">
                <div className="font-bold text-rose-700 dark:text-rose-300">{isAr ? 'خاطئة' : 'Incorrect'}: {result.incorrect_count}</div>
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-emerald-300 bg-emerald-50/70 p-3 text-start dark:border-emerald-500/30 dark:bg-emerald-500/10">
              <div className="mb-1 inline-flex items-center gap-1.5 font-bold text-emerald-700 dark:text-emerald-300">
                <ShieldCheck className="h-3.5 w-3.5" /> {isAr ? 'نقاط القوة' : 'Strong Areas'}
              </div>
              {strongTopics.length > 0 ? (
                <ul className="ms-4 list-disc space-y-0.5 text-xs">
                  {strongTopics.map((t, i) => <li key={i}>{t}</li>)}
                </ul>
              ) : (
                <div className="text-xs text-slate-500">{isAr ? 'لا توجد بيانات' : 'N/A'}</div>
              )}
            </div>
            <div className="rounded-2xl border border-amber-300 bg-amber-50/70 p-3 text-start dark:border-amber-500/30 dark:bg-amber-500/10">
              <div className="mb-1 inline-flex items-center gap-1.5 font-bold text-amber-700 dark:text-amber-300">
                <Lightbulb className="h-3.5 w-3.5" /> {isAr ? 'مجالات التحسين' : 'Areas to improve'}
              </div>
              {weakTopicsArr.length > 0 ? (
                <ul className="ms-4 list-disc space-y-0.5 text-xs">
                  {weakTopicsArr.map(([t, n]) => <li key={t}><strong>{t}</strong>: {n} {isAr ? 'أخطاء' : 'mistakes'}</li>)}
                </ul>
              ) : (
                <div className="text-xs text-slate-500">{isAr ? 'لا توجد مجالات للتحسين' : 'None — great job!'}</div>
              )}
            </div>
          </div>

          {mistakes.length > 0 && (
            <div className="mt-6">
              <div className="mb-3 inline-flex items-center gap-1.5 font-bold text-rose-700 dark:text-rose-300">
                <AlertTriangle className="h-3.5 w-3.5" /> {isAr ? 'مراجعة الأخطاء' : 'Review Mistakes'}
              </div>
              <div className="space-y-3 text-start">
                {mistakes.map((m, i) => (
                  <details key={i} className="rounded-2xl border border-slate-200 bg-white/60 p-3 dark:border-white/10 dark:bg-white/5">
                    <summary className="cursor-pointer text-sm font-bold">
                      <span className="me-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-xs text-white">{m.position}</span>
                      {m.stem}
                    </summary>
                    <div className="mt-2 space-y-2 text-xs">
                      <div className="rounded-lg bg-rose-50 p-2 dark:bg-rose-500/10">
                        <strong className="text-rose-700 dark:text-rose-300">{isAr ? 'إجابتك' : 'Your answer'}: </strong>
                        <span className="ms-1">{m.user_answer || '—'} — {m.options[m.user_answer as keyof typeof m.options] || '—'}</span>
                      </div>
                      <div className="rounded-lg bg-emerald-50 p-2 dark:bg-emerald-500/10">
                        <strong className="text-emerald-700 dark:text-emerald-300">{isAr ? 'الصحيحة' : 'Correct'}: </strong>
                        <span className="ms-1">{m.correct_answer} — {m.options[m.correct_answer as keyof typeof m.options]}</span>
                      </div>
                      <div className="rounded-lg bg-sky-50 p-2 dark:bg-sky-500/10">
                        <strong className="text-sky-700 dark:text-sky-300">{isAr ? 'الشرح' : 'Explanation'}: </strong>
                        <span className="ms-1">{m.explanation}</span>
                      </div>
                      {m.why_wrong?.A && (
                        <details className="rounded-lg bg-rose-50/50 p-2 dark:bg-rose-500/5">
                          <summary className="cursor-pointer text-xs font-bold text-rose-700 dark:text-rose-300">{isAr ? 'لماذا الخيارات الأخرى أقل ملاءمة' : 'Why other options are less appropriate'}</summary>
                          <ul className="ms-4 mt-1 list-disc space-y-0.5 text-[11px]">
                            {(['A', 'B', 'C', 'D'] as const).filter((L) => L !== m.correct_answer).map((L) => (
                              <li key={L}><strong>{L}.</strong> {m.options[L]} — {m.why_wrong[L]}</li>
                            ))}
                          </ul>
                        </details>
                      )}
                      {m.reference?.url && (
                        <a href={m.reference.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 hover:underline dark:text-emerald-300">
                          <ExternalLink className="h-3 w-3" /> {m.reference.label || 'Source'}
                        </a>
                      )}
                    </div>
                  </details>
                ))}
              </div>
            </div>
          )}

          {result.learning_points && result.learning_points.length > 0 && (
            <div className="mt-6 rounded-2xl border border-sky-300 bg-sky-50/70 p-4 text-start dark:border-sky-500/30 dark:bg-sky-500/10">
              <div className="mb-2 inline-flex items-center gap-1.5 font-bold text-sky-700 dark:text-sky-300">
                <Lightbulb className="h-3.5 w-3.5" /> {isAr ? 'نقاط التعلم الرئيسية' : 'Key Learning Points'}
              </div>
              <ul className="ms-4 list-disc space-y-1 text-xs text-slate-700 dark:text-slate-200">
                {result.learning_points.map((lp, i) => <li key={i}>{lp}</li>)}
              </ul>
            </div>
          )}

          {result.references && result.references.length > 0 && (
            <div className="mt-3 rounded-2xl border border-slate-200 bg-white/70 p-3 text-start text-xs dark:border-white/10 dark:bg-white/5">
              <div className="mb-1 inline-flex items-center gap-1.5 font-bold">
                <BookOpen className="h-3.5 w-3.5" /> {isAr ? 'المراجع العلمية' : 'Scientific References'}
              </div>
              <ul className="space-y-0.5">
                {result.references.map((r: any, i: number) => (
                  <li key={i} className="flex items-start gap-1">
                    <ExternalLink className="mt-0.5 h-3 w-3 shrink-0 text-sky-500" />
                    <a href={r.url} target="_blank" rel="noreferrer" className="hover:underline"><strong>{r.abbr}</strong> — {r.title}</a>
                  </li>
                ))}
              </ul>
              {result.guideline_version && (
                <div className="mt-1 text-[10px] text-slate-500">{isAr ? 'الإصدار' : 'Guideline'}: {result.guideline_version}</div>
              )}
            </div>
          )}

          <div className="mt-4 rounded-xl border border-amber-300/40 bg-amber-50/70 p-2 text-[10px] text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
            <AlertTriangle className="me-1 inline h-3 w-3" /> {result.disclaimer}
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button onClick={onTryAgain} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 px-5 py-2 text-sm font-bold text-white shadow">
              <RotateCcw className="h-4 w-4" /> {isAr ? 'حاول مرة أخرى' : 'Try Again'}
            </button>
            <button onClick={onRandom} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-2 text-sm font-bold text-white shadow">
              <Sparkles className="h-4 w-4" /> {isAr ? 'حالة عشوائية' : 'Random Case'}
            </button>
            <button onClick={onBackToLobby} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2 text-sm font-bold hover:border-primary dark:border-white/10">
              <ArrowLeft className="h-4 w-4" /> {isAr ? 'العودة للمكتبة' : 'Back to Library'}
            </button>
            <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2 text-sm font-bold hover:border-primary dark:border-white/10">
              {isAr ? 'English' : 'العربية'}
            </button>
          </div>
        </motion.div>
      </div>
      <Footer />
    </div>
  );
}
