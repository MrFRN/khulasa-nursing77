import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Download, Share2, Copy, Heart, Calendar, HardDrive, BookUser, BookMarked,
  GraduationCap, Tag, Eye, FileText,
} from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import Breadcrumb from '../components/Breadcrumb';
import ReadingProgress from '../components/ReadingProgress';
import PdfViewer from '../components/PdfViewer';
import FileTypeChip from '../components/FileTypeChip';
import ResourceCard from '../components/ResourceCard';
import Spinner from '../components/Spinner';
import { useToast } from '../components/Toast';
import { fetchResource, fetchResources, trackDownload, trackEvent, fetchChunks, assembleChunks, isMultipart } from '../lib/api';
import type { Chunk } from '../lib/api';
import { formatBytes, formatDate } from '../lib/format';
import { isPdfType, isImageType } from '../lib/filetypes';
import { isFavorite, toggleFavorite } from '../lib/favorites';
import { SECTIONS } from '../lib/constants';
import type { Resource } from '../types';

export default function ResourceDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const [resource, setResource] = useState<Resource | null>(null);
  const [related, setRelated] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [downloading, setDownloading] = useState(false);
  const [fav, setFav] = useState(false);
  const [chunks, setChunks] = useState<Chunk[]>([]);
  const [multiUrl, setMultiUrl] = useState('');
  const [assembling, setAssembling] = useState(false);
  const [assemblePct, setAssemblePct] = useState(0);
  const multi = resource ? isMultipart(resource) : false;

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    setError('');
    window.scrollTo({ top: 0 });
    fetchResource(id)
      .then((r) => {
        setResource(r);
        setFav(isFavorite(r.id));
        if (isMultipart(r)) fetchChunks(r.id).then(setChunks).catch(() => {});
        // Log a view only once per resource per session so heavy traffic
        // doesn't flood the database with writes.
        try {
          const k = `viewed-${r.id}`;
          if (!sessionStorage.getItem(k)) {
            sessionStorage.setItem(k, '1');
            trackEvent('view', `/resource/${r.id}`, r.id);
          }
        } catch {
          trackEvent('view', `/resource/${r.id}`, r.id);
        }
        fetchResources({ section: r.section, limit: '12' })
          .then((list) => setRelated(list.filter((x) => x.id !== r.id && x.category === r.category).slice(0, 4)))
          .catch(() => {});
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [id]);

  const handleDownload = async () => {
    if (!resource) return;
    setDownloading(true);
    try {
      if (multi) {
        const objUrl = await ensureAssembled();
        const a = document.createElement('a');
        a.href = objUrl; a.download = resource.file_name || resource.title;
        document.body.appendChild(a); a.click(); a.remove();
        trackDownload(resource.id).catch(() => {});
      } else {
        const { url, file_name } = await trackDownload(resource.id);
        const dl = url + (url.includes('?') ? '&' : '?') + 'download=' + encodeURIComponent(file_name || resource.title);
        const a = document.createElement('a');
        a.href = dl; a.rel = 'noopener';
        document.body.appendChild(a); a.click(); a.remove();
      }
      setResource({ ...resource, download_count: resource.download_count + 1 });
      toast('جارٍ التحميل…', 'success');
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setDownloading(false);
    }
  };

  const share = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try { await navigator.share({ title: resource?.title, url }); } catch { /* cancelled */ }
    } else {
      await navigator.clipboard.writeText(url);
      toast('تم نسخ الرابط', 'success');
    }
  };
  const copy = async () => { await navigator.clipboard.writeText(window.location.href); toast('تم نسخ الرابط', 'success'); };
  const onFav = () => { toggleFavorite(resource!.id); setFav(!fav); };

  const ensureAssembled = async (): Promise<string> => {
    if (multiUrl) return multiUrl;
    if (!resource || !chunks.length) throw new Error('تعذّر معاينة الملف');
    setAssembling(true); setAssemblePct(0);
    try {
      const blob = await assembleChunks(chunks, resource.file_type, (p) => setAssemblePct(p));
      const u = URL.createObjectURL(blob);
      setMultiUrl(u);
      return u;
    } finally { setAssembling(false); }
  };

  useEffect(() => () => { if (multiUrl) URL.revokeObjectURL(multiUrl); }, [multiUrl]);

  const section = resource ? SECTIONS[resource.section] : null;
  const canPreview = resource && (isPdfType(resource.file_type || resource.file_name) || isImageType(resource.file_type || resource.file_name));

  return (
    <PublicLayout>
      <ReadingProgress />
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {loading ? (
          <div className="flex justify-center py-24"><Spinner label="جارٍ التحميل…" /></div>
        ) : error || !resource ? (
          <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 py-24 text-center dark:border-white/10">
            <FileText className="h-12 w-12 text-slate-300" />
            <p className="font-bold text-slate-700 dark:text-slate-200">{error || 'حدث خطأ'}</p>
            <Link to="/" className="text-sm text-primary underline">العودة للرئيسية</Link>
          </div>
        ) : (
          <>
            <Breadcrumb items={[
              { label: section!.label, to: section!.path },
              ...(resource.category ? [{ label: resource.category, to: `${section!.path}/${resource.category}` }] : []),
              { label: resource.title },
            ]} />

            <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_360px]">
              {/* Preview */}
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="order-2 lg:order-1">
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-white/10 dark:bg-white/5">
                  {multi ? (
                    multiUrl ? (
                      <PdfViewer url={multiUrl} fileType={resource.file_type || resource.file_name} className="h-[75vh]" />
                    ) : (
                      <div className="flex h-[55vh] flex-col items-center justify-center gap-4 p-6 text-center text-slate-500 dark:text-slate-400">
                        <FileText className="h-12 w-12 text-slate-300" />
                        <p className="max-w-sm text-sm">ملف كبير مقسّم إلى أجزاء؛ جهّز المعاينة أو حمّل الملف مباشرة.</p>
                        {canPreview && (
                          <button onClick={() => ensureAssembled()} disabled={assembling} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-60">
                            {assembling ? `جارٍ التجهيز… ${assemblePct}%` : 'تجهيز المعاينة'}
                          </button>
                        )}
                      </div>
                    )
                  ) : canPreview ? (
                    <PdfViewer url={resource.file_url} fileType={resource.file_type || resource.file_name} className="h-[75vh]" />
                  ) : resource.cover_image_url ? (
                    <img src={resource.cover_image_url} alt={resource.title} className="max-h-[75vh] w-full object-contain" />
                  ) : (
                    <div className="flex h-[50vh] flex-col items-center justify-center gap-3 text-slate-400">
                      <FileText className="h-12 w-12" /><p className="text-sm">المعاينة غير متاحة — حمّل الملف للاطلاع.</p>
                    </div>
                  )}
                </div>
              </motion.div>

              {/* Sidebar */}
              <aside className="order-1 lg:order-2">
                <div className="lg:sticky lg:top-24">
                  <div className="mb-3 flex items-center gap-2">
                    <FileTypeChip name={resource.file_type || resource.file_name} />
                    {section && <span className="text-xs font-bold text-primary">{section.label}</span>}
                  </div>
                  <h1 className="text-2xl font-extrabold leading-tight tracking-tight text-slate-900 dark:text-white">{resource.title}</h1>
                  {resource.description && <p className="mt-3 leading-relaxed text-slate-600 dark:text-slate-300">{resource.description}</p>}

                  <div className="mt-5 flex gap-2">
                    <button onClick={handleDownload} disabled={downloading} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-4 py-3 font-semibold text-white shadow-lg shadow-primary/30 transition hover:opacity-90 disabled:opacity-60">
                      <Download className="h-4.5 w-4.5" /> {downloading ? 'جارٍ…' : 'تحميل'}
                    </button>
                    <button onClick={onFav} aria-label="مفضلة" className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-200 text-slate-500 transition hover:text-accent dark:border-white/10 dark:text-slate-300"><Heart className={`h-5 w-5 ${fav ? 'fill-accent text-accent' : ''}`} /></button>
                    <button onClick={share} aria-label="مشاركة" className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-200 text-slate-500 transition hover:text-primary dark:border-white/10 dark:text-slate-300"><Share2 className="h-5 w-5" /></button>
                    <button onClick={copy} aria-label="نسخ الرابط" className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-200 text-slate-500 transition hover:text-primary dark:border-white/10 dark:text-slate-300"><Copy className="h-5 w-5" /></button>
                  </div>

                  <dl className="mt-6 space-y-3 rounded-2xl border border-slate-200 bg-white p-4 text-sm dark:border-white/10 dark:bg-white/5">
                    <Row icon={<HardDrive className="h-4 w-4" />} label="الحجم" value={formatBytes(resource.file_size)} />
                    <Row icon={<Download className="h-4 w-4" />} label="التحميلات" value={String(resource.download_count)} />
                    {resource.subject && <Row icon={<BookMarked className="h-4 w-4" />} label="المادة" value={resource.subject} />}
                    {resource.year && <Row icon={<GraduationCap className="h-4 w-4" />} label="السنة" value={resource.year} />}
                    {resource.author && <Row icon={<BookUser className="h-4 w-4" />} label="المؤلف" value={resource.author} />}
                    {resource.edition && <Row icon={<Eye className="h-4 w-4" />} label="الإصدار" value={resource.edition} />}
                    <Row icon={<Calendar className="h-4 w-4" />} label="تاريخ الإضافة" value={formatDate(resource.created_at)} />
                  </dl>

                  {resource.tags && resource.tags.length > 0 && (
                    <div className="mt-4">
                      <div className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase text-slate-400"><Tag className="h-3.5 w-3.5" /> وسوم</div>
                      <div className="flex flex-wrap gap-2">
                        {resource.tags.map((t) => <span key={t} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs text-slate-600 dark:bg-white/10 dark:text-slate-300">{t}</span>)}
                      </div>
                    </div>
                  )}
                </div>
              </aside>
            </div>

            {related.length > 0 && (
              <section className="mt-16">
                <h2 className="mb-6 text-xl font-extrabold text-slate-900 dark:text-white">ملفات ذات صلة</h2>
                <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
                  {related.map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </PublicLayout>
  );
}

function Row({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="flex items-center gap-2 text-slate-500 dark:text-slate-400">{icon}{label}</span>
      <span className="font-semibold text-slate-800 dark:text-slate-100">{value}</span>
    </div>
  );
}
