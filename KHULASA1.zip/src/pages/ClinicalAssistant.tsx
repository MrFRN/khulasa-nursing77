import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, BrainCircuit, History as HistoryIcon, Loader2, Save, Search, ShieldCheck, Sparkles } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import SymptomPicker from '../components/SymptomPicker';
import ReportView from '../components/ReportView';
import { useToast } from '../components/Toast';
import { useAuth } from '../contexts/AuthContext';
import { analyzeCase, getAiHistory, getAiAnalysis, AiReport } from '../lib/api';

const input = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white';
const label = 'mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200';

const VITALS = [
  { k: 'temp', ar: 'Temperature', unit: '°C', ph: '37.0' },
  { k: 'sbp', ar: 'Systolic BP', unit: 'mmHg', ph: '120' },
  { k: 'dbp', ar: 'Diastolic BP', unit: 'mmHg', ph: '80' },
  { k: 'hr', ar: 'Heart Rate', unit: 'bpm', ph: '80' },
  { k: 'rr', ar: 'Respiratory Rate', unit: '/min', ph: '16' },
  { k: 'spo2', ar: 'Oxygen Saturation', unit: '%', ph: '98' },
  { k: 'glucose', ar: 'Blood Glucose', unit: 'mg/dL', ph: '100' },
];
const LABS = [
  { k: 'wbc', ar: 'WBC', unit: '10³/µL' }, { k: 'hgb', ar: 'Hemoglobin', unit: 'g/dL' },
  { k: 'plt', ar: 'Platelets', unit: '10³/µL' }, { k: 'crp', ar: 'CRP', unit: 'mg/L' },
  { k: 'esr', ar: 'ESR', unit: 'mm/h' }, { k: 'troponin', ar: 'Troponin', unit: 'ng/mL' },
  { k: 'lactate', ar: 'Lactate', unit: 'mmol/L' }, { k: 'd_dimer', ar: 'D-Dimer', unit: 'µg/mL' },
  { k: 'hba1c', ar: 'HbA1c', unit: '%' }, { k: 'glucose', ar: 'Fasting Glucose', unit: 'mg/dL' },
  { k: 'creatinine', ar: 'Creatinine', unit: 'mg/dL' }, { k: 'sodium', ar: 'Sodium', unit: 'mmol/L' },
  { k: 'potassium', ar: 'Potassium', unit: 'mmol/L' }, { k: 'inr', ar: 'INR', unit: '' },
  { k: 'amylase', ar: 'Amylase', unit: 'U/L' }, { k: 'lipase', ar: 'Lipase', unit: 'U/L' },
  { k: 'uric_acid', ar: 'Uric Acid', unit: 'mg/dL' }, { k: 'bilirubin', ar: 'Bilirubin', unit: 'mg/dL' },
  { k: 'alt', ar: 'ALT', unit: 'U/L' }, { k: 'ast', ar: 'AST', unit: 'U/L' },
];
const IMAGING = ['Chest X-ray', 'CT', 'MRI', 'Ultrasound', 'ECG', 'Echo', 'Other'];
const HISTORY = ['Diabetes', 'Hypertension', 'Heart disease', 'Asthma/COPD', 'Kidney disease', 'Liver disease', 'Cancer', 'Previous surgery', 'Immunocompromised'];

function Collapsible({ title, icon: Icon, children, defaultOpen = false }: { title: string; icon: any; children: React.ReactNode; defaultOpen?: boolean }) {
  const [o, setO] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/60 p-4 dark:border-white/10 dark:bg-white/5">
      <button type="button" onClick={() => setO(!o)} className="flex w-full items-center justify-between text-sm font-bold text-slate-800 dark:text-slate-100">
        <span className="flex items-center gap-2"><Icon className="h-4 w-4 text-primary" /> {title}</span>
        <span className="text-slate-400">{o ? '−' : '+'}</span>
      </button>
      {o && <div className="mt-3 space-y-3">{children}</div>}
    </div>
  );
}

export default function ClinicalAssistant() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [form, setForm] = useState<any>({ gender: '', smoking: '', symptoms: [], labs: {}, imaging: [], history: [] });
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<AiReport | null>(null);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [histList, setHistList] = useState<any[]>([]);
  const [histLoading, setHistLoading] = useState(false);
  const [lang, setLang] = useState<'en' | 'ar'>('en');
  const isAr = lang === 'ar';

  const set = (patch: any) => setForm((f: any) => ({ ...f, ...patch }));

  const analyze = async () => {
    if (!form.age || !form.gender || !form.chiefComplaint?.trim()) {
      toast(isAr ? 'الرجاء إدخال العمر والجنس والشكوى الرئيسية على الأقل' : 'Please provide age, gender and chief complaint.', 'error');
      return;
    }
    setLoading(true);
    try {
      const payload = {
        age: Number(form.age), gender: form.gender, height: form.height ? Number(form.height) : undefined,
        weight: form.weight ? Number(form.weight) : undefined, chiefComplaint: form.chiefComplaint, duration: form.duration,
        presentIllness: form.presentIllness, history: form.history, medications: form.medications, allergies: form.allergies,
        familyHistory: form.familyHistory, smoking: form.smoking, pregnancy: !!form.pregnancy,
        vitals: form.vitals || {}, symptoms: form.symptoms, labs: form.labs, imaging: form.imaging, lang,
      };
      const res = await analyzeCase(payload);
      setReport(res.report);
      setRemaining(res.remaining);
      toast(isAr ? 'تم تحليل الحالة' : 'Case analyzed', 'success');
      if (user && res.savedId) toast(isAr ? 'تم حفظ التحليل في سجلّك' : 'Saved to your history', 'success');
    } catch (e: any) {
      toast(e.message || (isAr ? 'تعذّر التحليل' : 'Analysis failed'), 'error');
    } finally { setLoading(false); }
  };

  const loadHistory = async () => {
    if (!user) { toast(isAr ? 'سجّل الدخول لعرض سجل التحليلات' : 'Log in to view your analysis history', 'error'); return; }
    setShowHistory(true); setHistLoading(true);
    try { setHistList(await getAiHistory()); } catch (e: any) { toast(e.message, 'error'); }
    finally { setHistLoading(false); }
  };
  const openSaved = async (id: number) => {
    try {
      const a = await getAiAnalysis(id);
      if (a?.report) { setReport(a.report); setShowHistory(false); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    } catch (e: any) { toast(e.message, 'error'); }
  };

  const saveCurrent = async () => {
    if (!report) return;
    if (!user) { toast(isAr ? 'سجّل الدخول لحفظ التحليل' : 'Log in to save this analysis', 'error'); return; }
    toast(isAr ? 'يتم حفظ التحليل تلقائياً عند الضغط على «تحليل الحالة»' : 'Analysis is saved automatically when you click Analyze (for logged-in users)', 'success');
  };

  const vitalsArr = useMemo(() => VITALS, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Hero */}
        <div className="mb-8 overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-br from-primary/10 via-white to-secondary/10 p-6 dark:border-white/10 dark:from-primary/20 dark:via-navy-800 dark:to-secondary/20">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-white shadow-lg"><BrainCircuit className="h-6 w-6" /></span>
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white sm:text-3xl">AI Clinical Assistant</h1>
                <p className="text-sm text-slate-500 dark:text-slate-300">Evidence-based Clinical Decision Support — for education only</p>
              </div>
            </div>
            <div className="flex items-center gap-1 rounded-full border border-slate-300 p-1 text-xs font-bold dark:border-white/10">
              <button onClick={() => setLang('en')} className={`rounded-full px-3 py-1 ${!isAr ? 'bg-primary text-white' : 'text-slate-500'}`}>EN</button>
              <button onClick={() => setLang('ar')} className={`rounded-full px-3 py-1 ${isAr ? 'bg-primary text-white' : 'text-slate-500'}`}>ع</button>
            </div>
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" />
            <span><strong>{report?.disclaimer || 'This tool is for educational purposes only and does not replace professional medical evaluation.'}</strong> It never provides a final diagnosis.</span>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Form */}
          <div className="space-y-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
              <h2 className="mb-4 flex items-center gap-2 font-bold text-slate-900 dark:text-white"><Activity className="h-5 w-5 text-primary" /> Patient Data</h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div className="col-span-1"><label className={label}>Age *</label><input type="number" className={input} value={form.age || ''} onChange={(e) => set({ age: e.target.value })} placeholder="years" /></div>
                <div className="col-span-1"><label className={label}>Gender *</label><select className={input} value={form.gender} onChange={(e) => set({ gender: e.target.value })}><option value="">—</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select></div>
                <div className="col-span-1"><label className={label}>Pregnancy</label><select className={input} value={form.pregnancy ? 'yes' : 'no'} onChange={(e) => set({ pregnancy: e.target.value === 'yes' })}><option value="no">No</option><option value="yes">Yes</option></select></div>
                <div><label className={label}>Height (cm)</label><input type="number" className={input} value={form.height || ''} onChange={(e) => set({ height: e.target.value })} /></div>
                <div><label className={label}>Weight (kg)</label><input type="number" className={input} value={form.weight || ''} onChange={(e) => set({ weight: e.target.value })} /></div>
                <div><label className={label}>Smoking</label><select className={input} value={form.smoking} onChange={(e) => set({ smoking: e.target.value })}><option value="">—</option><option value="never">Never</option><option value="current">Current</option><option value="former">Former</option></select></div>
              </div>
              <div className="mt-3"><label className={label}>Chief Complaint *</label><input className={input} value={form.chiefComplaint || ''} onChange={(e) => set({ chiefComplaint: e.target.value })} placeholder="e.g. chest pain and fever" /></div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <div><label className={label}>Duration of Symptoms</label><input className={input} value={form.duration || ''} onChange={(e) => set({ duration: e.target.value })} placeholder="e.g. 3 days" /></div>
                <div><label className={label}>Present Illness</label><input className={input} value={form.presentIllness || ''} onChange={(e) => set({ presentIllness: e.target.value })} /></div>
              </div>
            </div>

            <Collapsible title="Vital Signs" icon={Activity} defaultOpen>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {vitalsArr.map((v) => (
                  <div key={v.k}><label className={label}>{v.ar} ({v.unit})</label><input type="number" step="0.1" className={input} placeholder={v.ph} value={form.vitals?.[v.k] || ''} onChange={(e) => set({ vitals: { ...(form.vitals || {}), [v.k]: e.target.value } })} /></div>
                ))}
              </div>
            </Collapsible>

            <Collapsible title="Symptoms" icon={Sparkles} defaultOpen>
              <SymptomPicker value={form.symptoms || []} onChange={(v) => set({ symptoms: v })} />
            </Collapsible>

            <Collapsible title="Laboratory Results (optional)" icon={FlaskIcon}>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {LABS.map((l) => (
                  <div key={l.k}><label className={label}>{l.ar} {l.unit && `(${l.unit})`}</label><input type="number" step="0.01" className={input} value={form.labs?.[l.k]?.value || ''} onChange={(e) => set({ labs: { ...(form.labs || {}), [l.k]: { value: e.target.value, unit: l.unit } } })} /></div>
                ))}
              </div>
            </Collapsible>

            <Collapsible title="Imaging (optional)" icon={ScanIcon}>
              <div className="flex flex-wrap gap-2">
                {IMAGING.map((im) => {
                  const on = (form.imaging || []).includes(im);
                  return <button key={im} type="button" onClick={() => set({ imaging: on ? form.imaging.filter((x: string) => x !== im) : [...(form.imaging || []), im] })} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${on ? 'bg-primary text-white' : 'border border-slate-300 dark:border-white/10'}`}>{im}</button>;
                })}
              </div>
              <div className="mt-2"><label className={label}>Findings description</label><input className={input} value={form.imagingNote || ''} onChange={(e) => set({ imagingNote: e.target.value })} placeholder="e.g. left pleural effusion" /></div>
            </Collapsible>

            <Collapsible title="Medical & Family History" icon={HistoryIcon}>
              <label className={label}>Past medical history</label>
              <div className="flex flex-wrap gap-2">
                {HISTORY.map((h) => {
                  const on = (form.history || []).includes(h);
                  return <button key={h} type="button" onClick={() => set({ history: on ? form.history.filter((x: string) => x !== h) : [...(form.history || []), h] })} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${on ? 'bg-secondary text-white' : 'border border-slate-300 dark:border-white/10'}`}>{h}</button>;
                })}
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <div><label className={label}>Current Medications</label><textarea className={`${input} min-h-16 resize-y`} value={form.medications || ''} onChange={(e) => set({ medications: e.target.value })} /></div>
                <div><label className={label}>Drug Allergies</label><textarea className={`${input} min-h-16 resize-y`} value={form.allergies || ''} onChange={(e) => set({ allergies: e.target.value })} /></div>
                <div className="sm:col-span-2"><label className={label}>Family History</label><input className={input} value={form.familyHistory || ''} onChange={(e) => set({ familyHistory: e.target.value })} /></div>
              </div>
            </Collapsible>

            <div className="flex flex-wrap items-center gap-3">
              <button onClick={analyze} disabled={loading} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 disabled:opacity-60">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <BrainCircuit className="h-4 w-4" />} Analyze Case
              </button>
              {remaining != null && <span className="text-xs text-slate-400">{isAr ? `الطلبات المتبقية هذا الساعة: ${remaining}` : `Requests left this hour: ${remaining}`}</span>}
              <button onClick={loadHistory} className="inline-flex items-center gap-1 rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><HistoryIcon className="h-4 w-4" /> {isAr ? 'سجل التحليلات' : 'History'}</button>
              {report && user && <button onClick={saveCurrent} className="inline-flex items-center gap-1 rounded-xl border border-primary px-4 py-3 text-sm font-semibold text-primary hover:bg-primary/10"><Save className="h-4 w-4" /> {isAr ? 'حفظ' : 'Save'}</button>}
            </div>
          </div>

          {/* Results */}
          <div className="lg:sticky lg:top-4 lg:self-start">
            {report ? (
              <ReportView report={report} lang={lang} />
            ) : (
              <div className="flex min-h-[400px] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-white/10">
                <BrainCircuit className="h-14 w-14 text-slate-300 dark:text-slate-600" />
                <p className="mt-3 text-sm text-slate-400">{isAr ? 'أدخل بيانات الحالة واضغط «تحليل الحالة» لعرض التشخيص التفريقي والخطة العلاجية والتمريضية.' : 'Enter the case data and click "Analyze Case" to view the differential diagnosis, treatment and nursing plan.'}</p>
                <p className="mt-1 text-xs text-slate-300">{isAr ? 'سيتم حفظ التحليل تلقائياً في سجلك إن كنت مسجّلاً للدخول.' : 'Analyses are saved to your history automatically if you are logged in.'}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* History modal */}
      {showHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowHistory(false)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5 dark:bg-navy-800" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between"><h3 className="font-bold text-slate-900 dark:text-white">{isAr ? 'سجل التحليلات' : 'Analysis History'}</h3><button onClick={() => setShowHistory(false)} className="text-slate-400 hover:text-slate-600">✕</button></div>
            {histLoading ? <p className="text-sm text-slate-400">{isAr ? 'جارٍ التحميل…' : 'Loading…'}</p> : histList.length === 0 ? <p className="text-sm text-slate-400">{isAr ? 'لا توجد تحليلات محفوظة بعد.' : 'No saved analyses yet.'}</p> : (
              <ul className="space-y-2">
                {histList.map((h) => (
                  <li key={h.id}><button onClick={() => openSaved(h.id)} className="flex w-full items-center justify-between rounded-xl border border-slate-200 p-3 text-right text-sm hover:border-primary dark:border-white/10"><span><span className="font-semibold text-slate-800 dark:text-slate-100">{h.title}</span><br /><span className="text-xs text-slate-400">{h.top_diagnosis} · {new Date(h.created_at).toLocaleString(isAr ? 'ar-EG' : 'en-US')}</span></span><Search className="h-4 w-4 text-primary" /></button></li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

function FlaskIcon({ className }: { className?: string }) { return <span className={className}><FlaskConicalInline /></span>; }
function FlaskConicalInline() { return <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-primary"><path d="M9 3h6M10 3v6.5L4.5 19a1.5 1.5 0 0 0 1.3 2.2h13.4A1.5 1.5 0 0 0 19.5 19L14 9.5V3" /></svg>; }
function ScanIcon({ className }: { className?: string }) { return <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-primary"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2" /></svg>; }
