import AITool from '../components/AITool';
import TOOLS from './tools';

// Care Plan is the long-form NANDA-I page; the rest of the tools use the
// shared AITool component.
import CarePlanFull from './CarePlanFull';

export const CarePlanPage = () => <CarePlanFull />;
export const CalculatorPage = () => <AITool config={TOOLS['calculator']} />;
export const CaseLegacyPage = () => <AITool config={TOOLS['case']} />;
import CaseSimulation from './CaseSimulation';
export const CasePage = () => <CaseSimulation />;
export const InterviewPage = () => <AITool config={TOOLS['interview']} />;
export const PdfPage = () => <AITool config={TOOLS['pdf']} />;
export const ChatPage = () => <AITool config={TOOLS['chat']} />;
export const DictionaryPage = () => <AITool config={TOOLS['dictionary']} />;
export const EcgPage = () => <AITool config={TOOLS['ecg']} />;
export const LabPage = () => <AITool config={TOOLS['lab']} />;
export const DrugPage = () => <AITool config={TOOLS['drug']} />;
export const ExamPage = () => <AITool config={TOOLS['exam']} />;
