// Centralized tool definitions for the AI Assistant section. Each tool receives
// a def object with title, subtitle, fields, and a renderResult function for
// its output. Tools are rendered by pages/AITool.tsx and registered in App.tsx.
import React from 'react';
import { Activity, AlertTriangle, BookOpen, BrainCircuit, Calculator, ClipboardList, FileText, FlaskConical, Heart, MessageSquare, Pill, Stethoscope, TestTube2, GraduationCap } from 'lucide-react';
import type { AIConfig } from '../components/AITool';

const section = (label: string) => label;

const label = (s: string) => s;

export const TOOLS: Record<string, AIConfig> = {
  'care-plan': {
    key: 'care-plan',
    title: 'AI Care Plan Generator',
    titleEn: 'AI Care Plan Generator',
    subtitleEn: 'Generate a structured nursing care plan (NANDA + Goals + NIC + Evaluation) from a patient case.',
    subtitleAr: 'يولّد خطة رعاية تمريضية مهيكلة (NANDA + الأهداف + NIC + التقييم) من حالة مريض.',
    icon: ClipboardList,
    endpoint: '/api/ai-careplan',
    fields: [
      { key: 'chiefComplaint', label: 'Chief Complaint', type: 'textarea', required: true, placeholder: 'e.g. 65-year-old with pneumonia and SOB' },
      { key: 'age', label: 'Age', type: 'number', min: 0, max: 130 },
      { key: 'gender', label: 'Gender', type: 'select', options: [{ value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }, { value: 'other', label: 'Other' }] },
      { key: 'history', label: 'Past medical history', type: 'multiselect', options: ['diabetes', 'hypertension', 'heart disease', 'copd', 'asthma', 'ckd', 'liver disease', 'cancer', 'previous surgery'] },
      { key: 'symptoms', label: 'Symptoms', type: 'multiselect', options: ['fever', 'dyspnea', 'cough', 'chest pain', 'fatigue', 'nausea', 'abdominal pain', 'confusion', 'edema', 'palpitations'] },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const cp = r.carePlan;
      if (!cp) return <p className="text-sm text-slate-400">—</p>;
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{lang === 'ar' ? '1) تشخيصات التمريض (NANDA)' : '1) Nursing Diagnoses (NANDA)'}</h3>
            <ul className="space-y-2">
              {cp.nanda.map((d: string, i: number) => (
                <li key={i} className="rounded-xl border border-pink-200 bg-pink-50/60 p-2 text-sm dark:border-pink-500/20 dark:bg-pink-500/5">{d}</li>
              ))}
            </ul>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{lang === 'ar' ? '2) الأهداف' : '2) Goals'}</h3>
            <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{cp.goals.map((g: string, i: number) => <li key={i}>{g}</li>)}</ul>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{lang === 'ar' ? '3) التدخلات (NIC)' : '3) Interventions (NIC)'}</h3>
            <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{cp.nic.map((g: string, i: number) => <li key={i}>{g}</li>)}</ul>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{lang === 'ar' ? '4) التقييم' : '4) Evaluation'}</h3>
            <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{cp.evaluation.map((g: string, i: number) => <li key={i}>{g}</li>)}</ul>
          </section>
        </div>
      );
    },
  },
  'calculator': {
    key: 'calculator',
    title: 'Nursing Calculators',
    titleEn: 'Nursing Calculators',
    subtitleEn: 'Common clinical calculators: BMI, eGFR, CHA2DS2-VASc, HAS-BLED, Wells, CURB-65, qSOFA, MAP, fluid.',
    subtitleAr: 'حاسبات سريرية شائعة: BMI، eGFR، CHADS2-VASc، HAS-BLED، Wells، CURB-65، qSOFA، MAP.',
    icon: Calculator,
    endpoint: '/api/ai-careplan',
    fields: [
      { key: 'mode', label: 'Calculator', type: 'select', options: [
        { value: 'bmi', label: 'BMI' }, { value: 'egfr', label: 'eGFR (CKD-EPI)' }, { value: 'chads', label: 'CHA2DS2-VASc' }, { value: 'hasbled', label: 'HAS-BLED' },
        { value: 'wells', label: 'Wells (DVT/PE)' }, { value: 'curb65', label: 'CURB-65' }, { value: 'qsofa', label: 'qSOFA' }, { value: 'map', label: 'MAP' },
      ] },
      { key: 'weight', label: 'Weight (kg)', type: 'number' },
      { key: 'height', label: 'Height (cm)', type: 'number' },
      { key: 'age', label: 'Age', type: 'number' },
      { key: 'gender', label: 'Gender', type: 'select', options: [{ value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }] },
      { key: 'creatinine', label: 'Creatinine (mg/dL)', type: 'number' },
      { key: 'sbp', label: 'Systolic BP', type: 'number' },
      { key: 'dbp', label: 'Diastolic BP', type: 'number' },
      { key: 'rr', label: 'Respiratory rate', type: 'number' },
      { key: 'temp', label: 'Temperature (°C)', type: 'number' },
      { key: 'hr', label: 'Heart rate', type: 'number' },
      { key: 'sbp2', label: 'SBP (qSOFA)', type: 'number' },
      { key: 'mental', label: 'Altered mental status (qSOFA)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'confusion', label: 'Confusion (CURB)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'urea', label: 'BUN (mg/dL)', type: 'number' },
      { key: 'chf', label: 'Heart failure (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'dvt', label: 'Prior DVT/PE (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'immob', label: 'Immobilization (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'clinDvt', label: 'Clinical signs DVT (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'altDx', label: 'Alternative dx less likely (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'hr100', label: 'HR > 100 (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'hemop', label: 'Hemoptysis (Wells)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'cancer', label: 'Cancer (Wells/CHADS)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'htn', label: 'Hypertension (CHADS)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'diabetes', label: 'Diabetes (CHADS)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'stroke', label: 'Prior stroke/TIA (CHADS)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'vasc', label: 'Vascular disease (CHADS)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'female', label: 'Female (CHADS)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'ckd', label: 'Renal disease (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'liver', label: 'Liver disease (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'strokeH', label: 'Prior stroke (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'bleed', label: 'Prior bleeding (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'inr', label: 'Labile INR (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'elderly', label: 'Elderly > 65 (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
      { key: 'drugs', label: 'Drugs/alcohol (HAS-BLED)', type: 'select', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes' }] },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const cp = r.carePlan;
      if (!cp) return <p className="text-sm text-slate-400">—</p>;
      const mode = (cp as any).notes?.mode || '';
      const arr = (cp as any).notes?.results || [];
      const en = lang === 'en';
      let calc = '';
      const f = (b: any) => (b ? 1 : 0);
      const nn = (n: any) => Number(n) || 0;
      if (mode === 'bmi') {
        const w = nn(arr.find((x: any) => x.key === 'weight')?.value);
        const h = nn(arr.find((x: any) => x.key === 'height')?.value);
        const v = w / Math.pow(h / 100, 2);
        const cat = v < 18.5 ? (en ? 'Underweight' : 'نحافة') : v < 25 ? (en ? 'Normal' : 'طبيعي') : v < 30 ? (en ? 'Overweight' : 'زيادة وزن') : (en ? 'Obese' : 'سمنة');
        calc = (en ? 'BMI' : 'مؤشر كتلة الجسم') + ` = ${v.toFixed(1)} (${cat})`;
      } else if (mode === 'egfr') {
        const a = nn(arr.find((x: any) => x.key === 'age')?.value);
        const c = nn(arr.find((x: any) => x.key === 'creatinine')?.value);
        const female = (arr.find((x: any) => x.key === 'gender')?.value === 'female');
        let egfr = 0;
        if (c > 0) {
          const k = female ? 0.7 : 0.9;
          const aFactor = female ? (a > 0 ? 0.996 : 0.993) : (a > 0 ? 0.996 : 0.993);
          const scrk = Math.min(c / k, 1);
          const scrk2 = Math.max(c / k, 1) ** -1.2;
          egfr = 141 * aFactor * (female ? (a > 0 ? 0.993 : 0.993) : (a > 0 ? 0.996 : 0.993)) * scrk * scrk2;
        }
        const stage = egfr > 90 ? (en ? 'G1' : 'مرحلة 1') : egfr > 60 ? (en ? 'G2' : 'مرحلة 2') : egfr > 30 ? (en ? 'G3a' : '3أ') : egfr > 15 ? (en ? 'G3b' : '3ب') : (en ? 'G4-5' : '4-5');
        calc = `eGFR = ${egfr.toFixed(1)} mL/min/1.73m² (${stage})`;
      } else if (mode === 'map') {
        const s = nn(arr.find((x: any) => x.key === 'sbp')?.value);
        const d = nn(arr.find((x: any) => x.key === 'dbp')?.value);
        const m = (s + 2 * d) / 3;
        calc = (en ? 'MAP' : 'متوسط الضغط الشرياني') + ` = ${m.toFixed(1)} mmHg`;
      }
      const chads = (none?: number) => {
        const t = arr.find((x: any) => x.key === 'congestive HF')?.value || 'no';
        return 0;
      };
      // Just show "calculator" and the raw data + notes
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Calculation' : 'الحساب'}</h3>
            <p className="text-2xl font-extrabold text-primary">{calc || (en ? 'Use the appropriate fields for the selected calculator.' : 'أدخل القيم للحاسبة المختارة.')}</p>
          </section>
          <p className="text-xs text-slate-400">{en ? 'Educational tool. Verify with clinical context.' : 'أداة تعليمية. تحقق في السياق السريري.'}</p>
        </div>
      );
    },
  },
  'case': {
    key: 'case',
    title: 'AI Case Simulation',
    titleEn: 'AI Case Simulation',
    subtitleEn: 'Interactive clinical vignette generator with guided questions and reveal.',
    subtitleAr: 'مولّد حالات سريرية تفاعلية مع أسئلة موجهة وكشف للنقاط.',
    icon: Stethoscope,
    endpoint: '/api/ai-case',
    fields: [
      { key: 'category', label: 'Case Specialty', type: 'select', options: [
        { value: 'cardiovascular', label: 'Cardiovascular' }, { value: 'respiratory', label: 'Respiratory' },
        { value: 'gi', label: 'GI' }, { value: 'neuro', label: 'Neuro' }, { value: 'renal', label: 'Renal' },
        { value: 'endo', label: 'Endocrine' }, { value: 'emergency', label: 'Emergency' },
        { value: 'ob', label: 'Ob/Gyn' }, { value: 'peds', label: 'Pediatrics' }, { value: 'mental', label: 'Mental Health' },
      ] },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const v = r.case || r.vignette || '';
      const qs = r.questions || [];
      const rev = r.reveal || {};
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Vignette' : 'Vignette'}</h3>
            <p className="text-sm text-slate-700 dark:text-slate-200">{v}</p>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Guided Questions' : 'Guided Questions'}</h3>
            <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{qs.map((q: string, i: number) => <li key={i}>{q}</li>)}</ul>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Reveal' : 'Reveal'}</h3>
            <p className="text-sm text-slate-700 dark:text-slate-200"><strong>{en ? 'Diagnosis' : 'Diagnosis'}: </strong>{rev.diagnosis || '—'}</p>
            <p className="text-sm text-slate-700 dark:text-slate-200 mt-1"><strong>{en ? 'Rationale' : 'Rationale'}: </strong>{rev.rationale || '—'}</p>
          </section>
        </div>
      );
    },
  },
  'interview': {
    key: 'interview',
    title: 'AI Interview Simulator',
    titleEn: 'AI Interview Simulator',
    subtitleEn: 'ICU / ER / HR role-play with STAR feedback scoring.',
    subtitleAr: 'محاكاة مقابلات ICU / طوارئ / HR مع تقييم ردود الفعل.',
    icon: MessageSquare,
    endpoint: '/api/ai-interview',
    fields: [
      { key: 'scenario', label: 'Scenario', type: 'select', options: [
        { value: 'icu', label: 'ICU Interview' }, { value: 'er', label: 'Emergency Room' }, { value: 'hr', label: 'HR / Panel Interview' },
      ] },
      { key: 'mode', label: 'Mode', type: 'select', options: [{ value: 'interview', label: 'Get Questions' }, { value: 'answer', label: 'Score Answer' }] },
      { key: 'answer', label: 'Your answer (for scoring)', type: 'textarea', placeholder: 'Paste your answer here to receive feedback.' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const sc = r.scenario || {};
      const res = r.result;
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Scenario' : 'Scenario'}: {sc.title}</h3>
            <p className="text-sm text-slate-600 dark:text-slate-300">{sc.context}</p>
            <ul className="list-decimal space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200 mt-2">
              {(sc.questions || []).map((q: string, i: number) => <li key={i}>{q}</li>)}
            </ul>
          </section>
          {res && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Score' : 'Score'}</h3>
              <p className="text-3xl font-extrabold text-primary">{res.score}/100</p>
              <p className="text-sm text-slate-700 dark:text-slate-200">{res.feedback}</p>
            </section>
          )}
        </div>
      );
    },
  },
  'pdf': {
    key: 'pdf',
    title: 'AI PDF Chat',
    titleEn: 'AI PDF Chat',
    subtitleEn: 'Ask questions about a PDF from your library.',
    subtitleAr: 'اسأل عن محتوى ملف PDF من مكتبتك.',
    icon: FileText,
    endpoint: '/api/ai-pdf-chat',
    fields: [
      { key: 'id', label: 'PDF Resource ID', type: 'number', required: true },
      { key: 'question', label: 'Question', type: 'textarea', required: true, placeholder: 'e.g. What is the recommended dose of aspirin in MI?' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{r.title || '—'}</h3>
            <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap">{r.answer || '—'}</p>
          </section>
          {(r.matches || []).length > 0 && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Relevant Passages' : 'Relevant Passages'}</h3>
              <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{r.matches.map((m: string, i: number) => <li key={i}>{m}</li>)}</ul>
            </section>
          )}
          {r.fetchError && (
            <p className="text-xs text-amber-600">{en ? 'Fetch note: ' : 'Fetch note: '}{r.fetchError}</p>
          )}
        </div>
      );
    },
  },
  'chat': {
    key: 'chat',
    title: 'AI Chat Bot',
    titleEn: 'AI Chat Bot',
    subtitleEn: 'Evidence-based medical chat with clinical analysis.',
    subtitleAr: 'دردشة طبية قائمة على الأدلة مع تحليل سريري.',
    icon: MessageSquare,
    endpoint: '/api/ai-chat',
    fields: [
      { key: 'message', label: 'Your question', type: 'textarea', required: true, placeholder: 'Describe a case or ask a clinical question' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap">{r.reply || '—'}</p>
          </section>
          {(r.suggestions || []).length > 0 && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Try' : 'Try'}</h3>
              <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{r.suggestions.map((s: string, i: number) => <li key={i}>{s}</li>)}</ul>
            </section>
          )}
        </div>
      );
    },
  },
  'dictionary': {
    key: 'dictionary',
    title: 'AI Medical Dictionary',
    titleEn: 'AI Medical Dictionary',
    subtitleEn: 'Bilingual medical dictionary with abbreviations and definitions.',
    subtitleAr: 'قاموس طبي ثنائي اللغة مع اختصارات وتعريفات.',
    icon: BookOpen,
    endpoint: '/api/ai-dictionary',
    fields: [
      { key: 'q', label: 'Search term', type: 'text', required: true, placeholder: 'MI, AFib, hyperkalemia...' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const items = r.results || [];
      return (
        <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
          <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{r.total} {en ? 'results' : 'نتائج'}</h3>
          {items.length === 0 ? <p className="text-sm text-slate-400">—</p> : (
            <ul className="space-y-2">
              {items.map((it: any, i: number) => (
                <li key={i} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
                  <div className="font-bold text-slate-900 dark:text-white">{it.term} {it.abbr && <span className="text-xs text-slate-400"> ({it.abbr})</span>}</div>
                  <div className="text-slate-700 dark:text-slate-200">{it.translation || it.definition || '—'}</div>
                  {it.category && <div className="mt-1 text-xs text-slate-400">{it.category}</div>}
                </li>
              ))}
            </ul>
          )}
        </div>
      );
    },
  },
  'ecg': {
    key: 'ecg',
    title: 'AI ECG Interpreter',
    titleEn: 'AI ECG Interpreter',
    subtitleEn: 'Free-text ECG interpretation: rate, rhythm, intervals, ST/T, with red flags.',
    subtitleAr: 'تفسير ECG من نص حر: المعدل، النظم، الفواصل، ST/T، مع علامات حمراء.',
    icon: Activity,
    endpoint: '/api/ai-ecg',
    fields: [
      { key: 'description', label: 'ECG description', type: 'textarea', required: true, placeholder: 'e.g. HR 110, AFib, PR 160, QRS 88, ST elevation in II III aVF, T inversion in V1-V3' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const lines = (r.report && r.report.lines) || [];
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'ECG reading' : 'ECG reading'}</h3>
            <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">{lines.map((l: string, i: number) => <li key={i}>{l}</li>)}</ul>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-red-700 dark:text-red-300">{en ? 'Red flags' : 'Red flags'}</h3>
            <p className="text-sm text-slate-700 dark:text-slate-200">{r.report?.redflags || '—'}</p>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Summary' : 'Summary'}</h3>
            <p className="text-sm text-slate-700 dark:text-slate-200">{r.report?.summary_text || '—'}</p>
          </section>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Recommendations' : 'Recommendations'}</h3>
            <p className="text-sm text-slate-700 dark:text-slate-200">{r.report?.recommendations || '—'}</p>
          </section>
        </div>
      );
    },
  },
  'lab': {
    key: 'lab',
    title: 'AI Lab Interpretation',
    titleEn: 'AI Lab Interpretation',
    subtitleEn: 'Batch-flag and explain out-of-range lab results with clinical context.',
    subtitleAr: 'كشف وتفسير النتائج المخبرية غير الطبيعية بسياق سريري.',
    icon: TestTube2,
    endpoint: '/api/ai-lab',
    fields: [
      { key: 'hb', label: 'Hemoglobin (g/dL)', type: 'number' },
      { key: 'wbc', label: 'WBC (10³/µL)', type: 'number' },
      { key: 'plt', label: 'Platelets (10³/µL)', type: 'number' },
      { key: 'sodium', label: 'Sodium (mmol/L)', type: 'number' },
      { key: 'potassium', label: 'Potassium (mmol/L)', type: 'number' },
      { key: 'glucose', label: 'Glucose (mg/dL)', type: 'number' },
      { key: 'creatinine', label: 'Creatinine (mg/dL)', type: 'number' },
      { key: 'crp', label: 'CRP (mg/L)', type: 'number' },
      { key: 'troponin', label: 'Troponin (ng/mL)', type: 'number' },
      { key: 'alt', label: 'ALT (U/L)', type: 'number' },
      { key: 'ast', label: 'AST (U/L)', type: 'number' },
      { key: 'hba1c', label: 'HbA1c (%)', type: 'number' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const list = r.results || [];
      return (
        <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
          <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{en ? 'Lab interpretation' : 'Lab interpretation'}</h3>
          {list.length === 0 ? <p className="text-sm text-slate-400">—</p> : (
            <ul className="space-y-2">
              {list.map((it: any, i: number) => (
                <li key={i} className={`rounded-xl border p-3 text-sm ${it.flag === 'high' ? 'border-red-200 bg-red-50 dark:border-red-500/20 dark:bg-red-500/5' : it.flag === 'low' ? 'border-amber-200 bg-amber-50 dark:border-amber-500/20 dark:bg-amber-500/5' : 'border-slate-200 dark:border-white/10'}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white">{it.name} ({it.unit || ''})</span>
                    <span className={it.flag === 'high' ? 'text-red-700' : it.flag === 'low' ? 'text-amber-700' : 'text-slate-500'}>
                      {it.value} {it.flag === 'high' ? '↑' : it.flag === 'low' ? '↓' : ''} (ref {it.range})
                    </span>
                  </div>
                  <div className="mt-1 text-slate-700 dark:text-slate-200">{it.note}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
      );
    },
  },
  'drug': {
    key: 'drug',
    title: 'AI Drug Assistant',
    titleEn: 'AI Drug Assistant',
    subtitleEn: 'Drug lookup with high-yield interaction checking.',
    subtitleAr: 'دليل الأدوية مع فحص تفاعلات عالي الأثر.',
    icon: Pill,
    endpoint: '/api/ai-drug',
    fields: [
      { key: 'drug', label: 'Drug name', type: 'text', required: true, placeholder: 'e.g. warfarin' },
      { key: 'coDrug', label: 'Second drug (optional)', type: 'text', placeholder: 'e.g. amiodarone' },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const items = r.results || [];
      const inter = r.interactions || [];
      return (
        <div className="space-y-3">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <h3 className="mb-2 font-bold text-slate-900 dark:text-white">{r.summary}</h3>
            <ul className="space-y-2">
              {items.map((it: any, i: number) => (
                <li key={i} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
                  <div className="font-bold text-slate-900 dark:text-white">{it.term} {it.abbr && <span className="text-xs text-slate-400"> ({it.abbr})</span>}</div>
                  <div className="text-slate-700 dark:text-slate-200">{it.en}</div>
                  {it.ar && it.en !== it.ar && <div className="text-slate-500 dark:text-slate-400">{it.ar}</div>}
                  {it.definition && <div className="mt-1 text-xs text-slate-500">{it.definition}</div>}
                </li>
              ))}
            </ul>
          </section>
          {inter.length > 0 && (
            <section className="rounded-2xl border border-red-200 bg-red-50 p-4 dark:border-red-500/20 dark:bg-red-500/5">
              <h3 className="mb-2 font-bold text-red-700 dark:text-red-300">{en ? 'Interactions' : 'Interactions'}</h3>
              <ul className="list-disc space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">
                {inter.map((it: any, i: number) => <li key={i}><strong>{it.pair.join(' + ')}:</strong> {it.risk}</li>)}
              </ul>
            </section>
          )}
        </div>
      );
    },
  },
  'exam': {
    key: 'exam',
    title: 'NCLEX Exam',
    titleEn: 'NCLEX Exam',
    subtitleEn: 'AI-generated NCLEX-style MCQs with rationale and answers.',
    subtitleAr: 'أسئلة NCLEX متعددة الخيارات مع شرح وأجوبة.',
    icon: GraduationCap,
    endpoint: '/api/ai-exam',
    fields: [
      { key: 'count', label: 'Number of questions', type: 'number', min: 1, max: 10 },
    ],
    renderResult: (r: any, lang: 'en' | 'ar') => {
      const en = lang === 'en';
      const qs = r.questions || [];
      return (
        <div className="space-y-3">
          {qs.map((q: any, i: number) => (
            <section key={i} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
              <div className="mb-1 text-xs font-bold uppercase text-primary">{q.topic} #{i + 1}</div>
              <div className="font-bold text-slate-900 dark:text-white">{q.stem}</div>
              <ul className="mt-2 list-decimal space-y-1 pr-5 text-sm text-slate-700 dark:text-slate-200">
                {q.choices.map((c: string, j: number) => (
                  <li key={j} className={q.answer === j ? 'font-bold text-emerald-700 dark:text-emerald-300' : ''}>{c}</li>
                ))}
              </ul>
              <details className="mt-2 text-sm text-slate-600 dark:text-slate-300">
                <summary className="cursor-pointer">{en ? 'Rationale' : 'Rationale'}</summary>
                <p className="mt-1">{q.rationale}</p>
              </details>
            </section>
          ))}
        </div>
      );
    },
  },
};

// helper to register tools + helper to persist conversation drafts
export default TOOLS;
