import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Minus, Sparkles, Send, CheckCircle2 } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import LiveSearch from '../components/LiveSearch';
import FloatingIcons from '../components/FloatingIcons';
import CategoryCard from '../components/CategoryCard';
import ResourceCard from '../components/ResourceCard';
import { SkeletonGrid } from '../components/CardSkeleton';
import StatCard from '../components/StatCard';
import SectionHeader from '../components/SectionHeader';
import { useSettings } from '../contexts/SettingsContext';
import { useToast } from '../components/Toast';
import { fetchResources, fetchPublicStats, trackEvent } from '../lib/api';
import { SECTION_LIST } from '../lib/constants';
import { formatNumber } from '../lib/format';
import type { Resource, PublicStats } from '../types';

const FAQS = [
  { q: 'هل التحميل مجاني؟', a: 'نعم، كل الملفات والكتب متاحة للتحميل مجانًا دون تسجيل.' },
  { q: 'كيف أبحث عن ملف معين؟', a: 'استخدم شريط البحث أعلى الصفحة أو تصفّح الأقسام والتصنيفات.' },
  { q: 'هل يمكنني معاينة الملف قبل التحميل؟', a: 'نعم، كل ملف PDF يمكن معاينته داخل الصفحة قبل التحميل.' },
  { q: 'كيف أضيف ملفات جديدة؟', a: 'من لوحة التحكم يمكنك رفع ملفات وكتب جديدة بسهولة.' },
];

const STAT_DEFS = [
  { icon: 'FileText', statKey: 'files', label: 'ملف ومصدر', gradient: 'from-primary to-primary-600' },
  { icon: 'Download', statKey: 'downloads', label: 'عملية تحميل', gradient: 'from-secondary to-secondary-600' },
  { icon: 'BookOpen', statKey: 'books', label: 'كتاب ومرجع', gradient: 'from-accent to-orange-500' },
  { icon: 'Users', statKey: 'views', label: 'زائر', gradient: 'from-purple-500 to-primary' },
];

export default function Home() {
  const { settings } = useSettings();
  const { toast } = useToast();
  const [featured, setFeatured] = useState<Resource[]>([]);
  const [latest, setLatest] = useState<Resource[]>([]);
  const [stats, setStats] = useState<PublicStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    Promise.all([
      fetchResources({ featured: 'true', limit: '8' }),
      fetchResources({ sort: 'created_at', order: 'desc', limit: '8' }),
      fetchPublicStats().catch(() => null),
    ]).then(([f, l, s]) => {
      setFeatured(f);
      setLatest(l);
      setStats(s);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const subscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) { toast('البريد الإلكتروني غير صالح', 'error'); return; }
    trackEvent('newsletter', email);
    setSubscribed(true);
    setEmail('');
    toast('تم الاشتراك بنجاح', 'success');
  };

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200/60 dark:border-white/10">
        <div className="absolute -top-24 right-0 h-96 w-96 rounded-full bg-primary/20 blur-3xl animate-blob dark:bg-primary/10" />
        <div className="absolute -bottom-24 left-0 h-96 w-96 rounded-full bg-secondary/20 blur-3xl animate-blob dark:bg-secondary/10" style={{ animationDelay: '4s' }} />
        <FloatingIcons />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">
              <Sparkles className="h-4 w-4" /> {settings.tagline}
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight tracking-tight text-slate-900 dark:text-white sm:text-5xl">
              {settings.heroTitle}
            </h1>
            <p className="mt-4 max-w-xl text-lg text-slate-600 dark:text-slate-300">{settings.heroSubtitle}</p>
            <div className="mt-7 max-w-lg"><LiveSearch /></div>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/study" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-6 py-3 font-semibold text-white shadow-lg shadow-primary/30 transition hover:opacity-90">
                {settings.heroCta} <ArrowLeft className="h-4.5 w-4.5" />
              </Link>
              <Link to="/books" className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white/70 px-6 py-3 font-semibold text-slate-700 transition hover:border-primary hover:text-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                تصفّح الكتب
              </Link>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.15 }} className="relative mx-auto w-full max-w-md">
            <div className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-br from-primary/30 to-secondary/30 blur-3xl" />
            <div className="relative z-10 animate-float overflow-hidden rounded-[2rem] border border-white/60 bg-white/50 p-2 shadow-2xl shadow-primary/20 backdrop-blur dark:border-white/10 dark:bg-white/5">
              <img src="/hero-nurse.jpg" alt="ممرض" loading="eager" width={1100} height={1100} className="aspect-square w-full rounded-[1.5rem] object-cover" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Quick categories */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <SectionHeader title="استكشف الأقسام" subtitle="مصادر منظّمة حسب احتياجك الدراسي" icon="Layers" center />
        <div className="grid gap-6 sm:grid-cols-3">
          {SECTION_LIST.map((s, i) => (
            <CategoryCard key={s.key} to={s.path} name={s.label} desc={s.desc} icon={s.icon} gradient={s.color} index={i} />
          ))}
        </div>
      </section>

      {/* Stats */}
      {stats && (
        <section className="border-y border-slate-200/60 bg-white/50 py-16 dark:border-white/10 dark:bg-white/[0.02]">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-5 px-4 sm:px-6 lg:grid-cols-4 lg:px-8">
            {STAT_DEFS.map((s, i) => (
              <StatCard key={s.statKey} icon={s.icon} value={formatNumber((stats as unknown as Record<string, number>)[s.statKey])} label={s.label} gradient={s.gradient} index={i} />
            ))}
          </div>
        </section>
      )}

      {/* Featured */}
      {(loading || featured.length > 0) && (
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <SectionHeader title="مختارات مميّزة" icon="Star" gradient="from-accent to-orange-500" />
          {loading ? <SkeletonGrid count={4} /> : (
            <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
              {featured.slice(0, 8).map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
            </div>
          )}
        </section>
      )}

      {/* Latest */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-end justify-between">
          <SectionHeader title="أحدث الملفات" icon="Sparkles" />
          <Link to="/study" className="mb-8 flex items-center gap-1 text-sm font-semibold text-primary hover:gap-2">عرض الكل <ArrowLeft className="h-4 w-4" /></Link>
        </div>
        {loading ? <SkeletonGrid count={8} /> : latest.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-slate-300 py-16 text-center text-slate-500 dark:border-white/10">لا توجد ملفات بعد</p>
        ) : (
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
            {latest.map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
          </div>
        )}
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl border-t border-slate-200/60 px-4 py-16 dark:border-white/10 sm:px-6 lg:px-8">
        <SectionHeader title="الأسئلة الشائعة" icon="HelpCircle" center />
        <div className="space-y-3">
          {FAQS.map((f, i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-white/10 dark:bg-white/5">
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="flex w-full items-center justify-between gap-3 px-5 py-4 text-right">
                <span className="font-bold text-slate-900 dark:text-white">{f.q}</span>
                {openFaq === i ? <Minus className="h-5 w-5 shrink-0 text-primary" /> : <Plus className="h-5 w-5 shrink-0 text-slate-400" />}
              </button>
              {openFaq === i && <p className="px-5 pb-5 leading-relaxed text-slate-600 dark:text-slate-300">{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-primary to-secondary p-10 text-center text-white sm:p-14">
          <div className="absolute -top-16 right-10 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
          <div className="relative">
            <h2 className="text-2xl font-extrabold sm:text-3xl">اشترك لتصلك التحديثات</h2>
            <p className="mx-auto mt-2 max-w-xl text-white/90">أضف بريدك الإلكتروني لتصلك أحدث الملفات والكتب والأسئلة.</p>
            {subscribed ? (
              <div className="mx-auto mt-6 inline-flex items-center gap-2 rounded-xl bg-white/20 px-5 py-3 font-semibold"><CheckCircle2 className="h-5 w-5" /> تم الاشتراك بنجاح</div>
            ) : (
              <form onSubmit={subscribe} className="mx-auto mt-6 flex max-w-md gap-2">
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="بريدك الإلكتروني" className="w-full rounded-xl border-0 bg-white/95 px-4 py-3 text-slate-800 outline-none" />
                <button type="submit" className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-white px-5 py-3 font-bold text-primary transition hover:bg-white/90"><Send className="h-4.5 w-4.5" /> اشتراك</button>
              </form>
            )}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
