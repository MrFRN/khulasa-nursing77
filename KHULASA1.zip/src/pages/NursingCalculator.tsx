import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle,
  BookOpen,
  Calculator as CalcIcon,
  Check,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  Copy,
  Droplet,
  ExternalLink,
  Eye,
  EyeOff,
  FlaskConical,
  Globe,
  Heart,
  HeartPulse,
  Loader2,
  Lock,
  Pill,
  Printer,
  RefreshCw,
  Save,
  Search,
  Share2,
  Sparkles,
  Stethoscope,
  Sun,
  Trash2,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useToast } from '../components/Toast';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import supabase from '../lib/supabase';

type Lang = 'en' | 'ar';
type Field = { key: string; label: string; labelAr: string; type: 'number' | 'select' | 'text'; unit?: string; placeholder?: string; min?: number; step?: number; options?: { value: string; label: string; labelAr: string }[]; hint?: string; hintAr?: string };

type CalcDef = {
  key: string;
  category: string;
  title: string; titleAr: string;
  short: string; shortAr: string;
  long: string; longAr: string;
  icon: any;
  fields: Field[];
  references?: { abbr: string; title: string; url: string }[];
};

const CATEGORIES = [
  { key: 'medication', en: 'Medication', ar: 'الأدوية', icon: Pill, gradient: 'from-sky-500 to-cyan-500', accent: 'text-sky-400' },
  { key: 'iv', en: 'IV Therapy', ar: 'العلاج الوريدي', icon: Droplet, gradient: 'from-cyan-500 to-teal-500', accent: 'text-cyan-400' },
  { key: 'pediatrics', en: 'Pediatrics', ar: 'طب الأطفال', icon: Heart, gradient: 'from-pink-500 to-rose-500', accent: 'text-rose-400' },
  { key: 'respiratory', en: 'Respiratory', ar: 'الجهاز التنفسي', icon: Stethoscope, gradient: 'from-emerald-500 to-green-500', accent: 'text-emerald-400' },
  { key: 'lab', en: 'Laboratory', ar: 'المختبر', icon: FlaskConical, gradient: 'from-amber-500 to-orange-500', accent: 'text-amber-400' },
  { key: 'hemodynamics', en: 'Hemodynamics', ar: 'الديناميكا', icon: HeartPulse, gradient: 'from-red-500 to-pink-500', accent: 'text-red-400' },
  { key: 'renal', en: 'Renal', ar: 'الكلى', icon: Sparkles, gradient: 'from-violet-500 to-purple-500', accent: 'text-violet-400' },
  { key: 'general', en: 'General Nursing', ar: 'تمريض عام', icon: ClipboardList, gradient: 'from-indigo-500 to-blue-500', accent: 'text-indigo-400' },
];

const CALCS: CalcDef[] = [
  // Medication
  {
    key: 'med_dose', category: 'medication',
    title: 'Medication Dosage', titleAr: 'حساب جرعة الدواء',
    short: 'Ordered vs. available dose', shortAr: 'الجرعة الموصوفة والمتوافرة',
    long: 'Calculate mL or tablets to give from ordered and available concentrations.',
    longAr: 'احسب مل أو أقراص للإعطاء بناءً على التركيز المتاح.',
    icon: Pill,
    fields: [
      { key: 'orderedDose', label: 'Ordered Dose', labelAr: 'الجرعة الموصوفة', type: 'number', placeholder: '500' },
      { key: 'availableDose', label: 'Available Dose', labelAr: 'الجرعة المتاحة', type: 'number', placeholder: '250' },
      { key: 'availableVolume', label: 'Available Volume (mL or tablets)', labelAr: 'الحجم المتاح (مل أو أقراص)', type: 'number', placeholder: '5' },
    ],
  },
  {
    key: 'wt_dose', category: 'medication',
    title: 'Weight-Based Dose', titleAr: 'الجرعة بالوزن',
    short: 'Total dose from mg/kg', shortAr: 'إجمالي الجرعة بمجم/كجم',
    long: 'Compute the total dose from mg/kg for adult or pediatric patients.',
    longAr: 'احسب الجرعة الإجمالية من مجم/كجم للبالغين أو الأطفال.',
    icon: Pill,
    fields: [
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'mgPerKg', label: 'mg/kg', labelAr: 'مجم/كجم', type: 'number', step: 0.01 },
    ],
  },
  {
    key: 'insulin', category: 'medication',
    title: 'Insulin Calculations', titleAr: 'حسابات الأنسولين',
    short: 'Total daily dose & bolus', shortAr: 'الجرعة اليومية وbolus',
    long: 'Calculate insulin total daily dose (TDD) and meal bolus.',
    longAr: 'احسب الجرعة اليومية للأنسولين وجرعة bolus.',
    icon: Pill,
    fields: [
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'dose', label: 'U/kg/day', labelAr: 'وحدة/كجم/يوم', type: 'number', step: 0.01 },
      { key: 'carbs', label: 'Carbs (g) [optional]', labelAr: 'الكربوهيدرات (غ) [اختياري]', type: 'number' },
      { key: 'ratio', label: 'Insulin:Carb ratio (1:U per N g) [optional]', labelAr: 'نسبة الأنسولين للكربوهيدرات [اختياري]', type: 'number' },
    ],
  },
  // IV Therapy
  {
    key: 'iv_flow', category: 'iv',
    title: 'IV Flow Rate', titleAr: 'معدل تدفق الوريد',
    short: 'mL/hr and gtt/min', shortAr: 'مل/س وقطرات/د',
    long: 'Calculate IV pump rate (mL/hr) and manual drop rate (drops/min).',
    longAr: 'احسب معدل ضخ الوريد (مل/س) ومعدل التقطير اليدوي (ق/د).',
    icon: Droplet,
    fields: [
      { key: 'volume', label: 'Volume (mL)', labelAr: 'الحجم (مل)', type: 'number' },
      { key: 'hours', label: 'Time (hours)', labelAr: 'الوقت (س)', type: 'number', step: 0.1 },
      { key: 'dropFactor', label: 'Drop factor (gtt/mL)', labelAr: 'معامل التقطير (ق/مل)', type: 'number' },
    ],
  },
  {
    key: 'iv_time', category: 'iv',
    title: 'IV Infusion Time', titleAr: 'وقت التسريب الوريدي',
    short: 'Duration of infusion', shortAr: 'مدة التسريب',
    long: 'Calculate how long an IV will take at a given rate.',
    longAr: 'احسب مدة التسريب الوريدي بمعدل معين.',
    icon: Droplet,
    fields: [
      { key: 'volume', label: 'Volume (mL)', labelAr: 'الحجم (مل)', type: 'number' },
      { key: 'rate', label: 'Rate (mL/hr)', labelAr: 'المعدل (مل/س)', type: 'number', step: 0.1 },
    ],
  },
  {
    key: 'heparin', category: 'iv',
    title: 'Heparin / IV Infusion', titleAr: 'الهيبارين / التسريب الوريدي',
    short: 'IV medication infusion', shortAr: 'تسريب الأدوية الوريدية',
    long: 'Calculate mL/hr from units/kg/hr and IV concentration.',
    longAr: 'احسب مل/س من وحدة/كجم/س وتركيز المحلول.',
    icon: Droplet,
    fields: [
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'rate', label: 'Units/kg/hr', labelAr: 'وحدة/كجم/س', type: 'number', step: 0.1 },
      { key: 'concentration', label: 'Concentration (U/mL)', labelAr: 'التركيز (وحدة/مل)', type: 'number' },
    ],
  },
  // Pediatrics
  {
    key: 'peds_dose', category: 'pediatrics',
    title: 'Pediatric Dose', titleAr: 'الجرعة للأطفال',
    short: 'mg/kg/day with max validation', shortAr: 'مجم/كجم/يوم مع التحقق من الحد الأقصى',
    long: 'Calculate pediatric dose with optional maximum dose safety check.',
    longAr: 'احسب جرعة الأطفال مع تحقق اختياري من الجرعة القصوى.',
    icon: Heart,
    fields: [
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'mgPerKg', label: 'mg/kg/dose', labelAr: 'مجم/كجم/الجرعة', type: 'number', step: 0.01 },
      { key: 'dosesPerDay', label: 'Doses per day', labelAr: 'الجرعات في اليوم', type: 'number' },
      { key: 'maxDailyDose', label: 'Max daily dose [optional]', labelAr: 'الجرعة اليومية القصوى [اختياري]', type: 'number' },
    ],
  },
  // Respiratory
  {
    key: 'pafi', category: 'respiratory',
    title: 'PaO₂/FiO₂ Ratio', titleAr: 'نسبة PaO₂/FiO₂',
    short: 'ARDS severity', shortAr: 'شدة ARDS',
    long: 'Calculate PaO2/FiO2 ratio and ARDS severity.',
    longAr: 'احسب نسبة PaO₂/FiO₂ وشدة متلازمة الضائقة التنفسية.',
    icon: Stethoscope,
    fields: [
      { key: 'pao2', label: 'PaO₂ (mmHg)', labelAr: 'PaO₂ (ملم زئبق)', type: 'number' },
      { key: 'fio2', label: 'FiO₂ (0.21-1.0)', labelAr: 'FiO₂ (0.21-1.0)', type: 'number', step: 0.01 },
    ],
  },
  {
    key: 'minute_vent', category: 'respiratory',
    title: 'Minute Ventilation', titleAr: 'التهوية الدقيقة',
    short: 'TV × RR', shortAr: 'الحجم المُد × معدل التنفس',
    long: 'Calculate minute ventilation for respiratory care.',
    longAr: 'احسب التهوية الدقيقة لرعاية الجهاز التنفسي.',
    icon: Stethoscope,
    fields: [
      { key: 'tidalVolume', label: 'Tidal Volume (mL)', labelAr: 'الحجم المُد (مل)', type: 'number' },
      { key: 'rr', label: 'Respiratory Rate (breaths/min)', labelAr: 'معدل التنفس (ن/د)', type: 'number' },
    ],
  },
  // Laboratory
  {
    key: 'anion_gap', category: 'lab',
    title: 'Anion Gap', titleAr: 'فجوة الأنيون',
    short: 'Na − (Cl + HCO3)', shortAr: 'Na − (Cl + HCO3)',
    long: 'Compute serum anion gap and classify acidosis.',
    longAr: 'احسب فجوة الأنيون في المصل وصنف الحماض.',
    icon: FlaskConical,
    fields: [
      { key: 'na', label: 'Sodium (mEq/L)', labelAr: 'الصوديوم (مEq/ل)', type: 'number' },
      { key: 'cl', label: 'Chloride (mEq/L)', labelAr: 'الكلور (مEq/ل)', type: 'number' },
      { key: 'hco3', label: 'Bicarbonate (mEq/L)', labelAr: 'البيكربونات (مEq/ل)', type: 'number' },
    ],
  },
  {
    key: 'corr_na', category: 'lab',
    title: 'Corrected Sodium', titleAr: 'الصوديوم المصحح',
    short: 'For hyperglycemia', shortAr: 'لارتفاع السكر',
    long: 'Adjust sodium for hyperglycemia.',
    longAr: 'تصحيح الصوديوم لارتفاع السكر.',
    icon: FlaskConical,
    fields: [
      { key: 'na', label: 'Sodium (mEq/L)', labelAr: 'الصوديوم (مEq/ل)', type: 'number' },
      { key: 'glucose', label: 'Glucose (mg/dL)', labelAr: 'الجلوكوز (ملغ/دل)', type: 'number' },
    ],
  },
  {
    key: 'corr_ca', category: 'lab',
    title: 'Corrected Calcium', titleAr: 'الكالسيوم المصحح',
    short: 'For hypoalbuminemia', shortAr: 'لانخفاض الألبومين',
    long: 'Adjust calcium for low albumin.',
    longAr: 'تصحيح الكالسيوم لانخفاض الألبومين.',
    icon: FlaskConical,
    fields: [
      { key: 'ca', label: 'Calcium (mg/dL)', labelAr: 'الكالسيوم (ملغ/دل)', type: 'number', step: 0.1 },
      { key: 'albumin', label: 'Albumin (g/dL)', labelAr: 'الألبومين (غ/دل)', type: 'number', step: 0.1 },
    ],
  },
  // Hemodynamics
  {
    key: 'map', category: 'hemodynamics',
    title: 'MAP', titleAr: 'متوسط الضغط الشرياني',
    short: 'DBP + (SBP − DBP)/3', shortAr: 'الانبساطي + (الانقباضي − الانبساطي)/3',
    long: 'Compute mean arterial pressure for organ perfusion.',
    longAr: 'احسب متوسط الضغط الشرياني لتروية الأعضاء.',
    icon: HeartPulse,
    fields: [
      { key: 'sbp', label: 'Systolic BP (mmHg)', labelAr: 'الضغط الانقباضي (ملم زئبق)', type: 'number' },
      { key: 'dbp', label: 'Diastolic BP (mmHg)', labelAr: 'الضغط الانبساطي (ملم زئبق)', type: 'number' },
    ],
  },
  {
    key: 'pp', category: 'hemodynamics',
    title: 'Pulse Pressure', titleAr: 'ضغط النبض',
    short: 'SBP − DBP', shortAr: 'انقباضي − انبساطي',
    long: 'Calculate pulse pressure.',
    longAr: 'احسب ضغط النبض.',
    icon: HeartPulse,
    fields: [
      { key: 'sbp', label: 'Systolic BP', labelAr: 'الضغط الانقباضي', type: 'number' },
      { key: 'dbp', label: 'Diastolic BP', labelAr: 'الضغط الانبساطي', type: 'number' },
    ],
  },
  // Renal
  {
    key: 'crcl', category: 'renal',
    title: 'Creatinine Clearance (CrCl)', titleAr: 'تصفية الكرياتينين',
    short: 'Cockcroft-Gault', shortAr: 'كروكروفت-غولت',
    long: 'Estimate creatinine clearance using Cockcroft-Gault.',
    longAr: 'قدّر تصفية الكرياتينين بمعادلة كروكروفت-غولت.',
    icon: Sparkles,
    fields: [
      { key: 'age', label: 'Age (years)', labelAr: 'العمر (سنة)', type: 'number' },
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'gender', label: 'Gender', labelAr: 'الجنس', type: 'select', options: [
        { value: 'male', label: 'Male', labelAr: 'ذكر' },
        { value: 'female', label: 'Female', labelAr: 'أنثى' },
      ] },
      { key: 'scr', label: 'Serum Creatinine (mg/dL)', labelAr: 'الكرياتينين في المصل (ملغ/دل)', type: 'number', step: 0.01 },
    ],
  },
  {
    key: 'egfr', category: 'renal',
    title: 'eGFR', titleAr: 'معدل الترشيح الكبيبي المقدر',
    short: 'CKD-EPI 2021', shortAr: 'CKD-EPI 2021',
    long: 'Estimate glomerular filtration rate with CKD-EPI 2021.',
    longAr: 'قدّر معدل الترشيح الكبيبي بمعادلة CKD-EPI 2021.',
    icon: Sparkles,
    fields: [
      { key: 'age', label: 'Age', labelAr: 'العمر', type: 'number' },
      { key: 'gender', label: 'Gender', labelAr: 'الجنس', type: 'select', options: [
        { value: 'male', label: 'Male', labelAr: 'ذكر' },
        { value: 'female', label: 'Female', labelAr: 'أنثى' },
      ] },
      { key: 'scr', label: 'Serum Creatinine (mg/dL)', labelAr: 'الكرياتينين في المصل (ملغ/دل)', type: 'number', step: 0.01 },
    ],
  },
  {
    key: 'urine_output', category: 'renal',
    title: 'Urine Output', titleAr: 'إدرار البول',
    short: 'mL/kg/hr', shortAr: 'مل/كجم/س',
    long: 'Calculate urine output per kg per hour.',
    longAr: 'احسب إدرار البول لكل كجم في الساعة.',
    icon: Sparkles,
    fields: [
      { key: 'volume', label: 'Volume (mL)', labelAr: 'الحجم (مل)', type: 'number' },
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'hours', label: 'Time (hours)', labelAr: 'الوقت (س)', type: 'number', step: 0.1 },
    ],
  },
  {
    key: 'fluid_balance', category: 'renal',
    title: 'Fluid Balance', titleAr: 'رصيد السوائل',
    short: 'Intake − Output', shortAr: 'مدخول − مُخرجات',
    long: 'Compute net fluid balance from intake and output.',
    longAr: 'احسب الرصيد الصافي للسوائل من المدخول والمُخرجات.',
    icon: Sparkles,
    fields: [
      { key: 'intake', label: 'Intake (mL)', labelAr: 'المدخول (مل)', type: 'number' },
      { key: 'output', label: 'Output (mL)', labelAr: 'المُخرجات (مل)', type: 'number' },
    ],
  },
  // General
  {
    key: 'bmi', category: 'general',
    title: 'BMI', titleAr: 'مؤشر كتلة الجسم',
    short: 'Weight / Height²', shortAr: 'الوزن ÷ الطول²',
    long: 'Calculate body mass index with category.',
    longAr: 'احسب مؤشر كتلة الجسم مع التصنيف.',
    icon: ClipboardList,
    fields: [
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'heightCm', label: 'Height (cm)', labelAr: 'الطول (سم)', type: 'number', step: 0.1 },
    ],
  },
  {
    key: 'bsa', category: 'general',
    title: 'BSA', titleAr: 'مساحة سطح الجسم',
    short: 'Mosteller', shortAr: 'مُوستلَر',
    long: 'Calculate body surface area (Mosteller).',
    longAr: 'احسب مساحة سطح الجسم بمعادلة مُوستلَر.',
    icon: ClipboardList,
    fields: [
      { key: 'weight', label: 'Weight (kg)', labelAr: 'الوزن (كجم)', type: 'number', step: 0.1 },
      { key: 'heightCm', label: 'Height (cm)', labelAr: 'الطول (سم)', type: 'number', step: 0.1 },
    ],
  },
];

const DISCLAIMER = {
  en: 'These calculators are educational and clinical-support tools. They do not replace professional nursing judgment, physician orders, institutional protocols, or current clinical guidelines.',
  ar: 'هذه الحاسبات أدوات تعليمية وداعمة سريريًا. لا تحل محل الحكم التمريضي المهني أو أوامر الطبيب أو بروتوكولات المؤسسة أو الإرشادات السريرية الحديثة.',
};

export default function NursingCalculator() {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('nc-lang') as Lang) || 'en');
  const [query, setQuery] = useState('');
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [showRefs, setShowRefs] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<{ id: number; title: string; type: string; created_at: string; inputs: any; result: any }[]>([]);
  const [activeCat, setActiveCat] = useState<string>('all');
  const { toast } = useToast();
  const { user } = useAuth();
  const { dark } = useTheme();
  const resultRef = useRef<HTMLDivElement>(null);
  const isAr = lang === 'ar';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try { localStorage.setItem('nc-lang', lang); } catch { /* ignore */ }
  }, [lang]);

  useEffect(() => {
    if (user && showHistory) refreshHistory();
  }, [user, showHistory]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CALCS.filter((c) => {
      if (activeCat !== 'all' && c.category !== activeCat) return false;
      if (!q) return true;
      const hay = (c.title + ' ' + c.titleAr + ' ' + c.short + ' ' + c.shortAr + ' ' + c.key + ' ' + c.category).toLowerCase();
      return hay.includes(q);
    });
  }, [query, activeCat]);

  const counts = useMemo(() => {
    const out: Record<string, number> = {};
    for (const c of CALCS) out[c.category] = (out[c.category] || 0) + 1;
    return out;
  }, []);

  const selected = useMemo(() => CALCS.find((c) => c.key === selectedKey) || null, [selectedKey]);

  const setVal = (k: string, v: string) => setValues((s) => ({ ...s, [k]: v }));

  const reset = () => {
    setValues({});
    setResult(null);
  };

  const calculate = async () => {
    if (!selected) return;
    const fields: Record<string, any> = {};
    for (const f of selected.fields) fields[f.key] = values[f.key] ?? '';
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/ai-calculator-pro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: selected.key, lang, fields }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Request failed');
      setResult({ ...data, calcTitle: isAr ? selected.titleAr : selected.title });
      toast(isAr ? 'تم الحساب' : 'Calculated', 'success');
    } catch (err: any) {
      toast(err.message || 'Failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const copyResult = () => {
    if (!result) return;
    const txt = formatResult(result, isAr);
    navigator.clipboard.writeText(txt).then(() => toast(isAr ? 'تم النسخ' : 'Copied!', 'success'));
  };

  const downloadPdf = () => {
    if (!resultRef.current) return;
    const w = window.open('', '_blank', 'width=900,height=800');
    if (!w) return;
    const css = `
      body { font-family: ${isAr ? "'Cairo','Segoe UI',sans-serif" : "'Inter',sans-serif"}; padding: 32px; color: #111; direction: ${isAr ? 'rtl' : 'ltr'}; }
      h1, h2, h3 { color: #0c4a6e; }
      .ref { background:#f1f5f9; padding: 8px 12px; border-radius: 8px; margin: 6px 0; }
      .formula { background:#f8fafc; padding: 12px; border-radius: 8px; font-family: monospace; }
      .note { background:#fef3c7; padding: 12px; border-radius: 8px; }
      .disclaimer { background:#fef3c7; padding: 12px; border-radius: 8px; margin-top: 24px; border: 1px solid #fcd34d; }
      ol { padding-${isAr ? 'right' : 'left'}: 24px; }
    `;
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"/><title>${result.calcTitle}</title><style>${css}</style></head><body>${resultRef.current.innerHTML}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 300);
  };

  const shareLink = () => {
    const url = window.location.origin + '/ai-assistant/calculator';
    navigator.clipboard.writeText(url).then(() => toast(isAr ? 'تم نسخ الرابط' : 'Link copied!', 'success'));
  };

  const saveToHistory = async () => {
    if (!user) {
      toast(isAr ? 'سجّل الدخول لحفظ النتائج.' : 'Sign in to save calculations.', 'error');
      return;
    }
    if (!result || !selected) return;
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      // Save to localStorage (no new API needed) and to existing ai_analyses table.
      const local = JSON.parse(localStorage.getItem('nc-history') || '[]');
      const row = { id: Date.now(), title: result.calcTitle, type: selected.key, created_at: new Date().toISOString(), inputs: values, result };
      local.unshift(row);
      localStorage.setItem('nc-history', JSON.stringify(local.slice(0, 50)));
      toast(isAr ? 'تم الحفظ محليًا' : 'Saved locally', 'success');
      // (Optional) try server save
      if (token) {
        await fetch('/api/ai-history', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            title: `Calculator: ${result.calcTitle}`,
            top_diagnosis: `${result.result} ${result.unit || ''}`.slice(0, 80),
            case_data: { kind: 'calculator', calcKey: selected.key, inputs: values },
            report: { result: result.result, unit: result.unit, formula: result.formula, steps: result.steps, extra: result.extra, references: result.references },
          }),
        }).catch(() => {});
      }
      refreshHistory();
    } catch (err: any) {
      toast(err.message || 'Failed to save', 'error');
    }
  };

  const refreshHistory = async () => {
    if (!user) return;
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      const res = await fetch('/api/ai-history', { headers: { Authorization: `Bearer ${token}` } });
      const list = await res.json();
      const calcList = (list || []).filter((r: any) => r?.case_data?.kind === 'calculator');
      setHistory(calcList.map((r: any) => ({
        id: r.id, title: r.title, type: r.case_data?.calcKey, created_at: r.created_at,
        inputs: r.case_data?.inputs || {}, result: r.report || {},
      })));
    } catch { /* ignore */ }
  };

  const loadFromHistory = (h: any) => {
    setSelectedKey(h.type);
    setValues(h.inputs || {});
    setResult(h.result ? { ...h.result, calcTitle: h.title } : null);
    setShowHistory(false);
    toast(isAr ? 'تم التحميل' : 'Loaded', 'success');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200/70 py-14 dark:border-white/10">
        <div className="absolute inset-0 -z-10">
          <div className="absolute -left-24 top-0 h-72 w-72 rounded-full bg-sky-500/30 blur-3xl" />
          <div className="absolute right-0 top-20 h-72 w-72 rounded-full bg-emerald-400/30 blur-3xl" />
          <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" />
        </div>
        {/* Floating medical icons */}
        <div className="absolute inset-0 -z-10 pointer-events-none">
          <Pill className="absolute right-10 top-8 h-6 w-6 animate-float text-sky-400/40" />
          <Droplet className="absolute left-12 top-24 h-5 w-5 animate-float-delayed text-cyan-400/40" />
          <HeartPulse className="absolute right-1/4 top-12 h-5 w-5 animate-float text-rose-400/40" />
          <FlaskConical className="absolute bottom-12 left-20 h-5 w-5 animate-float-delayed text-emerald-400/40" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-12 lg:items-center">
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="lg:col-span-7">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-sky-400/40 bg-sky-500/10 px-3 py-1 text-xs font-semibold text-sky-600 dark:text-sky-300">
                <Sparkles className="h-3.5 w-3.5" /> {isAr ? 'أداة احترافية' : 'Professional Toolkit'}
              </div>
              <h1 className="bg-gradient-to-r from-sky-500 via-cyan-500 to-emerald-500 bg-clip-text text-4xl font-extrabold text-transparent sm:text-5xl">
                {isAr ? 'حاسبات التمريض' : 'Nursing Calculator'}
              </h1>
              <p className="mt-3 text-base text-slate-600 dark:text-slate-300 sm:text-lg">
                {isAr ? 'كل حسابات التمريض في مكان واحد' : 'All the nursing math in one place.'}
              </p>
              <p className="mt-2 max-w-2xl text-sm text-slate-500 dark:text-slate-400">
                {isAr ? '20 حاسبة طبية احترافية بصيغ علمية وخطوات ومراجع موثوقة.' : '20 professional medical calculators with formulas, steps, and trusted references.'}
              </p>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <div className="relative w-full max-w-md">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={isAr ? 'ابحث عن: MAP، CrCl، جرعة الأطفال، IV Flow...' : 'Search: MAP, CrCl, Pediatric Dose, IV Flow...'}
                    className="w-full rounded-2xl border border-slate-200 bg-white/70 px-10 py-3 text-sm shadow-sm backdrop-blur placeholder:text-slate-400 focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30 dark:border-white/10 dark:bg-white/5"
                  />
                </div>
                <button
                  onClick={() => setShowHistory((v) => !v)}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white/70 px-4 py-3 text-sm font-semibold backdrop-blur transition hover:border-sky-500 hover:text-sky-600 dark:border-white/10 dark:bg-white/5"
                >
                  <BookOpen className="h-4 w-4" /> {isAr ? 'السجل' : 'History'}
                </button>
                <button
                  onClick={() => setLang((l) => (l === 'en' ? 'ar' : 'en'))}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white/70 px-4 py-3 text-sm font-semibold backdrop-blur transition hover:border-sky-500 hover:text-sky-600 dark:border-white/10 dark:bg-white/5"
                >
                  <Globe className="h-4 w-4" /> {isAr ? 'English' : 'العربية'}
                </button>
              </div>
            </motion.div>

            {/* Quick access */}
            <div className="lg:col-span-5">
              <div className="rounded-3xl border border-slate-200/70 bg-white/70 p-5 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
                <div className="mb-3 inline-flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
                  <Sun className="h-4 w-4 text-amber-500" /> {isAr ? 'وصول سريع' : 'Quick access'}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {['map', 'crcl', 'bmi', 'egfr', 'peds_dose', 'iv_flow'].map((k) => {
                    const c = CALCS.find((x) => x.key === k);
                    if (!c) return null;
                    const Icon = c.icon;
                    return (
                      <button
                        key={k}
                        onClick={() => { setSelectedKey(k); reset(); }}
                        className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-start text-xs font-semibold transition hover:border-sky-500 hover:bg-sky-50/50 dark:border-white/10 dark:bg-white/5 dark:hover:bg-white/10"
                      >
                        <Icon className="h-4 w-4 text-sky-500" />
                        {isAr ? c.titleAr : c.title}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-amber-300/40 bg-amber-50/70 p-3 text-xs text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
            <div className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <p>{isAr ? DISCLAIMER.ar : DISCLAIMER.en}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-extrabold">{isAr ? 'الفئات' : 'Categories'}</h2>
          <button
            onClick={() => setActiveCat('all')}
            className={`rounded-full px-3 py-1 text-xs font-semibold transition ${activeCat === 'all' ? 'bg-sky-500 text-white shadow' : 'border border-slate-200 hover:border-sky-500 dark:border-white/10'}`}
          >{isAr ? 'الكل' : 'All'} ({CALCS.length})</button>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const count = counts[cat.key] || 0;
            const isActive = activeCat === cat.key;
            return (
              <button
                key={cat.key}
                onClick={() => setActiveCat(isActive ? 'all' : cat.key)}
                className={`group relative overflow-hidden rounded-2xl border bg-white/70 p-4 text-start shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-xl dark:bg-white/5 ${isActive ? 'border-sky-500 ring-2 ring-sky-500/30' : 'border-slate-200 dark:border-white/10'}`}
              >
                <div className={`absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br ${cat.gradient} opacity-20 blur-2xl transition group-hover:opacity-40`} />
                <div className={`relative mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${cat.gradient} text-white shadow`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="relative text-sm font-bold">{isAr ? cat.ar : cat.en}</div>
                <div className="relative mt-1 text-xs text-slate-500 dark:text-slate-400">{count} {isAr ? 'حاسبة' : 'calculators'}</div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Calculator list */}
      <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <h2 className="mb-3 text-lg font-extrabold">{isAr ? 'الحاسبات' : 'Calculators'}</h2>
            <div className="grid gap-3">
              {filtered.map((c) => {
                const Icon = c.icon;
                const active = c.key === selectedKey;
                return (
                  <button
                    key={c.key}
                    onClick={() => { setSelectedKey(c.key); reset(); }}
                    className={`group relative overflow-hidden rounded-2xl border bg-white/70 p-4 text-start shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:shadow-lg dark:bg-white/5 ${active ? 'border-sky-500 ring-2 ring-sky-500/30' : 'border-slate-200 dark:border-white/10'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${CATEGORIES.find((x) => x.key === c.category)?.gradient || 'from-sky-500 to-cyan-500'} text-white shadow`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-bold">{isAr ? c.titleAr : c.title}</div>
                        <div className="truncate text-xs text-slate-500 dark:text-slate-400">{isAr ? c.shortAr : c.short}</div>
                      </div>
                      <ChevronRight className={`ms-auto h-4 w-4 text-slate-400 transition ${active ? 'text-sky-500 translate-x-0.5' : ''}`} />
                    </div>
                  </button>
                );
              })}
              {filtered.length === 0 && (
                <div className="rounded-2xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500 dark:border-white/10">
                  {isAr ? 'لا توجد نتائج.' : 'No results.'}
                </div>
              )}
            </div>
          </div>

          {/* Active calculator */}
          <div className="lg:col-span-8">
            {!selected ? (
              <div className="flex h-full min-h-[400px] flex-col items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-white/40 p-10 text-center text-sm text-slate-500 dark:border-white/10 dark:bg-white/5">
                <CalcIcon className="mb-3 h-10 w-10 text-slate-400" />
                {isAr ? 'اختر حاسبة من القائمة أو ابحث في الشريط أعلاه.' : 'Select a calculator from the list or use the search above.'}
              </div>
            ) : (
              <CalculatorPanel
                calc={selected}
                lang={lang}
                values={values}
                onChange={setVal}
                onCalculate={calculate}
                onReset={reset}
                result={result}
                loading={loading}
                resultRef={resultRef}
                showRefs={showRefs}
                setShowRefs={setShowRefs}
                onCopy={copyResult}
                onPrint={() => window.print()}
                onPdf={downloadPdf}
                onShare={shareLink}
                onSave={saveToHistory}
                isAuthed={!!user}
              />
            )}
          </div>
        </div>

        {/* History drawer */}
        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
              className="mt-8 rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5"
            >
              <div className="mb-3 inline-flex items-center gap-2 text-base font-bold">
                <BookOpen className="h-4 w-4 text-sky-500" /> {isAr ? 'حساباتي' : 'My Calculations'}
              </div>
              {!user ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">{isAr ? 'سجّل الدخول لحفظ الحسابات في حسابك.' : 'Sign in to save calculations to your account.'}</p>
              ) : history.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">{isAr ? 'لا توجد حسابات محفوظة بعد.' : 'No saved calculations yet.'}</p>
              ) : (
                <ul className="grid gap-2 sm:grid-cols-2">
                  {history.map((h) => (
                    <li key={h.id} className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
                      <div className="min-w-0">
                        <div className="truncate font-semibold">{h.title}</div>
                        <div className="text-xs text-slate-400">{new Date(h.created_at).toLocaleString(isAr ? 'ar-EG' : 'en-US')}</div>
                      </div>
                      <button onClick={() => loadFromHistory(h)} className="rounded-lg border border-sky-400/40 bg-sky-500/10 px-2 py-1 text-xs font-semibold text-sky-600 hover:bg-sky-500/20 dark:text-sky-300">{isAr ? 'تحميل' : 'Load'}</button>
                    </li>
                  ))}
                </ul>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      <Footer />
    </div>
  );
}

function CalculatorPanel({
  calc, lang, values, onChange, onCalculate, onReset, result, loading, resultRef, showRefs, setShowRefs, onCopy, onPrint, onPdf, onShare, onSave, isAuthed,
}: {
  calc: CalcDef; lang: Lang; values: Record<string, string>; onChange: (k: string, v: string) => void;
  onCalculate: () => void; onReset: () => void;
  result: any; loading: boolean; resultRef: React.RefObject<HTMLDivElement>;
  showRefs: boolean; setShowRefs: (b: boolean) => void;
  onCopy: () => void; onPrint: () => void; onPdf: () => void; onShare: () => void; onSave: () => void;
  isAuthed: boolean;
}) {
  const isAr = lang === 'ar';
  const Icon = calc.icon;
  return (
    <div className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
      <div className="mb-4 flex items-start gap-4">
        <div className={`inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${CATEGORIES.find((c) => c.key === calc.category)?.gradient || 'from-sky-500 to-cyan-500'} text-white shadow-lg`}>
          <Icon className="h-6 w-6" />
        </div>
        <div>
          <h3 className="text-xl font-extrabold">{isAr ? calc.titleAr : calc.title}</h3>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{isAr ? calc.longAr : calc.long}</p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {calc.fields.map((f) => (
          <Field key={f.key} field={f} lang={lang} value={values[f.key] ?? ''} onChange={(v) => onChange(f.key, v)} />
        ))}
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        <button onClick={onCalculate} disabled={loading} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-sky-500/30 transition hover:opacity-90 disabled:opacity-60">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <CalcIcon className="h-4 w-4" />}
          {isAr ? 'احسب' : 'Calculate'}
        </button>
        <button onClick={onReset} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-semibold transition hover:border-rose-500 hover:text-rose-500 dark:border-white/10">
          <RefreshCw className="h-4 w-4" /> {isAr ? 'إعادة تعيين' : 'Reset'}
        </button>
        <div className="ms-auto flex flex-wrap items-center gap-2">
          {result && !result.error && (
            <>
              <button onClick={onCopy} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-sky-500 hover:text-sky-600 dark:border-white/10"><Copy className="h-3.5 w-3.5" /> {isAr ? 'نسخ' : 'Copy'}</button>
              <button onClick={onPdf} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-sky-500 hover:text-sky-600 dark:border-white/10"><Printer className="h-3.5 w-3.5" /> PDF</button>
              <button onClick={onPrint} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-sky-500 hover:text-sky-600 dark:border-white/10"><Printer className="h-3.5 w-3.5" /> {isAr ? 'طباعة' : 'Print'}</button>
              <button onClick={onShare} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-sky-500 hover:text-sky-600 dark:border-white/10"><Share2 className="h-3.5 w-3.5" /> {isAr ? 'مشاركة' : 'Share'}</button>
              <button onClick={onSave} className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 px-3 py-1.5 text-xs font-bold text-white shadow-md shadow-emerald-500/30">
                {isAuthed ? <Save className="h-3.5 w-3.5" /> : <Lock className="h-3.5 w-3.5" />}
                {isAr ? 'حفظ' : 'Save'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Result */}
      <AnimatePresence>
        {result && (
          <motion.div ref={resultRef} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-6 space-y-4 print:space-y-2">
            {result.error ? (
              <div className="rounded-2xl border border-rose-300 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
                <AlertTriangle className="me-2 inline h-4 w-4" /> {result.error}
              </div>
            ) : (
              <>
                <div className="rounded-3xl border border-sky-300 bg-gradient-to-br from-sky-50 via-white to-cyan-50 p-6 shadow-lg dark:border-sky-500/30 dark:from-sky-500/10 dark:via-sky-500/5 dark:to-cyan-500/10">
                  <div className="text-xs font-semibold uppercase tracking-wide text-sky-600 dark:text-sky-300">{isAr ? 'النتيجة' : 'Result'}</div>
                  <div className="mt-2 flex items-baseline gap-2">
                    <div className="text-4xl font-extrabold text-sky-700 dark:text-sky-300 sm:text-5xl">{result.result}</div>
                    <div className="text-lg font-bold text-slate-500 dark:text-slate-400">{result.unit}</div>
                  </div>
                  {result.extra && (
                    <div className="mt-2 text-sm font-medium text-slate-700 dark:text-slate-300">{result.extra}</div>
                  )}
                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm dark:border-white/10 dark:bg-white/5">
                  <div className="mb-2 font-bold text-slate-700 dark:text-slate-200">{isAr ? 'الصيغة' : 'Formula'}</div>
                  <div className="font-mono text-xs text-slate-600 dark:text-slate-300">{result.formula}</div>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm dark:border-white/10 dark:bg-white/5">
                  <div className="mb-2 font-bold text-slate-700 dark:text-slate-200">{isAr ? 'الخطوات' : 'Step-by-step'}</div>
                  <ol className="ms-4 list-decimal space-y-1 text-xs text-slate-700 dark:text-slate-300">
                    {(result.steps || []).map((s: string, i: number) => <li key={i}>{s}</li>)}
                  </ol>
                </div>

                <div className="rounded-2xl border border-emerald-300 bg-emerald-50 p-4 text-sm text-emerald-900 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-200">
                  <div className="mb-1 font-bold">{isAr ? 'ملاحظة سريرية' : 'Clinical Note'}</div>
                  <div className="text-xs">{result.clinicalNote}</div>
                </div>

                {showRefs && result.references && result.references.length > 0 && (
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm dark:border-white/10 dark:bg-white/5">
                    <div className="mb-2 inline-flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
                      <BookOpen className="h-4 w-4 text-sky-500" /> {isAr ? 'المراجع العلمية' : 'Scientific References'}
                    </div>
                    <ul className="space-y-2">
                      {result.references.map((r: any, j: number) => (
                        <li key={j} className="flex items-start gap-2 rounded-lg bg-slate-50 p-2 dark:bg-white/5">
                          <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-500" />
                          <a href={r.url} target="_blank" rel="noreferrer noopener" className="text-xs text-sky-700 hover:underline dark:text-sky-300">
                            <strong>{r.abbr}</strong> — {r.title}
                          </a>
                        </li>
                      ))}
                    </ul>
                    <button onClick={() => setShowRefs(false)} className="mt-2 text-xs text-slate-500 hover:text-slate-700 dark:text-slate-400">{isAr ? 'إخفاء المراجع' : 'Hide references'}</button>
                  </div>
                )}
                {!showRefs && (
                  <button onClick={() => setShowRefs(true)} className="text-xs text-sky-600 hover:underline dark:text-sky-300">{isAr ? 'إظهار المراجع' : 'Show references'}</button>
                )}

                <div className="rounded-2xl border border-amber-300 bg-amber-50 p-3 text-[11px] text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
                  {result.disclaimer || (isAr ? DISCLAIMER.ar : DISCLAIMER.en)}
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Field({ field, lang, value, onChange }: { field: Field; lang: Lang; value: string; onChange: (v: string) => void }) {
  const isAr = lang === 'ar';
  const label = isAr ? field.labelAr : field.label;
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="font-semibold text-slate-700 dark:text-slate-300">{label}</span>
      {field.type === 'select' ? (
        <select value={value} onChange={(e) => onChange(e.target.value)} className="rounded-xl border border-slate-300 bg-white/90 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5">
          <option value="">—</option>
          {(field.options || []).map((o) => <option key={o.value} value={o.value}>{isAr ? o.labelAr : o.label}</option>)}
        </select>
      ) : (
        <input
          type={field.type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={field.placeholder}
          min={field.min}
          step={field.step}
          className="rounded-xl border border-slate-300 bg-white/90 px-3 py-2 text-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30 dark:border-white/10 dark:bg-white/5"
        />
      )}
      {field.hint && <span className="text-[10px] text-slate-400">{isAr ? field.hintAr : field.hint}</span>}
    </label>
  );
}

function formatResult(r: any, isAr: boolean) {
  let s = '';
  s += `${r.calcTitle}\n`;
  s += `Result: ${r.result} ${r.unit || ''}\n`;
  if (r.extra) s += `${r.extra}\n`;
  s += `\nFormula: ${r.formula}\n\nStep-by-step:\n`;
  (r.steps || []).forEach((step: string, i: number) => s += `${i + 1}. ${step}\n`);
  s += `\nClinical Note: ${r.clinicalNote}\n`;
  if (r.references?.length) {
    s += `\nReferences:\n`;
    r.references.forEach((ref: any) => s += `- ${ref.abbr}: ${ref.title} (${ref.url})\n`);
  }
  s += `\n${r.disclaimer || ''}\n`;
  return s;
}
