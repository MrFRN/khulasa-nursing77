import { useEffect, useState } from 'react';
import { BarChart3, BookOpen, Cog, ShieldCheck, ToggleLeft, ToggleRight, Trash2 } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import { useToast } from '../../components/Toast';
import { getAiSettings, updateAiSettings, getAiAnalytics, getAiGuidelines, updateGuideline } from '../../lib/api';

type Tab = 'settings' | 'analytics' | 'guidelines';

export default function AdminAI() {
  const { toast } = useToast();
  const [tab, setTab] = useState<Tab>('settings');
  const [cfg, setCfg] = useState<any>({ enabled: true, disclaimer: '', rate_limit_per_hour: 30, max_history: 50, require_login_for_history: true });
  const [analytics, setAnalytics] = useState<any>(null);
  const [guidelines, setGuidelines] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    try {
      const [s, a, g] = await Promise.all([getAiSettings(), getAiAnalytics(), getAiGuidelines()]);
      setCfg((c: any) => ({ ...c, ...s, rate_limit_per_hour: c.rate_limit_per_hour || 30, max_history: c.max_history || 50, require_login_for_history: c.require_login_for_history !== false }));
      setAnalytics(a); setGuidelines(g.filter((x: any) => x.abbr !== 'AI_CONFIG'));
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };

  const saveSettings = async () => {
    setSaving(true);
    try { await updateAiSettings(cfg); toast('تم حفظ إعدادات الذكاء الاصطناعي', 'success'); }
    catch (e: any) { toast(e.message, 'error'); } finally { setSaving(false); }
  };

  const toggleGuideline = async (g: any) => {
    try { await updateGuideline(g.id, { enabled: !g.enabled }); setGuidelines((gs) => gs.map((x) => x.id === g.id ? { ...x, enabled: !x.enabled } : x)); }
    catch (e: any) { toast(e.message, 'error'); }
  };
  const saveGuidelineUrl = async (g: any, url: string) => {
    try { await updateGuideline(g.id, { url }); toast('تم تحديث الرابط', 'success'); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  const maxDisease = Math.max(1, ...(analytics?.topDiseases || []).map((d: any) => d.count));
  const maxSym = Math.max(1, ...(analytics?.commonSymptoms || []).map((d: any) => d.count));

  return (
    <AdminShell title="المساعد السريري الذكي">
      <div className="mb-5 flex flex-wrap gap-2">
        {([['settings', 'الإعدادات', Cog], ['analytics', 'التحليلات', BarChart3], ['guidelines', 'المراجع', BookOpen]] as const).map(([k, label, Icon]) => (
          <button key={k} onClick={() => setTab(k as Tab)} className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition ${tab === k ? 'bg-gradient-to-l from-primary to-primary-600 text-white' : 'border border-slate-200 text-slate-600 dark:border-white/10 dark:text-slate-300'}`}>
            <Icon className="h-4 w-4" /> {label}
          </button>
        ))}
      </div>

      {loading ? <p className="text-slate-400">جارٍ التحميل…</p> : (
        <>
          {tab === 'settings' && (
            <div className="max-w-2xl space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white"><ShieldCheck className="h-5 w-5 text-primary" /> تفعيل المساعد الذكي</div>
                <button onClick={() => setCfg((c: any) => ({ ...c, enabled: !c.enabled }))} className="text-primary">
                  {cfg.enabled ? <ToggleRight className="h-7 w-7" /> : <ToggleLeft className="h-7 w-7 text-slate-400" />}
                </button>
              </div>
              <div><label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">تنبيه الإخلاء المسؤولية</label>
                <textarea className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white" rows={3} value={cfg.disclaimer} onChange={(e) => setCfg((c: any) => ({ ...c, disclaimer: e.target.value }))} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="mb-1 block text-sm font-semibold">حد الطلبات/ساعة</label><input type="number" className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5 dark:text-white" value={cfg.rate_limit_per_hour} onChange={(e) => setCfg((c: any) => ({ ...c, rate_limit_per_hour: Number(e.target.value) }))} /></div>
                <div><label className="mb-1 block text-sm font-semibold">أقصى عدد تحليلات محفوظة</label><input type="number" className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5 dark:text-white" value={cfg.max_history} onChange={(e) => setCfg((c: any) => ({ ...c, max_history: Number(e.target.value) }))} /></div>
              </div>
              <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={!!cfg.require_login_for_history} onChange={(e) => setCfg((c: any) => ({ ...c, require_login_for_history: e.target.checked }))} /> اشتراط تسجيل الدخول لحفظ السجل</label>
              <button onClick={saveSettings} disabled={saving} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-6 py-2.5 text-sm font-bold text-white disabled:opacity-60">{saving ? 'جارٍ…' : 'حفظ الإعدادات'}</button>
            </div>
          )}

          {tab === 'analytics' && (
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
                <h3 className="mb-3 font-bold text-slate-900 dark:text-white">أكثر التشخيصات بحثاً</h3>
                <div className="space-y-2">
                  {(analytics?.topDiseases || []).length === 0 && <p className="text-sm text-slate-400">لا توجد بيانات بعد.</p>}
                  {(analytics?.topDiseases || []).map((d: any, i: number) => (
                    <div key={i}><div className="flex justify-between text-sm"><span className="font-semibold text-slate-700 dark:text-slate-200">{d.name}</span><span className="text-slate-400">{d.count}</span></div><div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10"><div className="h-full rounded-full bg-gradient-to-l from-primary to-secondary" style={{ width: `${(d.count / maxDisease) * 100}%` }} /></div></div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
                <h3 className="mb-3 font-bold text-slate-900 dark:text-white">الأعراض الأكثر شيوعاً</h3>
                <div className="space-y-2">
                  {(analytics?.commonSymptoms || []).length === 0 && <p className="text-sm text-slate-400">لا توجد بيانات بعد.</p>}
                  {(analytics?.commonSymptoms || []).map((s: any, i: number) => (
                    <div key={i}><div className="flex justify-between text-sm"><span className="font-semibold text-slate-700 dark:text-slate-200">{s.id}</span><span className="text-slate-400">{s.count}</span></div><div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10"><div className="h-full rounded-full bg-gradient-to-l from-accent to-orange-500" style={{ width: `${(s.count / maxSym) * 100}%` }} /></div></div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5 lg:col-span-2">
                <div className="flex gap-6 text-sm">
                  <div><div className="text-2xl font-extrabold text-primary">{analytics?.totalAnalyses || 0}</div><div className="text-slate-400">إجمالي التحليلات المحفوظة</div></div>
                  <div><div className="text-2xl font-extrabold text-secondary">{analytics?.periodAnalyses || 0}</div><div className="text-slate-400">خلال 30 يوماً</div></div>
                </div>
              </div>
            </div>
          )}

          {tab === 'guidelines' && (
            <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-white/10 dark:bg-white/5">
              <table className="w-full text-right text-sm">
                <thead className="border-b border-slate-100 text-xs text-slate-400 dark:border-white/10"><tr><th className="p-3">الجهة</th><th className="p-3">الاسم</th><th className="p-3">الرابط</th><th className="p-3">حالة</th></tr></thead>
                <tbody>
                  {guidelines.map((g) => (
                    <tr key={g.id} className="border-b border-slate-50 dark:border-white/5">
                      <td className="p-3 font-bold text-primary">{g.abbr}</td>
                      <td className="p-3 text-slate-700 dark:text-slate-200">{g.name}</td>
                      <td className="p-3"><input defaultValue={g.url} onBlur={(e) => e.target.value !== g.url && saveGuidelineUrl(g, e.target.value)} className="w-72 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white" /></td>
                      <td className="p-3"><button onClick={() => toggleGuideline(g)} className="text-primary">{g.enabled ? <ToggleRight className="h-6 w-6" /> : <ToggleLeft className="h-6 w-6 text-slate-400" />}</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </AdminShell>
  );
}
