import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Upload, FileStack, CheckCircle2, Download, Users, Clock, TrendingUp } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import Spinner from '../../components/Spinner';
import StorageMeter from '../../components/StorageMeter';
import TrendChart from '../../components/TrendChart';
import { fetchAnalytics } from '../../lib/api';
import { formatNumber, timeAgo } from '../../lib/format';
import { SECTIONS } from '../../lib/constants';
import type { Analytics } from '../../types';

function Tile({ icon, label, value, gradient }: { icon: React.ReactNode; label: string; value: React.ReactNode; gradient: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
      <div className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-white`}>{icon}</div>
      <p className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">{value}</p>
      <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">{label}</p>
    </div>
  );
}

export default function Dashboard() {
  const [a, setA] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchAnalytics().then(setA).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, []);

  return (
    <AdminShell title="لوحة التحكم">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-slate-500 dark:text-slate-400">نظرة عامة على أداء المكتبة.</p>
        <Link to="/admin/upload" className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2.5 text-sm font-bold text-white"><Upload className="h-4.5 w-4.5" /> رفع ملف</Link>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Spinner label="جارٍ التحميل…" /></div>
      ) : error || !a ? (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-500/20 dark:bg-red-500/10">{error}</div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Tile icon={<FileStack className="h-5 w-5" />} label="إجمالي الملفات" value={formatNumber(a.total)} gradient="from-primary to-primary-600" />
            <Tile icon={<CheckCircle2 className="h-5 w-5" />} label="منشور" value={formatNumber(a.published)} gradient="from-secondary to-secondary-600" />
            <Tile icon={<Download className="h-5 w-5" />} label="التحميلات" value={formatNumber(a.downloads)} gradient="from-accent to-orange-500" />
            <Tile icon={<Users className="h-5 w-5" />} label="الزيارات" value={formatNumber(a.visitors)} gradient="from-purple-500 to-primary" />
          </div>

          <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-4 flex items-center gap-2 font-bold text-slate-900 dark:text-white"><TrendingUp className="h-5 w-5 text-primary" /> النشاط آخر 14 يوم</h3>
              <TrendChart series={a.series} />
            </div>
            <div className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
                <StorageMeter used={a.used} quota={a.quota} />
                {a.scheduled > 0 && <p className="mt-3 flex items-center gap-1.5 text-xs text-slate-400"><Clock className="h-3.5 w-3.5" /> {a.scheduled} مجدول لاحقًا</p>}
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
                <h3 className="mb-4 font-bold text-slate-900 dark:text-white">المحتوى حسب القسم</h3>
                <div className="space-y-3">
                  {Object.entries(a.bySection).map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-300">{SECTIONS[k as keyof typeof SECTIONS]?.label || k}</span>
                      <span className="font-bold text-slate-900 dark:text-white">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-4 font-bold text-slate-900 dark:text-white">الأكثر تحميلًا</h3>
              <div className="space-y-3">
                {a.topDownloaded.length === 0 && <p className="text-sm text-slate-400">لا توجد بيانات.</p>}
                {a.topDownloaded.map((r, i) => (
                  <Link key={r.id} to={`/resource/${r.id}`} className="flex items-center gap-3">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">{i + 1}</span>
                    <span className="min-w-0 flex-1 truncate text-sm text-slate-700 dark:text-slate-200">{r.title}</span>
                    <span className="inline-flex items-center gap-1 text-xs text-slate-400"><Download className="h-3 w-3" /> {r.download_count}</span>
                  </Link>
                ))}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-4 font-bold text-slate-900 dark:text-white">أحدث الإضافات</h3>
              <div className="space-y-3">
                {a.recent.map((r) => (
                  <Link key={r.id} to={`/resource/${r.id}`} className="flex items-center gap-3">
                    <div className="flex h-9 w-7 shrink-0 items-center justify-center overflow-hidden rounded bg-slate-100 dark:bg-white/10">{r.cover_image_url ? <img src={r.cover_image_url} alt="" className="h-full w-full object-cover" /> : <FileStack className="h-4 w-4 text-slate-400" />}</div>
                    <span className="min-w-0 flex-1 truncate text-sm text-slate-700 dark:text-slate-200">{r.title}</span>
                    <span className="shrink-0 text-xs text-slate-400">{timeAgo(r.created_at)}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminShell>
  );
}
