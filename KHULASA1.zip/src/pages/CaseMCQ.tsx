import { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle, ArrowLeft, Award, BookOpen, Brain, Calculator, Check,
  ChevronLeft, ChevronRight, ClipboardList, Clock, ExternalLink, Eye,
  Filter, Flame, Globe, Heart, HeartPulse, Lightbulb, Lock, MessageSquare,
  Pause, Play, RefreshCw, RotateCcw, Save, Search, Shield, ShieldCheck,
  Sparkles, Star, Stethoscope, Sun, Target, Timer, TrendingUp, Trophy, X,
  Zap,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useToast } from '../components/Toast';
import { useTheme } from '../contexts/ThemeContext';

type Lang = 'en' | 'ar';

interface MCQOption { A: string; B: string; C: string; D: string }
interface MCQQuestion { id: number; position: number; stem: string; options: MCQOption }
interface MCQCase {
  id: number; slug: string; title: string; condition: string;
  specialty: string; difficulty: string;
  patient: {
    age: number; gender: string; chief_complaint: string; history: string;
    symptoms: string[]; allergies: string[]; medications: any[];
    vitals: any; labs: any; physical_exam: string; narrative_intro: string;
  };
  learning_points: string[]; references: any[];
  questions: MCQQuestion[];
}
interface GradeResult {
  case_id: number; case_title: string; condition: string;
  score: number; total: number; percentage: number;
  level_key: string; level: any;
  learning_points: string[]; references: any[];
  source_url: string | null; guideline_version: string | null;
  weak_topics: Record<string, number>;
  strong_topics: Record<string, number>;
  correct_count: number; incorrect_count: number;
  per_question: Array<{
    question_id: number; position: number; stem: string;
    user_answer: string | null; correct_answer: string; is_correct: boolean;
    options: MCQOption;
    explanation: string;
    why_wrong: { A: string; B: string; C: string; D: string };
    reference: { label: string | null; url: string | null };
    category: string | null;
  }>;
  mistakes: any[];
  disclaimer: string;
}

const SPECIALTY_META: Record<string, { en: string; ar: string; icon: any; gradient: string }> = {
  cardiology: { en: 'Cardiology', ar: 'القلب', icon: HeartPulse, gradient: 'from-rose-500 to-red-500' },
  icu: { en: 'ICU', ar: 'ICU', icon: Brain, gradient: 'from-indigo-500 to-violet-500' },
  emergency: { en: 'Emergency', ar: 'الطوارئ', icon: Zap, gradient: 'from-amber-500 to-orange-500' },
  pediatrics: { en: 'Pediatrics', ar: 'الأطفال', icon: Heart, gradient: 'from-pink-500 to-rose-500' },
  dialysis: { en: 'Dialysis', ar: 'غسيل الكلى', icon: HeartPulse, gradient: 'from-violet-500 to-purple-500' },
  neurology: { en: 'Neurology', ar: 'الأعصاب', icon: Brain, gradient: 'from-purple-500 to-indigo-500' },
  respiratory: { en: 'Respiratory', ar: 'الجهاز التنفسي', icon: Stethoscope, gradient: 'from-sky-500 to-blue-500' },
  'medical-surgical': { en: 'Med-Surg', ar: 'الباطنية والجراحية', icon: ClipboardList, gradient: 'from-teal-500 to-emerald-500' },
  surgical: { en: 'Surgical', ar: 'الجراحة', icon: ClipboardList, gradient: 'from-cyan-500 to-teal-500' },
  nicu: { en: 'NICU', ar: 'NICU', icon: Heart, gradient: 'from-fuchsia-500 to-pink-500' },
  maternity: { en: 'Maternity', ar: 'الأمومة', icon: Heart, gradient: 'from-pink-400 to-rose-500' },
  gynecology: { en: 'Gynecology', ar: 'النسائية', icon: Heart, gradient: 'from-rose-400 to-pink-500' },
  psychiatric: { en: 'Psychiatric', ar: 'النفسي', icon: Brain, gradient: 'from-indigo-500 to-purple-500' },
  oncology: { en: 'Oncology', ar: 'الأورام', icon: ShieldCheck, gradient: 'from-pink-500 to-rose-600' },
  endocrine: { en: 'Endocrine', ar: 'الغدد الصماء', icon: Sparkles, gradient: 'from-emerald-500 to-cyan-500' },
  'infectious-diseases': { en: 'Infectious', ar: 'المعدية', icon: Shield, gradient: 'from-emerald-600 to-teal-600' },
  hematology: { en: 'Hematology', ar: 'الدم', icon: Heart, gradient: 'from-red-500 to-rose-500' },
  geriatrics: { en: 'Geriatric', ar: 'كبار السن', icon: Heart, gradient: 'from-amber-400 to-orange-400' },
  burns: { en: 'Burns', ar: 'الحروق', icon: Flame, gradient: 'from-orange-500 to-red-600' },
  trauma: { en: 'Trauma', ar: 'الرضوح', icon: ShieldCheck, gradient: 'from-red-600 to-orange-500' },
  orthopedic: { en: 'Orthopedic', ar: 'العظام', icon: ClipboardList, gradient: 'from-slate-500 to-blue-500' },
  urology: { en: 'Urology', ar: 'المسالك', icon: Heart, gradient: 'from-sky-400 to-blue-500' },
  ent: { en: 'ENT', ar: 'الأنف والأذن', icon: Sparkles, gradient: 'from-emerald-400 to-teal-400' },
  ophthalmology: { en: 'Ophthalmology', ar: 'العيون', icon: Sparkles, gradient: 'from-cyan-400 to-sky-400' },
  'wound-care': { en: 'Wound Care', ar: 'الجروح', icon: ShieldCheck, gradient: 'from-pink-400 to-rose-500' },
  'pain-management': { en: 'Pain Mgmt', ar: 'الألم', icon: Heart, gradient: 'from-orange-500 to-red-500' },
  'infection-control': { en: 'Infection Ctrl', ar: 'مكافحة العدوى', icon: Shield, gradient: 'from-cyan-500 to-blue-600' },
  'palliative-care': { en: 'Palliative', ar: 'التلطيفية', icon: Heart, gradient: 'from-violet-400 to-purple-500' },
  'home-health': { en: 'Home Health', ar: 'المنزلية', icon: Heart, gradient: 'from-emerald-400 to-teal-500' },
  rehabilitation: { en: 'Rehabilitation', ar: 'التأهيل', icon: Heart, gradient: 'from-cyan-500 to-blue-500' },
};

export default function CaseMCQ() {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('mcq-lang') as Lang) || 'en');
  const [view, setView] = useState<'lobby' | 'play' | 'result'>('lobby');
  const [cases, setCases] = useState<any[]>([]);
  const [specialty, setSpecialty] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'newest' | 'popular' | 'featured' | 'random'>('newest');
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);

  const [activeCase, setActiveCase] = useState<MCQCase | null>(null);
  const [questionIdx, setQuestionIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [elapsed, setElapsed] = useState(0);
  const [gradeResult, setGradeResult] = useState<GradeResult | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const { toast } = useToast();
  const { dark } = useTheme();
  const isAr = lang === 'ar';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try { localStorage.setItem('mcq-lang', lang); } catch { /* ignore */ }
  }, [lang]);

  useEffect(() => {
    loadCases();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [specialty, sort, search, view]);

  async function loadCases() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('sort', sort);
      params.set('lang', lang);
      params.set('page', String(page));
      params.set('pageSize', '24');
      if (specialty !== 'all') params.set('specialty', specialty);
      if (search) params.set('search', search);
      const res = await fetch('/api/mcq-list?' + params.toString());
      const data = await res.json();
      setCases(data.items || []);
      setHasMore(!!data.hasMore);
    } catch { /* ignore */ }
    setLoading(false);
  }

  const filteredSpecialties = useMemo(() => {
    const map: Record<string, number> = {};
    cases.forEach((c: any) => { map[c.specialty] = (map[c.specialty] || 0) + 1; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [cases]);

  async function startCase(slug: string) {
    try {
      const res = await fetch('/api/mcq-start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setActiveCase(data.case);
      setQuestionIdx(0);
      setAnswers({});
      setRevealed({});
      setStartTime(Date.now());
      setElapsed(0);
      setGradeResult(null);
      setView('play');
    } catch (e: any) {
      toast(e.message || 'Failed', 'error');
    }
  }

  async function startRandom() {
    try {
      const res = await fetch('/api/mcq-start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ random: 1, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setActiveCase(data.case);
      setQuestionIdx(0);
      setAnswers({});
      setRevealed({});
      setStartTime(Date.now());
      setElapsed(0);
      setGradeResult(null);
      setView('play');
    } catch (e: any) {
      toast(e.message || 'Failed', 'error');
    }
  }

  function selectAnswer(qid: number, letter: string) {
    if (revealed[qid]) return;
    setAnswers((a) => ({ ...a, [qid]: letter }));
    setRevealed((r) => ({ ...r, [qid]: true }));
  }

  async function submitAll() {
    if (!activeCase) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/mcq-grade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caseId: activeCase.id, answers, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setGradeResult(data);
      setView('result');
    } catch (e: any) {
      toast(e.message || 'Failed', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  // Render
  if (view === 'play' && activeCase) {
    return (
      <PlayView
        activeCase={activeCase}
        questionIdx={questionIdx}
        setQuestionIdx={setQuestionIdx}
        answers={answers}
        revealed={revealed}
        selectAnswer={selectAnswer}
        submitAll={submitAll}
        submitting={submitting}
        lang={lang}
        setLang={setLang}
        onExit={() => setView('lobby')}
        startTime={startTime}
      />
    );
  }
  if (view === 'result' && gradeResult) {
    return (
      <ResultView
        result={gradeResult}
        activeCase={activeCase}
        lang={lang}
        setLang={setLang}
        onTryAgain={() => { if (activeCase) startCase(activeCase.slug); }}
        onRandom={startRandom}
        onBackToLobby={() => setView('lobby')}
      />
    );
  }
  return (
    <LobbyView
      lang={lang}
      setLang={setLang}
      cases={cases}
      loading={loading}
      specialty={specialty}
      setSpecialty={setSpecialty}
      search={search}
      setSearch={setSearch}
      sort={sort}
      setSort={setSort}
      hasMore={hasMore}
      page={page}
      setPage={setPage}
      filteredSpecialties={filteredSpecialties}
      onStart={startCase}
      onRandom={startRandom}
    />
  );
}

function LobbyView(props: any) {
  const { lang, setLang, cases, loading, specialty, setSpecialty, search, setSearch, sort, setSort, hasMore, page, setPage, filteredSpecialties, onStart, onRandom } = props;
  const isAr = lang === 'ar';

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200/70 py-14 dark:border-white/10">
        <div className="absolute inset-0 -z-10">
          <div className="absolute -left-24 top-0 h-72 w-72 rounded-full bg-sky-500/25 blur-3xl" />
          <div className="absolute -right-24 top-20 h-72 w-72 rounded-full bg-emerald-500/25 blur-3xl" />
          <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-violet-500/20 blur-3xl" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-12 lg:items-center">
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="lg:col-span-7">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-300">
                <Sparkles className="h-3.5 w-3.5" /> {isAr ? 'ميزة جديدة' : 'New Feature'}
              </div>
              <h1 className="bg-gradient-to-r from-sky-500 via-emerald-500 to-violet-500 bg-clip-text text-4xl font-extrabold text-transparent sm:text-5xl">
                {isAr ? 'حالات تعليمية قائمة على MCQ' : 'Case-Based Nursing MCQ'}
              </h1>
              <p className="mt-3 text-lg font-medium text-slate-700 dark:text-slate-200">
                {isAr ? 'حالات سريرية مع أسئلة متعددة الخيارات متصلة' : 'Clinical cases with connected multiple-choice questions'}
              </p>
              <p className="mt-2 max-w-2xl text-sm text-slate-600 dark:text-slate-400">
                {isAr ? 'كل حالة تحتوي على 8-10 أسئلة MCQ متدرجة. تقييم، أولويات، حكم سريري، إعادة تقييم.' : 'Each case contains 8-10 progressive MCQs: assessment, priorities, clinical judgment, reassessment.'}
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button onClick={onRandom} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-sky-500/30 transition hover:opacity-90">
                  <Sparkles className="h-4 w-4" /> {isAr ? 'حالة عشوائية' : 'Random Case'}
                </button>
                <div className="relative w-full max-w-md">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isAr ? 'ابحث في المكتبة...' : 'Search library...'} className="w-full rounded-2xl border border-slate-200 bg-white/70 px-10 py-3 text-sm shadow-sm backdrop-blur focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30 dark:border-white/10 dark:bg-white/5" />
                </div>
                <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white/70 px-4 py-3 text-sm font-semibold backdrop-blur hover:border-sky-500 dark:border-white/10 dark:bg-white/5">
                  <Globe className="h-4 w-4" /> {isAr ? 'English' : 'العربية'}
                </button>
              </div>
            </motion.div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl border border-slate-200/70 bg-white/70 p-5 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
                <div className="mb-3 inline-flex items-center gap-2 text-sm font-bold">
                  <BookOpen className="h-4 w-4 text-sky-500" /> {isAr ? 'كيف يعمل' : 'How it works'}
                </div>
                <ol className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                  <li>1. {isAr ? 'اختر حالة من المكتبة' : 'Pick a case from the library'}</li>
                  <li>2. {isAr ? 'أجب عن 8-10 أسئلة متدرجة' : 'Answer 8-10 progressive questions'}</li>
                  <li>3. {isAr ? 'احصل على شرح فوري لكل سؤال' : 'Get instant explanation per question'}</li>
                  <li>4. {isAr ? 'شاهد نتيجتك ونقاط التعلم' : 'See score + learning points'}</li>
                </ol>
                <div className="mt-4 rounded-xl border border-amber-300/40 bg-amber-50/70 p-3 text-[11px] text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
                  <AlertTriangle className="me-1 inline h-3 w-3" /> {isAr ? 'للأغراض التعليمية فقط.' : 'Educational use only.'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters + Library */}
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <button onClick={() => setSpecialty('all')} className={`rounded-full px-3 py-1.5 text-xs font-bold transition ${specialty === 'all' ? 'bg-gradient-to-r from-sky-500 to-emerald-500 text-white shadow' : 'border border-slate-200 hover:border-sky-500 dark:border-white/10'}`}>
            {isAr ? 'كل التخصصات' : 'All Specialties'} ({cases.length})
          </button>
          {filteredSpecialties.slice(0, 12).map(([key, count]) => {
            const meta = SPECIALTY_META[key] || { en: key, ar: key, icon: Stethoscope, gradient: 'from-slate-400 to-slate-500' };
            const Icon = meta.icon;
            const active = specialty === key;
            return (
              <button key={key} onClick={() => setSpecialty(active ? 'all' : key)} className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition ${active ? `bg-gradient-to-r ${meta.gradient} text-white shadow` : 'border border-slate-200 hover:border-sky-500 dark:border-white/10'}`}>
                <Icon className="h-3.5 w-3.5" /> {isAr ? meta.ar : meta.en} <span className="opacity-70">{count}</span>
              </button>
            );
          })}
        </div>
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'الترتيب' : 'Sort'}:</span>
          {[
            { key: 'newest', en: 'Newest', ar: 'الأحدث' },
            { key: 'popular', en: 'Popular', ar: 'الأكثر شعبية' },
            { key: 'featured', en: 'Featured', ar: 'المميزة' },
            { key: 'random', en: 'Random', ar: 'عشوائي' },
          ].map((s) => (
            <button key={s.key} onClick={() => setSort(s.key as any)} className={`rounded-full px-3 py-1.5 text-xs font-bold transition ${sort === s.key ? 'bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow' : 'border border-slate-200 hover:border-violet-500 dark:border-white/10'}`}>
              {isAr ? s.ar : s.en}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="py-12 text-center text-sm text-slate-500 dark:text-slate-400">
            <Loader2 className="mx-auto mb-2 h-6 w-6 animate-spin" /> {isAr ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : cases.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-sm text-slate-500 dark:border-white/10">
            {isAr ? 'لا توجد حالات متاحة بعد.' : 'No cases available yet.'}
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {cases.map((c: any) => {
              const meta = SPECIALTY_META[c.specialty] || { en: c.specialty, ar: c.specialty, icon: Stethoscope, gradient: 'from-slate-400 to-slate-500' };
              const Icon = meta.icon;
              return (
                <button key={c.id} onClick={() => onStart(c.slug)} className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white/80 p-4 text-start shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-xl dark:border-white/10 dark:bg-white/5">
                  <div className={`absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br ${meta.gradient} opacity-20 blur-2xl transition group-hover:opacity-40`} />
                  <div className="relative mb-2 flex items-center justify-between">
                    <div className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${meta.gradient} text-white shadow`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">
                      {isAr ? c.difficulty : c.difficulty}
                    </span>
                  </div>
                  <div className="relative text-sm font-bold">{isAr ? c.title_ar : c.title_en}</div>
                  <div className="relative mt-1 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">{isAr ? c.condition_ar : c.condition_en}</div>
                  <div className="relative mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-[10px] text-slate-400 dark:border-white/10">
                    <span>{isAr ? meta.ar : meta.en}</span>
                    <span>{c.patient_age}y · {c.patient_gender}</span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
}

function Loader2(props: any) {
  return <svg {...props} className={(props.className || '') + ' animate-spin'} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></svg>;
}

function PlayView(props: any) {
  const { activeCase, questionIdx, setQuestionIdx, answers, revealed, selectAnswer, submitAll, submitting, lang, setLang, onExit, startTime } = props;
  const isAr = lang === 'ar';
  const q = activeCase.questions[questionIdx];
  const total = activeCase.questions.length;
  const answered = Object.keys(revealed).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white/80 p-4 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
          <div className="flex items-center gap-3">
            <button onClick={onExit} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-rose-500 hover:text-rose-500 dark:border-white/10">
              <ArrowLeft className="h-3.5 w-3.5" /> {isAr ? 'خروج' : 'Exit'}
            </button>
            <div className="text-sm font-bold">{isAr ? activeCase.title_ar : activeCase.title}</div>
            <span className="rounded-full bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-700 dark:bg-sky-500/15 dark:text-sky-300">
              {isAr ? activeCase.condition_ar : activeCase.condition}
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
              {isAr ? `سؤال ${questionIdx + 1} / ${total}` : `Q ${questionIdx + 1} / ${total}`}
            </span>
            <span className="rounded-full bg-violet-100 px-2 py-0.5 font-bold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
              {isAr ? `تم ${answered}` : `${answered} done`}
            </span>
            <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 font-semibold hover:border-sky-500 dark:border-white/10">
              <Globe className="h-3.5 w-3.5" /> {isAr ? 'EN' : 'AR'}
            </button>
          </div>
        </div>

        {/* Two-column layout */}
        <div className="grid gap-4 lg:grid-cols-12">
          {/* Patient case (left) */}
          <aside className="space-y-3 lg:col-span-4">
            <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 shadow-lg backdrop-blur dark:border-white/10 dark:bg-white/5">
              <div className="mb-2 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-sky-600 dark:text-sky-300">
                <Heart className="h-3.5 w-3.5" /> {isAr ? 'الحالة' : 'Case'}
              </div>
              <div className="text-sm font-bold">{isAr ? 'مريض' : 'Patient'} {activeCase.patient.age}y {activeCase.patient.gender}</div>
              <div className="mt-1 text-xs text-slate-500 dark:text-slate-400"><strong>{isAr ? 'الشكوى' : 'CC'}:</strong> {activeCase.patient.chief_complaint}</div>
              <div className="mt-1 text-xs text-slate-500 dark:text-slate-400"><strong>{isAr ? 'التاريخ' : 'HPI'}:</strong> {activeCase.patient.history}</div>
              <div className="mt-2 flex flex-wrap gap-1">
                {Object.entries(activeCase.patient.vitals || {}).map(([k, v]: any) => (
                  <span key={k} className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">{k.toUpperCase()}: {String(v)}</span>
                ))}
              </div>
              <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400"><strong>{isAr ? 'الحساسية' : 'Allergies'}:</strong> {(activeCase.patient.allergies || []).join(', ') || 'NKDA'}</div>
              <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400"><strong>{isAr ? 'الأدوية' : 'Meds'}:</strong> {(activeCase.patient.medications || []).map((m: any) => `${m.name} ${m.dose}`).join('; ')}</div>
              <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400"><strong>{isAr ? 'التحاليل' : 'Labs'}:</strong> {Object.entries(activeCase.patient.labs || {}).map(([k, v]: any) => `${k}=${v}`).join(', ')}</div>
            </div>
          </aside>

          {/* Question (right) */}
          <section className="lg:col-span-8">
            <AnimatePresence mode="wait">
              <motion.div key={q.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="rounded-3xl border border-slate-200 bg-white/80 p-5 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
                <div className="mb-1 text-[10px] font-bold uppercase tracking-wide text-violet-600 dark:text-violet-400">
                  {isAr ? `السؤال ${questionIdx + 1} من ${total}` : `Question ${questionIdx + 1} of ${total}`} · {q.category}
                </div>
                <div className="mb-4 text-base font-bold leading-relaxed">{q.stem}</div>
                <div className="grid gap-2">
                  {(['A', 'B', 'C', 'D'] as const).map((L) => {
                    const isPicked = answers[q.id] === L;
                    const isRevealed = !!revealed[q.id];
                    const text = q.options[L];
                    const isCorrectAnswer = isRevealed && activeCase.questions[questionIdx] && isPicked;
                    return (
                      <button key={L} onClick={() => selectAnswer(q.id, L)} disabled={isRevealed} className={`group flex items-start gap-3 rounded-2xl border p-3 text-start text-sm transition ${
                        isPicked ? (isCorrectAnswer ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-500/10' : 'border-rose-500 bg-rose-50 dark:bg-rose-500/10') : 'border-slate-200 bg-white hover:border-sky-500 dark:border-white/10 dark:bg-white/5'
                      } ${isRevealed && !isPicked ? 'opacity-80' : ''}`}>
                        <span className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                          isPicked ? (isCorrectAnswer ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white') : 'bg-slate-200 text-slate-700 dark:bg-white/10 dark:text-slate-300'
                        }`}>{L}</span>
                        <span className="flex-1 pt-1">{text}</span>
                        {isPicked && isRevealed && (
                          <Check className={`mt-1 h-5 w-5 ${isCorrectAnswer ? 'text-emerald-500' : 'text-rose-500'}`} />
                        )}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Explanation appears after answering */}
            {revealed[q.id] && (
              <ExplanationPanel
                question={q}
                activeCase={activeCase}
                userAnswer={answers[q.id]}
                lang={lang}
              />
            )}

            {/* Navigation */}
            <div className="mt-4 flex items-center justify-between gap-3">
              <button
                onClick={() => setQuestionIdx(Math.max(0, questionIdx - 1))}
                disabled={questionIdx === 0}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold disabled:opacity-50 dark:border-white/10"
              >
                <ChevronLeft className="h-4 w-4" /> {isAr ? 'السابق' : 'Previous'}
              </button>
              {questionIdx < total - 1 ? (
                <button
                  onClick={() => setQuestionIdx(Math.min(total - 1, questionIdx + 1))}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 px-5 py-2 text-sm font-bold text-white shadow-md disabled:opacity-50"
                >
                  {isAr ? 'التالي' : 'Next'} <ChevronRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  onClick={submitAll}
                  disabled={submitting || answered < total}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-2 text-sm font-bold text-white shadow-md disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trophy className="h-4 w-4" />}
                  {isAr ? 'إنهاء وتقديم' : 'Finish & Submit'}
                </button>
              )}
            </div>
            {answered < total && questionIdx === total - 1 && (
              <p className="mt-2 text-center text-xs text-amber-700 dark:text-amber-300">
                {isAr ? `أجبت على ${answered} من ${total}. أجب على الباقي قبل التقديم.` : `Answered ${answered}/${total}. Answer remaining questions before submitting.`}
              </p>
            )}
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}

function ExplanationPanel({ question, activeCase, userAnswer, lang }: any) {
  const isAr = lang === 'ar';
  // We need to look up the correct answer and explanation from /api/mcq-grade response.
  // The play view only has the question + options, not explanation data.
  // To avoid an extra round-trip per question, we show generic guidance and re-grade at submit.
  // The detailed explanation arrives in the final ResultView.
  return (
    <div className="mt-3 rounded-2xl border border-emerald-300/60 bg-emerald-50/70 p-3 text-sm dark:border-emerald-500/30 dark:bg-emerald-500/10">
      <div className="mb-1 inline-flex items-center gap-1.5 font-bold text-emerald-700 dark:text-emerald-300">
        <Check className="h-3.5 w-3.5" /> {isAr ? 'تم تسجيل إجابتك' : 'Answer recorded'}
      </div>
      <p className="text-xs text-slate-700 dark:text-slate-300">
        {isAr ? 'سيظهر الشرح الكامل عند إنهاء جميع الأسئلة وتقديمها.' : 'Detailed explanation and rationale will appear after you submit all answers.'}
      </p>
    </div>
  );
}

function ResultView(props: any) {
  const { result, activeCase, lang, setLang, onTryAgain, onRandom, onBackToLobby } = props;
  const isAr = lang === 'ar';
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />
      <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl border border-slate-200 bg-white/80 p-6 text-center shadow-2xl backdrop-blur dark:border-white/10 dark:bg-white/5">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-300">
            <Award className="h-3.5 w-3.5" /> {isAr ? 'النتيجة' : 'Result'}
          </div>
          <h1 className="text-2xl font-extrabold sm:text-3xl">{isAr ? result.case_title : result.case_title}</h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{isAr ? result.condition : result.condition}</p>
          <div className="mx-auto mt-6 inline-flex items-center gap-4 rounded-3xl bg-gradient-to-br from-sky-50 via-white to-emerald-50 p-6 shadow-lg dark:from-sky-500/10 dark:via-slate-900 dark:to-emerald-500/10">
            <div className="text-center">
              <div className="text-5xl font-extrabold text-sky-600 dark:text-sky-300">{result.percentage}%</div>
              <div className="mt-1 text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'النتيجة' : 'Score'}</div>
            </div>
            <div className="h-12 w-px bg-slate-200 dark:bg-white/10" />
            <div className="text-center">
              <div className="text-2xl font-bold text-slate-700 dark:text-slate-200">{result.score}/{result.total}</div>
              <div className="mt-1 text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'إجابات صحيحة' : 'Correct'}</div>
            </div>
            <div className="h-12 w-px bg-slate-200 dark:bg-white/10" />
            <div className="text-center">
              <div className={`text-2xl font-bold ${result.percentage >= 75 ? 'text-emerald-600 dark:text-emerald-300' : result.percentage >= 60 ? 'text-amber-600 dark:text-amber-300' : 'text-rose-600 dark:text-rose-300'}`}>
                {isAr ? result.level.ar : result.level.en}
              </div>
              <div className="mt-1 text-xs font-bold text-slate-500 dark:text-slate-400">{isAr ? 'المستوى' : 'Level'}</div>
            </div>
          </div>

          {/* Strengths / Weaknesses */}
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-emerald-300 bg-emerald-50/70 p-3 text-start dark:border-emerald-500/30 dark:bg-emerald-500/10">
              <div className="mb-1 inline-flex items-center gap-1.5 font-bold text-emerald-700 dark:text-emerald-300">
                <ShieldCheck className="h-3.5 w-3.5" /> {isAr ? 'نقاط القوة' : 'Strong Areas'}
              </div>
              <ul className="space-y-0.5 text-xs">
                {Object.keys(result.strong_topics || {}).length > 0 ? Object.entries(result.strong_topics).map(([k]: any) => (
                  <li key={k}>{isAr ? 'لا توجد أخطاء في' : 'No mistakes in'} <strong>{k}</strong></li>
                )) : <li>{isAr ? 'لا توجد بيانات' : 'N/A'}</li>}
              </ul>
            </div>
            <div className="rounded-2xl border border-amber-300 bg-amber-50/70 p-3 text-start dark:border-amber-500/30 dark:bg-amber-500/10">
              <div className="mb-1 inline-flex items-center gap-1.5 font-bold text-amber-700 dark:text-amber-300">
                <Lightbulb className="h-3.5 w-3.5" /> {isAr ? 'مجالات التحسين' : 'Areas to improve'}
              </div>
              <ul className="space-y-0.5 text-xs">
                {Object.entries(result.weak_topics || {}).length > 0 ? Object.entries(result.weak_topics).map(([k, v]: any) => (
                  <li key={k}><strong>{k}</strong>: {v} {isAr ? 'أخطاء' : 'mistakes'}</li>
                )) : <li>{isAr ? 'لا توجد مجالات للتحسين' : 'None — great job!'}</li>}
              </ul>
            </div>
          </div>

          {/* Mistakes review */}
          {result.mistakes && result.mistakes.length > 0 && (
            <div className="mt-6">
              <div className="mb-3 inline-flex items-center gap-1.5 font-bold text-rose-700 dark:text-rose-300">
                <AlertTriangle className="h-3.5 w-3.5" /> {isAr ? 'مراجعة الأخطاء' : 'Mistake Review'}
              </div>
              <div className="space-y-3 text-start">
                {result.mistakes.map((m: any, i: number) => (
                  <details key={i} className="rounded-2xl border border-slate-200 bg-white/60 p-3 dark:border-white/10 dark:bg-white/5">
                    <summary className="cursor-pointer text-sm font-bold">
                      <span className="me-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-xs text-white">{m.position}</span>
                      {m.stem}
                    </summary>
                    <div className="mt-2 space-y-2 text-xs">
                      <div className="rounded-lg bg-rose-50 p-2 dark:bg-rose-500/10">
                        <strong className="text-rose-700 dark:text-rose-300">{isAr ? 'إجابتك' : 'Your answer'}: </strong> {m.user_answer || '—'} — {m.options[m.user_answer] || '—'}
                      </div>
                      <div className="rounded-lg bg-emerald-50 p-2 dark:bg-emerald-500/10">
                        <strong className="text-emerald-700 dark:text-emerald-300">{isAr ? 'الإجابة الصحيحة' : 'Correct'}: </strong> {m.correct_answer} — {m.options[m.correct_answer]}
                      </div>
                      <div className="rounded-lg bg-sky-50 p-2 dark:bg-sky-500/10">
                        <strong className="text-sky-700 dark:text-sky-300">{isAr ? 'الشرح' : 'Explanation'}: </strong> {m.explanation}
                      </div>
                      {m.reference?.url && (
                        <a href={m.reference.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 hover:underline dark:text-emerald-300">
                          <ExternalLink className="h-3 w-3" /> {m.reference.label || 'Source'}
                        </a>
                      )}
                    </div>
                  </details>
                ))}
              </div>
            </div>
          )}

          {/* Learning Points */}
          {result.learning_points && result.learning_points.length > 0 && (
            <div className="mt-6 rounded-2xl border border-sky-300 bg-sky-50/70 p-4 text-start dark:border-sky-500/30 dark:bg-sky-500/10">
              <div className="mb-2 inline-flex items-center gap-1.5 font-bold text-sky-700 dark:text-sky-300">
                <Lightbulb className="h-3.5 w-3.5" /> {isAr ? 'نقاط التعلم الرئيسية' : 'Key Learning Points'}
              </div>
              <ul className="ms-4 list-disc space-y-1 text-xs text-slate-700 dark:text-slate-200">
                {result.learning_points.map((lp: string, i: number) => <li key={i}>{lp}</li>)}
              </ul>
            </div>
          )}

          {/* References */}
          {result.references && result.references.length > 0 && (
            <div className="mt-3 rounded-2xl border border-slate-200 bg-white/70 p-3 text-start text-xs dark:border-white/10 dark:bg-white/5">
              <div className="mb-1 inline-flex items-center gap-1.5 font-bold">
                <BookOpen className="h-3.5 w-3.5" /> {isAr ? 'المراجع العلمية' : 'Scientific References'}
              </div>
              <ul className="space-y-0.5">
                {result.references.map((r: any, i: number) => (
                  <li key={i} className="flex items-start gap-1">
                    <ExternalLink className="mt-0.5 h-3 w-3 shrink-0 text-sky-500" />
                    <a href={r.url} target="_blank" rel="noreferrer" className="hover:underline"><strong>{r.abbr}</strong> — {r.title}</a>
                  </li>
                ))}
              </ul>
              {result.guideline_version && (
                <div className="mt-1 text-[10px] text-slate-500">{isAr ? 'الإصدار' : 'Guideline'}: {result.guideline_version}</div>
              )}
            </div>
          )}

          <div className="mt-3 rounded-xl border border-amber-300/40 bg-amber-50/70 p-2 text-[10px] text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
            <AlertTriangle className="me-1 inline h-3 w-3" /> {result.disclaimer}
          </div>

          {/* Actions */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button onClick={onTryAgain} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 px-5 py-2 text-sm font-bold text-white shadow">
              <RotateCcw className="h-4 w-4" /> {isAr ? 'حاول مرة أخرى' : 'Try Again'}
            </button>
            <button onClick={onRandom} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-2 text-sm font-bold text-white shadow">
              <Sparkles className="h-4 w-4" /> {isAr ? 'حالة عشوائية' : 'Random Case'}
            </button>
            <button onClick={onBackToLobby} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2 text-sm font-bold hover:border-sky-500 dark:border-white/10">
              <ArrowLeft className="h-4 w-4" /> {isAr ? 'العودة للمكتبة' : 'Back to Library'}
            </button>
            <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2 text-sm font-bold hover:border-sky-500 dark:border-white/10">
              <Globe className="h-4 w-4" /> {isAr ? 'English' : 'العربية'}
            </button>
          </div>
        </motion.div>
      </div>
      <Footer />
    </div>
  );
}
