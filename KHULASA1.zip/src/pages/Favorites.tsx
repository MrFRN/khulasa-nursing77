import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { HeartOff } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import Breadcrumb from '../components/Breadcrumb';
import SectionHeader from '../components/SectionHeader';
import ResourceCard from '../components/ResourceCard';
import { SkeletonGrid } from '../components/CardSkeleton';
import { fetchResources } from '../lib/api';
import { getFavorites } from '../lib/favorites';
import type { Resource } from '../types';

export default function Favorites() {
  const [all, setAll] = useState<Resource[]>([]);
  const [ids, setIds] = useState<number[]>(getFavorites());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchResources().then(setAll).catch(() => {}).finally(() => setLoading(false));
    const h = () => setIds(getFavorites());
    window.addEventListener('favorites-changed', h);
    return () => window.removeEventListener('favorites-changed', h);
  }, []);

  const items = all.filter((r) => ids.includes(r.id));

  return (
    <PublicLayout>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Breadcrumb items={[{ label: 'المفضلة' }]} />
        <div className="mt-6">
          <SectionHeader title="ملفاتي المفضلة" subtitle="الملفات التي قمت بحفظها للرجوع إليها لاحقًا" icon="Heart" gradient="from-accent to-orange-500" />
        </div>
        {loading ? <SkeletonGrid count={4} /> : items.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 py-20 text-center text-slate-500 dark:border-white/10">
            <HeartOff className="h-12 w-12 text-slate-300" />
            <p className="font-semibold text-slate-700 dark:text-slate-200">لا توجد ملفات مفضلة بعد</p>
            <Link to="/" className="text-sm text-primary underline">تصفّح المكتبة</Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
            {items.map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
