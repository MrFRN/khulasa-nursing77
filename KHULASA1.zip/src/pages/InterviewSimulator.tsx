// AI Nursing Interview Simulator - full voice/text interview with
// practice and real-interview modes, scoring, and final report.
import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, AlertCircle, Award, Brain, Briefcase, Check, ChevronLeft,
  ChevronRight, ClipboardList, Clock, ExternalLink, Heart, Lightbulb,
  Loader2, Mic, MicOff, Pause, Play, RotateCcw, Send, ShieldCheck,
  Sparkles, Star, Target, Trophy, User, Volume2, X,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useToast } from '../components/Toast';

type Lang = 'en' | 'ar';

const SPECIALTIES = [
  { key: 'general', en: 'General Nursing', ar: 'التمريض العام', icon: Heart },
  { key: 'icu', en: 'ICU / Critical Care', ar: 'العناية المركزة', icon: Activity },
  { key: 'er', en: 'Emergency Room', ar: 'الطوارئ', icon: Activity },
  { key: 'ccu', en: 'CCU / Cardiac', ar: 'العناية القلبية', icon: Heart },
  { key: 'cath', en: 'Cardiac Catheterization', ar: 'قسطرة القلب', icon: Heart },
  { key: 'dialysis', en: 'Dialysis', ar: 'غسيل الكلى', icon: Activity },
  { key: 'nicu', en: 'NICU', ar: 'حديثي الولادة', icon: Heart },
  { key: 'picu', en: 'PICU', ar: 'أطفال الحالات الحرجة', icon: Heart },
  { key: 'medsurg', en: 'Medical-Surgical', ar: 'الباطنية والجراحة', icon: ClipboardList },
  { key: 'surgical', en: 'Surgical Ward', ar: 'الجناح الجراحي', icon: ClipboardList },
  { key: 'or', en: 'Operating Room', ar: 'غرفة العمليات', icon: ClipboardList },
  { key: 'ob', en: 'Obstetrics', ar: 'النسائية والتوليد', icon: Heart },
  { key: 'gyn', en: 'Gynecology', ar: 'أمراض النساء', icon: Heart },
  { key: 'psych', en: 'Psychiatric', ar: 'الطب النفسي', icon: Brain },
  { key: 'geri', en: 'Geriatric', ar: 'كبار السن', icon: User },
  { key: 'onc', en: 'Oncology', ar: 'الأورام', icon: Activity },
];

const EXPERIENCE = [
  { key: 'fresh', en: 'Fresh Graduate', ar: 'حديث التخرج' },
  { key: 'intern', en: 'Internship', ar: 'امتياز' },
  { key: '1-2', en: '1-2 Years', ar: '1-2 سنوات' },
  { key: 'exp', en: 'Experienced', ar: 'خبير' },
  { key: 'senior', en: 'Senior / Charge', ar: 'أول / مسؤول وردية' },
];

const TYPES = [
  { key: 'hr', en: 'HR / Behavioral', ar: 'HR / سلوكي' },
  { key: 'clinical', en: 'Clinical', ar: 'سريري' },
  { key: 'mixed', en: 'Mixed', ar: 'مختلط' },
];

const DIFFICULTY = [
  { key: 'easy', en: 'Easy', ar: 'سهل' },
  { key: 'normal', en: 'Normal', ar: 'متوسط' },
  { key: 'advanced', en: 'Advanced', ar: 'متقدم' },
  { key: 'high', en: 'High Pressure', ar: 'ضغط عالي' },
];

const MODES = [
  { key: 'practice', en: 'Practice Mode', ar: 'وضع التدريب', desc_en: 'Get feedback + model answer after each question.', desc_ar: 'احصل على تغذية راجعة وإجابة نموذجية بعد كل سؤال.' },
  { key: 'real', en: 'Real Interview', ar: 'مقابلة حقيقية', desc_en: 'No feedback until the end. Natural flow.', desc_ar: 'لا توجد تغذية راجعة حتى النهاية. تدفق طبيعي.' },
];

function pickLang(s, isAr) { return isAr ? s.ar : s.en; }

function useSpeech(lang) {
  const recRef = useRef(null);
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interim, setInterim] = useState('');

  useEffect(() => {
    const SR = typeof window !== 'undefined' ? (window.SpeechRecognition || window.webkitSpeechRecognition) : null;
    if (!SR) { setSupported(false); return; }
    setSupported(true);
    const r = new SR();
    r.continuous = false;
    r.interimResults = true;
    r.lang = lang === 'ar' ? 'ar-SA' : 'en-US';
    r.onresult = (e) => {
      let inter = '';
      let txt = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) txt += t; else inter += t;
      }
      setInterim(inter);
      if (txt) setTranscript(prev => (prev + ' ' + txt).trim());
    };
    r.onend = () => { setListening(false); setInterim(''); };
    r.onerror = () => { setListening(false); setInterim(''); };
    recRef.current = r;
    return () => { try { r.stop(); } catch {} };
  }, [lang]);

  function start() { if (!recRef.current) return; setTranscript(''); setInterim(''); setListening(true); try { recRef.current.start(); } catch {} }
  function stop() { if (!recRef.current) return; setListening(false); try { recRef.current.stop(); } catch {} }
  return { supported, listening, transcript, interim, setTranscript, start, stop };
}

function speak(text, lang) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang === 'ar' ? 'ar-SA' : 'en-US';
    u.rate = 1;
    window.speechSynthesis.speak(u);
  } catch {}
}

export default function InterviewSimulator() {
  const [lang, setLang] = useState<Lang>('en');
  const isAr = lang === 'ar';
  const { toast } = useToast();

  // Setup
  const [setup, setSetup] = useState({
    specialty: 'icu', experience: '1-2', type: 'mixed', difficulty: 'normal', mode: 'practice',
  });
  const [stage, setStage] = useState('setup'); // 'setup' | 'interview' | 'result'
  const [session, setSession] = useState<any>(null);
  const [currentQ, setCurrentQ] = useState<any>(null);
  const [finalResult, setFinalResult] = useState<any>(null);
  const [textAnswer, setTextAnswer] = useState('');
  const [interim, setInterim] = useState('');
  const [showModel, setShowModel] = useState(false);
  const [busy, setBusy] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Voice
  const { supported: voiceSupported, listening, transcript, interim: interimVoice, setTranscript, start: startVoice, stop: stopVoice } = useSpeech(lang);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Combine voice transcript + text
  useEffect(() => {
    if (transcript) setTextAnswer(prev => (prev + ' ' + transcript).trim());
  }, [transcript]);

  // Timer
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (stage !== 'interview') return;
    const id = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(id);
  }, [stage]);

  // Auto-speak question
  useEffect(() => {
    if (currentQ && stage === 'interview') {
      speak(currentQ.text, lang);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentQ?.id]);

  async function startInterview() {
    setBusy(true);
    try {
      const res = await fetch('/api/interview-v2', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'start', lang, ...setup }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setSession(data.session);
      setCurrentQ(data.question);
      setStage('interview');
      setTextAnswer('');
      setElapsed(0);
    } catch (e: any) { toast(e.message || 'Failed to start', 'error'); }
    setBusy(false);
  }

  async function submitAnswer() {
    if (!textAnswer.trim() || busy) return;
    if (listening) stopVoice();
    setBusy(true);
    setShowModel(false);
    try {
      const res = await fetch('/api/interview-v2', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'answer', lang, questionId: currentQ.id, answer: textAnswer, session }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setSession(data.session);
      // Practice mode: show feedback + model
      if (setup.mode === 'practice' && data.practiceFeedback) {
        setShowModel(true);
        setPendingNext(data.next);
        setPendingFinished(!!data.finished);
        setShowNextPrompt(false);
      } else if (data.finished) {
        await finishInterview();
      } else {
        setCurrentQ(data.next);
        setTextAnswer('');
      }
    } catch (e: any) { toast(e.message || 'Failed', 'error'); }
    setBusy(false);
  }

  // After showing practice feedback, user clicks Next to advance
  const [pendingNext, setPendingNext] = useState<any>(null);
  const [pendingFinished, setPendingFinished] = useState(false);
  function continueAfterFeedback() {
    setShowModel(false);
    if (pendingFinished) {
      finishInterview();
    } else if (pendingNext) {
      setCurrentQ(pendingNext);
      setTextAnswer('');
    }
  }

  async function finishInterview() {
    setBusy(true);
    try {
      const res = await fetch('/api/interview-v2', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'finish', lang, session }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setFinalResult(data.result);
      setStage('result');
    } catch (e: any) { toast(e.message || 'Failed', 'error'); }
    setBusy(false);
  }

  function retryAnswer() {
    setTextAnswer('');
    setShowModel(false);
  }

  function newInterview() {
    setStage('setup'); setSession(null); setCurrentQ(null); setFinalResult(null);
    setTextAnswer(''); setElapsed(0);
  }

  // ---------------- UI ----------------
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white">
      <Navbar />

      {/* Top bar */}
      <div className="border-b border-slate-200 bg-white/80 backdrop-blur dark:border-white/10 dark:bg-slate-900/80">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2">
            <Briefcase className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-extrabold">{isAr ? 'محاكي المقابلات بالذكاء الاصطناعي' : 'AI Nursing Interview Simulator'}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-3 py-1.5 text-sm font-bold hover:border-primary dark:border-white/10">
              {isAr ? 'English' : 'العربية'}
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
        <AnimatePresence mode="wait">
          {stage === 'setup' && (
            <SetupScreen key="setup" lang={lang} setup={setup} setSetup={setSetup} onStart={startInterview} busy={busy} />
          )}
          {stage === 'interview' && (
            <InterviewScreen
              key="interview"
              lang={lang}
              setup={setup}
              session={session}
              currentQ={currentQ}
              textAnswer={textAnswer}
              setTextAnswer={setTextAnswer}
              elapsed={elapsed}
              voiceSupported={voiceSupported}
              voiceListening={listening}
              voiceTranscript={transcript}
              voiceInterim={interimVoice}
              onStartVoice={startVoice}
              onStopVoice={stopVoice}
              onSubmit={submitAnswer}
              onRetry={retryAnswer}
              onAbandon={newInterview}
              onToggleSettings={() => setShowSettings(s => !s)}
              showSettings={showSettings}
              busy={busy}
              showModel={showModel}
              onContinue={continueAfterFeedback}
              lastAnswer={session?.answers?.[session.answers.length - 1]}
            />
          )}
          {stage === 'result' && (
            <ResultScreen key="result" lang={lang} result={finalResult} onNew={newInterview} />
          )}
        </AnimatePresence>
      </div>

      <Footer />
    </div>
  );
}

function SetupScreen({ lang, setup, setSetup, onStart, busy }: any) {
  const isAr = lang === 'ar';
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="rounded-3xl border border-slate-200 bg-gradient-to-br from-sky-50 via-white to-emerald-50 p-6 dark:border-white/10 dark:from-sky-900/30 dark:via-slate-900 dark:to-emerald-900/20">
        <h2 className="text-2xl font-extrabold">{isAr ? 'ابدأ مقابلتك' : 'Start Your Interview'}</h2>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          {isAr
            ? 'اختر التخصص والمستوى ونوع المقابلة. سيتحدث معك المحاور بالذكاء الاصطناعي ويسألك أسئلة متصلة. أجب بصوتك أو اكتب إجابتك.'
            : 'Choose your specialty, experience level, and interview type. The AI interviewer will speak to you and ask connected questions. Answer by voice or by typing.'}
        </p>
      </div>

      {/* Specialty grid */}
      <div>
        <Label isAr={isAr} en="Specialty" ar="التخصص" />
        <div className="mt-2 grid gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {SPECIALTIES.map((s) => {
            const Icon = s.icon;
            const active = setup.specialty === s.key;
            return (
              <button key={s.key} onClick={() => setSetup({ ...setup, specialty: s.key })}
                className={`flex items-center gap-2 rounded-2xl border px-3 py-3 text-start text-sm transition ${active ? 'border-primary bg-primary/10 text-primary' : 'border-slate-200 hover:border-primary/50 dark:border-white/10'}`}>
                <Icon className="h-4 w-4 shrink-0" />
                <span className="font-semibold">{pickLang(s, isAr)}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Experience */}
      <div>
        <Label isAr={isAr} en="Experience" ar="الخبرة" />
        <div className="mt-2 grid gap-2 sm:grid-cols-3 lg:grid-cols-5">
          {EXPERIENCE.map((e) => {
            const active = setup.experience === e.key;
            return (
              <button key={e.key} onClick={() => setSetup({ ...setup, experience: e.key })}
                className={`rounded-2xl border px-3 py-2 text-sm font-semibold transition ${active ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-slate-200 hover:border-emerald-500/40 dark:border-white/10'}`}>
                {pickLang(e, isAr)}
              </button>
            );
          })}
        </div>
      </div>

      {/* Type + Difficulty + Mode */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <Label isAr={isAr} en="Interview Type" ar="نوع المقابلة" />
          <div className="mt-2 grid gap-1.5">
            {TYPES.map((t) => {
              const active = setup.type === t.key;
              return (
                <button key={t.key} onClick={() => setSetup({ ...setup, type: t.key })}
                  className={`rounded-xl border px-3 py-2 text-sm font-semibold transition ${active ? 'border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300' : 'border-slate-200 hover:border-amber-500/40 dark:border-white/10'}`}>
                  {pickLang(t, isAr)}
                </button>
              );
            })}
          </div>
        </div>
        <div>
          <Label isAr={isAr} en="Difficulty" ar="الصعوبة" />
          <div className="mt-2 grid gap-1.5">
            {DIFFICULTY.map((d) => {
              const active = setup.difficulty === d.key;
              return (
                <button key={d.key} onClick={() => setSetup({ ...setup, difficulty: d.key })}
                  className={`rounded-xl border px-3 py-2 text-sm font-semibold transition ${active ? 'border-violet-500 bg-violet-500/10 text-violet-700 dark:text-violet-300' : 'border-slate-200 hover:border-violet-500/40 dark:border-white/10'}`}>
                  {pickLang(d, isAr)}
                </button>
              );
            })}
          </div>
        </div>
        <div>
          <Label isAr={isAr} en="Mode" ar="الوضع" />
          <div className="mt-2 grid gap-1.5">
            {MODES.map((m) => {
              const active = setup.mode === m.key;
              return (
                <button key={m.key} onClick={() => setSetup({ ...setup, mode: m.key })}
                  className={`rounded-xl border px-3 py-2 text-start text-sm transition ${active ? 'border-sky-500 bg-sky-500/10' : 'border-slate-200 hover:border-sky-500/40 dark:border-white/10'}`}>
                  <div className="font-bold">{pickLang(m, isAr)}</div>
                  <div className="text-[10px] text-slate-500">{pickLang(m, isAr) === m.en ? m.desc_en : m.desc_ar}</div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-amber-300/40 bg-amber-50/70 p-3 text-xs text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
        <AlertCircle className="me-1 inline h-3 w-3" /> {isAr
          ? 'للأغراض التعليمية فقط. لا يحل محل الحكم السريري أو التقييم الرسمي.'
          : 'Educational only. Does not replace professional judgment or official evaluation.'}
        {!voiceSupported && <div className="mt-1 italic">({isAr ? 'الصوت غير متاح في هذا المتصفح، يمكنك الكتابة' : 'Voice not available in this browser, you can type'})</div>}
      </div>

      <button onClick={onStart} disabled={busy}
        className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 px-6 py-4 text-base font-extrabold text-white shadow-lg shadow-sky-500/30 transition hover:opacity-90 disabled:opacity-50">
        {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sparkles className="h-5 w-5" />}
        {isAr ? 'ابدأ المقابلة' : 'Start Interview'}
      </button>
    </motion.div>
  );
}

function Label({ isAr, en, ar }: any) {
  return <div className="text-sm font-bold text-slate-700 dark:text-slate-300">{isAr ? ar : en}</div>;
}

function InterviewScreen(props: any) {
  const { lang, setup, session, currentQ, textAnswer, setTextAnswer, elapsed, voiceSupported, voiceListening, voiceTranscript, voiceInterim, onStartVoice, onStopVoice, onSubmit, onRetry, onAbandon, onToggleSettings, showSettings, busy, showModel, onContinue, lastAnswer } = props;
  const isAr = lang === 'ar';
  const fmt = (s) => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
  const progress = session?.asked?.length || 0;
  const total = setup.mode === 'practice' ? 6 : 8;
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      {/* Top bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm dark:border-white/10 dark:bg-white/5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 to-emerald-500 text-white">
            <User className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wide text-slate-500">{isAr ? 'المقابلة' : 'Interview'}</div>
            <div className="text-sm font-extrabold">{isAr ? 'المحاور: الذكاء الاصطناعي' : 'AI Interviewer'}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold dark:bg-white/10">
            <Clock className="me-1 inline h-3 w-3" /> {fmt(elapsed)}
          </div>
          <div className="rounded-full bg-sky-100 px-3 py-1 text-xs font-bold text-sky-700 dark:bg-sky-500/15 dark:text-sky-300">
            {isAr ? 'السؤال' : 'Q'} {progress} / {total}
          </div>
          <button onClick={onAbandon} className="rounded-full border border-rose-200 bg-rose-50 px-3 py-1 text-xs font-bold text-rose-700 hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300">
            {isAr ? 'إنهاء' : 'End'}
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/5">
        <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-emerald-500 transition-all" style={{ width: `${(progress/total)*100}%` }} />
      </div>

      {/* AI Question card */}
      <div className="rounded-3xl border border-sky-200 bg-gradient-to-br from-sky-50 via-white to-white p-5 shadow-md dark:border-sky-500/30 dark:from-sky-900/20 dark:via-slate-900 dark:to-slate-900">
        <div className="mb-2 flex items-center justify-between">
          <div className="inline-flex items-center gap-2 rounded-full bg-sky-100 px-3 py-1 text-xs font-bold text-sky-700 dark:bg-sky-500/15 dark:text-sky-300">
            <Brain className="h-3 w-3" /> {isAr ? 'المحاور يسأل' : 'Interviewer asks'}
          </div>
          {currentQ?.category && (
            <div className="text-xs text-slate-500">{currentQ.category}</div>
          )}
        </div>
        <div className="text-lg font-bold leading-relaxed text-slate-900 dark:text-white">
          {currentQ?.text}
        </div>
        <div className="mt-3 flex items-center gap-2">
          <button onClick={() => speak(currentQ?.text, lang)} className="inline-flex items-center gap-1 rounded-lg border border-sky-300 bg-white/80 px-2 py-1 text-xs font-bold hover:bg-sky-50 dark:border-sky-500/30 dark:bg-white/5">
            <Volume2 className="h-3 w-3" /> {isAr ? 'إعادة تشغيل الصوت' : 'Replay audio'}
          </button>
        </div>
      </div>

      {/* Answer area */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-md dark:border-white/10 dark:bg-white/5">
        <div className="mb-2 text-sm font-bold">{isAr ? 'إجابتك' : 'Your answer'}</div>
        <textarea
          value={textAnswer}
          onChange={(e) => setTextAnswer(e.target.value)}
          placeholder={isAr ? 'اكتب إجابتك هنا، أو اضغط على زر الميكروفون للتحدث...' : 'Type your answer here, or tap the microphone to speak...'}
          rows={5}
          className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-white/10 dark:bg-slate-800/40"
          disabled={showModel}
        />
        <div className="mt-2 min-h-[1.25rem] text-xs text-slate-500">
          {voiceListening && <span className="text-rose-500">● {isAr ? 'يستمع...' : 'Listening...'}</span>}
          {voiceInterim && <span className="ms-2 italic">{voiceInterim}</span>}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          {voiceSupported && (
            <button onClick={voiceListening ? onStopVoice : onStartVoice} disabled={showModel || busy}
              className={`inline-flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold transition ${voiceListening ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30 animate-pulse' : 'border border-slate-300 bg-white hover:border-rose-500 hover:text-rose-500 dark:border-white/10 dark:bg-white/5'}`}>
              {voiceListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              {voiceListening ? (isAr ? 'إيقاف' : 'Stop') : (isAr ? 'تسجيل صوتي' : 'Voice')}
            </button>
          )}
          <button onClick={onRetry} disabled={busy || showModel || !textAnswer.trim()}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 px-4 py-3 text-sm font-bold hover:border-amber-500 dark:border-white/10">
            <RotateCcw className="h-4 w-4" /> {isAr ? 'إعادة' : 'Retry'}
          </button>
          <button onClick={onSubmit} disabled={busy || !textAnswer.trim() || showModel}
            className="ml-auto inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 px-5 py-3 text-sm font-extrabold text-white shadow-lg disabled:opacity-50">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            {isAr ? 'إرسال' : 'Submit'}
          </button>
        </div>
      </div>

      {/* Practice mode feedback */}
      <AnimatePresence>
        {showModel && lastAnswer && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-white p-5 dark:border-emerald-500/30 dark:from-emerald-900/20 dark:to-slate-900">
            <div className="mb-3 flex items-center justify-between">
              <div className="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                <Check className="h-3 w-3" /> {isAr ? 'نتيجة هذا السؤال' : 'Question result'}
              </div>
              <div className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-300">{lastAnswer.evaluation.score}<span className="text-sm">/100</span></div>
            </div>

            {lastAnswer.evaluation.model && (
              <div className="mb-3 rounded-2xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-white/5">
                <div className="mb-1 text-xs font-bold text-slate-500 uppercase">{isAr ? 'إجابة نموذجية' : 'Model answer'}</div>
                <div className="text-sm leading-relaxed">{lastAnswer.evaluation.model}</div>
              </div>
            )}

            {(lastAnswer.evaluation.strengths || []).length > 0 && (
              <div className="mb-2">
                <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300">🟢 {isAr ? 'نقاط القوة' : 'Strengths'}</div>
                <ul className="ms-5 mt-1 list-disc text-sm">
                  {lastAnswer.evaluation.strengths.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>
            )}
            {(lastAnswer.evaluation.improvements || []).length > 0 && (
              <div className="mb-3">
                <div className="text-xs font-bold text-amber-700 dark:text-amber-300">🟡 {isAr ? 'لتحسين' : 'To improve'}</div>
                <ul className="ms-5 mt-1 list-disc text-sm">
                  {lastAnswer.evaluation.improvements.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>
            )}

            <button onClick={onContinue} className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 px-5 py-3 text-sm font-extrabold text-white">
              {progress >= total ? (isAr ? 'إنهاء المقابلة' : 'End Interview') : (isAr ? 'السؤال التالي' : 'Next Question')}
              <ChevronRight className="h-4 w-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function ResultScreen({ lang, result, onNew }: any) {
  const isAr = lang === 'ar';
  if (!result) return null;
  const overall = result.overall || 0;
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <div className="rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-md dark:border-white/10 dark:bg-white/5">
        <div className="text-xs font-bold uppercase text-slate-500">{isAr ? 'النتيجة النهائية' : 'Final Result'}</div>
        <div className="mt-2 text-5xl font-extrabold bg-gradient-to-r from-sky-500 to-emerald-500 bg-clip-text text-transparent">{overall}<span className="text-2xl text-slate-400">/100</span></div>
        <div className="mt-1 text-sm font-bold">{isAr ? (result.grade_ar || result.grade_en) : result.grade_en}</div>
        <div className="mt-2 text-xs text-slate-500">{result.questionsAnswered}/{result.questionsAsked} {isAr ? 'أسئلة' : 'questions'}</div>
      </div>

      {/* Criteria */}
      <div>
        <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-600 dark:text-slate-300">{isAr ? 'المعايير' : 'Criteria'}</h3>
        <div className="grid gap-2 sm:grid-cols-2">
          {(result.evaluation || []).map((c: any) => (
            <div key={c.key} className="rounded-2xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-white/5">
              <div className="flex items-center justify-between text-sm">
                <span className="font-bold">{isAr ? c.label_ar : c.label_en}</span>
                <span className="font-extrabold text-primary">{c.score}/100</span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/5">
                <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-emerald-500" style={{ width: `${c.score}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Strengths / Improvements */}
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 dark:border-emerald-500/30 dark:bg-emerald-500/10">
          <div className="text-sm font-bold text-emerald-700 dark:text-emerald-300">🟢 {isAr ? 'نقاط القوة' : 'Strengths'}</div>
          <ul className="ms-5 mt-2 list-disc text-sm">
            {(result.strengths || []).length ? result.strengths.map((s, i) => <li key={i}>{s}</li>) : <li className="list-none italic text-slate-500">{isAr ? 'لا توجد' : 'None yet'}</li>}
          </ul>
        </div>
        <div className="rounded-2xl border border-rose-200 bg-rose-50/60 p-4 dark:border-rose-500/30 dark:bg-rose-500/10">
          <div className="text-sm font-bold text-rose-700 dark:text-rose-300">🔴 {isAr ? 'نقاط الضعف' : 'Weaknesses'}</div>
          <ul className="ms-5 mt-2 list-disc text-sm">
            {(result.improvements || []).length ? result.improvements.map((s, i) => <li key={i}>{s}</li>) : <li className="list-none italic text-slate-500">{isAr ? 'لا توجد' : 'None'}</li>}
          </ul>
        </div>
      </div>

      {/* Review questions */}
      <div>
        <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-600 dark:text-slate-300">{isAr ? 'مراجعة الأسئلة' : 'Question Review'}</h3>
        <div className="space-y-2">
          {(result.answers || []).map((a: any, i: number) => (
            <div key={i} className="rounded-2xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-white/5">
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="font-bold text-slate-500">Q{i+1} · {a.category}</span>
                <span className={`font-extrabold ${a.evaluation.score >= 70 ? 'text-emerald-600' : a.evaluation.score >= 50 ? 'text-amber-600' : 'text-rose-600'}`}>{a.evaluation.score}/100</span>
              </div>
              <div className="text-sm font-semibold">{a.question}</div>
              <div className="mt-1 text-xs text-slate-600 dark:text-slate-400 line-clamp-2">{a.answer}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Linked Interview Questions library */}
      <div className="rounded-2xl border border-sky-200 bg-sky-50/60 p-4 dark:border-sky-500/30 dark:bg-sky-500/10">
        <div className="text-sm font-bold text-sky-700 dark:text-sky-300">📚 {isAr ? 'راجع أسئلة المقابلات' : 'Review Interview Questions library'}</div>
        <a href="/interview" className="mt-2 inline-flex items-center gap-2 rounded-xl border border-sky-300 bg-white px-3 py-2 text-sm font-bold hover:bg-sky-50 dark:border-sky-500/30 dark:bg-white/5">
          <ExternalLink className="h-3 w-3" /> {isAr ? 'افتح مكتبة أسئلة المقابلات' : 'Open Interview Questions library'}
        </a>
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={onNew} className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 px-5 py-3 text-sm font-extrabold text-white">
          <Sparkles className="h-4 w-4" /> {isAr ? 'مقابلة جديدة' : 'New Interview'}
        </button>
        <a href="/interview" className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-slate-300 px-5 py-3 text-sm font-bold hover:border-primary dark:border-white/10">
          <BookOpen className="h-4 w-4" /> {isAr ? 'الأسئلة' : 'Question Bank'}
        </a>
      </div>

      <p className="text-center text-xs text-slate-500">{result.disclaimer}</p>
    </motion.div>
  );
}
