import type { Section, SiteSettings } from '../types';

export interface SectionMeta {
  key: Section;
  label: string;
  path: string;
  icon: string;
  desc: string;
  color: string; // tailwind gradient classes
}

export const SECTIONS: Record<Section, SectionMeta> = {
  study: {
    key: 'study',
    label: 'ملفات دراسية',
    path: '/study',
    icon: 'GraduationCap',
    desc: 'ملخّصات ومحاضرات لجميع الفرق الدراسية',
    color: 'from-primary to-primary-600',
  },
  books: {
    key: 'books',
    label: 'كتب عن التمريض',
    path: '/books',
    icon: 'BookOpen',
    desc: 'مراجع وكتب تمريضية وطبية متخصّصة',
    color: 'from-secondary to-secondary-600',
  },
  interview: {
    key: 'interview',
    label: 'أسئلة الانترفيو',
    path: '/interview',
    icon: 'MessagesSquare',
    desc: 'الاستعداد لمقابلات الامتياز وسوق العمل',
    color: 'from-accent to-orange-500',
  },
};

export const SECTION_LIST = Object.values(SECTIONS);

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'الخلاصة في التمريض',
  tagline: 'مكتبة التمريض الرقمية',
  heroTitle: 'كل ما يحتاجه طالب التمريض في مكان واحد',
  heroSubtitle: 'ملفات دراسية، وكتب متخصصة، وأسئلة انترفيو للامتياز وسوق العمل — تصفّح وحمّل مجانًا.',
  heroCta: 'ابدأ التصفّح',
  aboutText: 'منصة تعليمية مجانية تجمع أفضل المصادر لطلاب وخريجي التمريض.',
  logoUrl: '',
  bannerUrl: '',
  telegram: 'https://t.me/',
  facebook: 'https://facebook.com/',
  email: 'info@example.com',
  footerText: 'الخلاصة في التمريض — مكتبة تعليمية مجانية لدعم مجتمع التمريض.',
};

export function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9؀-ۿ]+/g, '-').replace(/^-+|-+$/g, '');
}
