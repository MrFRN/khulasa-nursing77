import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { ReactNode } from 'react';
import type { SiteSettings } from '../types';
import { DEFAULT_SETTINGS } from '../lib/constants';
import { fetchSettings } from '../lib/api';

interface SettingsValue {
  settings: SiteSettings;
  loading: boolean;
  refresh: () => void;
}
const SettingsContext = createContext<SettingsValue>({
  settings: DEFAULT_SETTINGS,
  loading: true,
  refresh: () => {},
});

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    fetchSettings()
      .then((data) => {
        setSettings({ ...DEFAULT_SETTINGS, ...(data.data || {}) } as SiteSettings);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  return (
    <SettingsContext.Provider value={{ settings, loading, refresh }}>
      {children}
    </SettingsContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export const useSettings = () => useContext(SettingsContext);
