export type ResourceStatus = 'draft' | 'published' | 'scheduled';
// Kept for StatusBadge compatibility
export type FileStatus = ResourceStatus;
export type Section = 'study' | 'books' | 'interview';

export interface ResourceI18n {
  title_en: string | null;
  description_en: string | null;
  category_en: string | null;
}

export interface Resource {
  id: number;
  title: string;
  description: string | null;
  section: Section;
  category: string | null;
  year: string | null;
  subject: string | null;
  author: string | null;
  edition: string | null;
  tags: string[] | null;
  file_name: string | null;
  file_path: string;
  file_url: string;
  file_size: number;
  file_type: string | null;
  cover_image_url: string | null;
  cover_path: string | null;
  status: ResourceStatus;
  featured: boolean;
  popular: boolean;
  download_count: number;
  view_count: number;
  scheduled_at: string | null;
  user_id: string | null;
  created_at: string;
  updated_at: string;
  en?: ResourceI18n | null;
}

export interface NursingCategory {
  id: number;
  name: string;
  slug: string | null;
  section: string | null;
  icon: string | null;
  sort: number;
  created_at: string;
  en?: { name_en: string | null } | null;
}

export interface SiteSettings {
  siteName: string;
  tagline: string;
  heroTitle: string;
  heroSubtitle: string;
  heroCta: string;
  aboutText: string;
  logoUrl: string;
  bannerUrl: string;
  telegram: string;
  facebook: string;
  email: string;
  footerText: string;
}

export interface SeriesPoint { key: string; label: string; visits: number; downloads: number; }
export interface Analytics {
  total: number; published: number; drafts: number; scheduled: number;
  downloads: number; used: number; quota: number; visitors: number;
  bySection: { study: number; books: number; interview: number };
  series: SeriesPoint[];
  topDownloaded: Resource[];
  recent: Resource[];
}

export interface PublicStats {
  resources: number; downloads: number; books: number; categories: number; visitors: number;
  files: number; sources: number;
}
