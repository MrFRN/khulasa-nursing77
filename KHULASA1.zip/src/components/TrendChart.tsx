import type { SeriesPoint } from '../types';

export default function TrendChart({ series }: { series: SeriesPoint[] }) {
  const max = Math.max(1, ...series.map((s) => Math.max(s.visits, s.downloads)));
  return (
    <div>
      <div className="flex items-end gap-1.5" style={{ height: 160 }}>
        {series.map((s, i) => (
          <div key={i} className="flex flex-1 flex-col items-center justify-end gap-1">
            <div className="flex w-full items-end justify-center gap-0.5" style={{ height: '100%' }}>
              <div className="w-1/2 rounded-t bg-primary/80 transition-all" style={{ height: `${(s.visits / max) * 100}%`, minHeight: s.visits ? 4 : 0 }} title={`زيارات: ${s.visits}`} />
              <div className="w-1/2 rounded-t bg-secondary/80 transition-all" style={{ height: `${(s.downloads / max) * 100}%`, minHeight: s.downloads ? 4 : 0 }} title={`تحميلات: ${s.downloads}`} />
            </div>
            <span className="text-[9px] text-slate-400">{s.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-center gap-5 text-xs text-slate-500 dark:text-slate-400">
        <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-primary/80" /> الزيارات</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-secondary/80" /> التحميلات</span>
      </div>
    </div>
  );
}
