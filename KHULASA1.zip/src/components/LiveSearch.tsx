import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Loader2, FileText } from 'lucide-react';
import { fetchResources } from '../lib/api';
import type { Resource } from '../types';

export default function LiveSearch({ compact = false }: { compact?: boolean }) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Resource[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    setLoading(true);
    const t = setTimeout(() => {
      fetchResources({ search: q.trim(), limit: '6' })
        .then((r) => { setResults(r); setOpen(true); })
        .catch(() => {})
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) { navigate(`/search?q=${encodeURIComponent(q.trim())}`); setOpen(false); }
  };

  const go = (id: number) => { navigate(`/resource/${id}`); setOpen(false); setQ(''); };

  return (
    <div ref={boxRef} className={`relative ${compact ? 'w-full' : 'w-full max-w-md'}`}>
      <form onSubmit={submit} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white/70 px-3 py-2 focus-within:border-primary dark:border-white/10 dark:bg-white/5">
        <Search className="h-4.5 w-4.5 shrink-0 text-slate-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => results.length && setOpen(true)}
          placeholder="ابحث عن ملف أو كتاب…"
          className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 outline-none dark:text-slate-100"
        />
        {loading && <Loader2 className="h-4 w-4 animate-spin text-slate-400" />}
      </form>
      {open && results.length > 0 && (
        <div className="absolute z-50 mt-2 w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl dark:border-white/10 dark:bg-navy-800">
          {results.map((r) => (
            <button key={r.id} onClick={() => go(r.id)} className="flex w-full items-center gap-3 px-3 py-2.5 text-right transition hover:bg-slate-50 dark:hover:bg-white/5">
              <div className="flex h-10 w-8 shrink-0 items-center justify-center overflow-hidden rounded bg-slate-100 dark:bg-white/10">
                {r.cover_image_url ? <img src={r.cover_image_url} alt="" className="h-full w-full object-cover" /> : <FileText className="h-4 w-4 text-slate-400" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-800 dark:text-slate-100">{r.title}</p>
                <p className="truncate text-xs text-slate-400">{r.subject || r.category || ''}</p>
              </div>
            </button>
          ))}
          <button onClick={submit} className="w-full bg-slate-50 px-3 py-2 text-center text-xs font-medium text-primary dark:bg-white/5">
            عرض كل النتائج
          </button>
        </div>
      )}
    </div>
  );
}
