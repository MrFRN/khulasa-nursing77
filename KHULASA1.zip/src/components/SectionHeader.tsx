import Icon from './Icon';

export default function SectionHeader({
  title, subtitle, icon, gradient = 'from-primary to-secondary', center = false,
}: { title: string; subtitle?: string; icon?: string; gradient?: string; center?: boolean }) {
  return (
    <div className={`mb-8 ${center ? 'text-center' : ''}`} data-section-header="v2">
      <div className={`flex items-center gap-3 ${center ? 'justify-center' : ''}`}>
        {icon && (
          <span className={`flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br ${gradient} text-white shadow-lg`}>
            <Icon name={icon} className="h-5 w-5" />
          </span>
        )}
        <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl">{title}</h2>
      </div>
      {subtitle && <p className={`mt-2 text-slate-500 dark:text-slate-400 ${center ? 'mx-auto max-w-2xl' : ''}`}>{subtitle}</p>}
    </div>
  );
}
