import type { ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, FileStack, Upload, FolderTree, Settings, LogOut, ExternalLink, Cross, BrainCircuit } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import ThemeToggle from './ThemeToggle';

const NAV = [
  { to: '/admin', label: 'لوحة التحكم', icon: LayoutDashboard, exact: true },
  { to: '/admin/resources', label: 'الملفات', icon: FileStack, exact: false },
  { to: '/admin/upload', label: 'رفع ملف', icon: Upload, exact: false },
  { to: '/admin/categories', label: 'التصنيفات', icon: FolderTree, exact: false },
  { to: '/admin/ai', label: 'المساعد الذكي', icon: BrainCircuit, exact: false },
  { to: '/admin/settings', label: 'الإعدادات', icon: Settings, exact: false },
];

export default function AdminShell({ children, title }: { children: ReactNode; title: string }) {
  const { pathname } = useLocation();
  const { user, signOut } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const active = (to: string, exact: boolean) => (exact ? pathname === to : pathname.startsWith(to));
  const doSignOut = async () => { await signOut(); navigate('/'); };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy lg:flex">
      <aside className="hidden w-64 shrink-0 border-l border-slate-200 bg-white dark:border-white/10 dark:bg-navy-800 lg:flex lg:flex-col">
        <Link to="/admin" className="flex h-16 items-center gap-2.5 border-b border-slate-100 px-6 dark:border-white/10">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary text-white"><Cross className="h-5 w-5" /></span>
          <span className="text-base font-extrabold text-slate-900 dark:text-white">{settings.siteName}</span>
        </Link>
        <nav className="flex-1 space-y-1 p-4">
          {NAV.map((item) => {
            const Icon = item.icon; const on = active(item.to, item.exact);
            return (
              <Link key={item.to} to={item.to} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${on ? 'bg-gradient-to-l from-primary to-primary-600 text-white shadow-lg shadow-primary/20' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5'}`}>
                <Icon className="h-4.5 w-4.5" /> {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="space-y-1 border-t border-slate-100 p-4 dark:border-white/10">
          <Link to="/" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5"><ExternalLink className="h-4.5 w-4.5" /> معاينة الموقع</Link>
          <button onClick={doSignOut} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5"><LogOut className="h-4.5 w-4.5" /> تسجيل الخروج</button>
        </div>
      </aside>

      {/* Mobile */}
      <div className="lg:hidden">
        <div className="flex h-14 items-center justify-between border-b border-slate-200 bg-white px-4 dark:border-white/10 dark:bg-navy-800">
          <span className="flex items-center gap-2 font-extrabold text-slate-900 dark:text-white"><Cross className="h-5 w-5 text-primary" /> {settings.siteName}</span>
          <div className="flex items-center gap-2"><ThemeToggle /><button onClick={doSignOut} className="text-sm text-slate-500">خروج</button></div>
        </div>
        <nav className="flex gap-1 overflow-x-auto border-b border-slate-200 bg-white px-2 py-2 dark:border-white/10 dark:bg-navy-800">
          {NAV.map((item) => { const Icon = item.icon; const on = active(item.to, item.exact); return (
            <Link key={item.to} to={item.to} className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-semibold ${on ? 'bg-primary text-white' : 'text-slate-600 dark:text-slate-300'}`}><Icon className="h-4 w-4" /> {item.label}</Link>
          ); })}
        </nav>
      </div>

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="mb-8 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">{title}</h1>
              {user?.email && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400" dir="ltr">{user.email}</p>}
            </div>
            <div className="hidden lg:block"><ThemeToggle /></div>
          </div>
          {children}
        </div>
      </main>
    </div>
  );
}
