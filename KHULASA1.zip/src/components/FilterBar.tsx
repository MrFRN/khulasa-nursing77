import { Search } from 'lucide-react';

export interface FilterConfig {
  key: string;
  placeholder: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}

const selectCls = 'rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-200';

export default function FilterBar({
  search, onSearch, filters = [], sort, onSort, sortOptions,
}: {
  search: string;
  onSearch: (v: string) => void;
  filters?: FilterConfig[];
  sort: string;
  onSort: (v: string) => void;
  sortOptions: { value: string; label: string }[];
}) {
  return (
    <div className="flex flex-wrap items-center gap-2.5">
      <div className="flex min-w-[220px] flex-1 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2.5 focus-within:border-primary dark:border-white/10 dark:bg-white/5">
        <Search className="h-4.5 w-4.5 text-slate-400" />
        <input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="ابحث…" className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 outline-none dark:text-slate-100" />
      </div>
      {filters.map((f) => (
        <select key={f.key} value={f.value} onChange={(e) => f.onChange(e.target.value)} className={selectCls}>
          <option value="">{f.placeholder}</option>
          {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      ))}
      <select value={sort} onChange={(e) => onSort(e.target.value)} className={selectCls}>
        {sortOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}
