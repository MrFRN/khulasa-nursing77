import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import Icon from './Icon';

export default function CategoryCard({
  to, name, count, icon, gradient = 'from-primary to-secondary', desc, index = 0,
}: { to: string; name: string; count?: number; icon: string; gradient?: string; desc?: string; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.06 }}
    >
      <Link to={to} className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 transition hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl hover:shadow-primary/10 dark:border-white/10 dark:bg-white/5">
        <span className={`mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${gradient} text-white shadow-lg`}>
          <Icon name={icon} className="h-7 w-7" />
        </span>
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">{name}</h3>
        {desc && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{desc}</p>}
        <div className="mt-auto flex items-center justify-between pt-4">
          {typeof count === 'number' && <span className="text-sm font-semibold text-slate-400">{count} ملف</span>}
          <ArrowLeft className="h-5 w-5 text-primary transition group-hover:-translate-x-1" />
        </div>
      </Link>
    </motion.div>
  );
}
