export default function ProgressBar({ value, error = false }: { value: number; error?: boolean }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
      <div
        className={`h-full rounded-full transition-all duration-200 ${error ? 'bg-red-500' : 'bg-gradient-to-l from-primary to-secondary'}`}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}
