import { Share2, Printer, Copy, Download, AlertTriangle, BookOpen, Pill, HeartPulse, FlaskConical, Stethoscope, ExternalLink, FileText } from 'lucide-react';
import type { AiReport } from '../lib/api';

function Section({ icon: Icon, title, accent, children }: { icon: any; title: string; accent: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
      <h3 className={`mb-3 flex items-center gap-2 text-base font-extrabold text-slate-900 dark:text-white`}>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${accent} text-white`}><Icon className="h-4 w-4" /></span>
        {title}
      </h3>
      <div className="space-y-2">{children}</div>
    </section>
  );
}

function List({ items, ordered }: { items: string[]; ordered?: boolean }) {
  if (!items || items.length === 0) return <p className="text-sm text-slate-400">—</p>;
  const cls = 'text-sm leading-relaxed text-slate-700 dark:text-slate-200';
  if (ordered) return <ol className={`list-decimal space-y-1 pr-5 ${cls}`}>{items.map((i, k) => <li key={k}>{i}</li>)}</ol>;
  return <ul className={`list-disc space-y-1 pr-5 ${cls}`}>{items.map((i, k) => <li key={k}>{i}</li>)}</ul>;
}

function toPlainText(r: AiReport, lang: string): string {
  const ar = lang === 'ar';
  const L: string[] = [];
  L.push(ar ? 'تقرير المساعد السريري الذكي (تعليمي فقط)' : 'AI Clinical Assistant Report (education only)');
  L.push(r.disclaimer);
  L.push('');
  L.push(ar ? 'التشخيص التفريقي المرجّح:' : 'Ranked Differential Diagnoses:');
  r.differentials.forEach((d, i) => L.push(`${i + 1}. ${d.name} — ${ar ? 'ثقة' : 'confidence'} ${d.confidence}% | ${d.reasoning}`));
  L.push('');
  L.push(ar ? 'الفحوصات الموصى بها:' : 'Recommended Investigations:'); r.sections.investigations.forEach((i) => L.push(' - ' + i));
  L.push('');
  L.push(ar ? 'العلاج:' : 'Treatment:'); L.push((ar ? 'أولي: ' : 'Initial: ') + r.sections.treatment.initial.join(', '));
  L.push((ar ? 'خط أول: ' : 'First-line: ') + r.sections.treatment.firstLine.join(', '));
  L.push((ar ? 'بدائل: ' : 'Alternative: ') + r.sections.treatment.alternative.join(', '));
  L.push('');
  L.push(ar ? 'الأدوية:' : 'Drug Information:'); r.sections.drugs.forEach((d) => L.push(` - ${d.generic} (${d.trade}): ${d.adultDose} ${d.route} ${d.frequency}`));
  L.push('');
  L.push(ar ? 'الأعلام الحمراء:' : 'Red Flags:'); r.sections.redFlags.forEach((f) => L.push(' - ' + f));
  L.push('');
  L.push(ar ? 'المراجع:' : 'References:'); r.sections.references.forEach((rf) => L.push(` - ${rf.abbr}: ${rf.note} ${rf.url}`));
  return L.join('\n');
}

export default function ReportView({ report, lang = 'en', onClose }: { report: AiReport; lang?: 'en' | 'ar'; onClose?: () => void }) {
  const ar = lang === 'ar';
  const copy = async () => {
    try { await navigator.clipboard.writeText(toPlainText(report, lang)); } catch {}
  };
  const share = async () => {
    const text = toPlainText(report, lang);
    if (navigator.share) { try { await navigator.share({ title: ar ? 'تقرير المساعد السريري الذكي' : 'AI Clinical Assistant Report', text }); return; } catch {} }
    copy();
  };
  const print = () => window.print();

  return (
    <div className="ai-report space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 dark:border-amber-500/30 dark:bg-amber-500/10">
        <div className="flex items-center gap-2 text-sm font-semibold text-amber-800 dark:text-amber-200">
          <AlertTriangle className="h-5 w-5" /> {report.disclaimer}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={copy} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><Copy className="h-3.5 w-3.5" /> {ar ? 'نسخ' : 'Copy'}</button>
          <button onClick={share} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><Share2 className="h-3.5 w-3.5" /> {ar ? 'مشاركة' : 'Share'}</button>
          <button onClick={print} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><Printer className="h-3.5 w-3.5" /> {ar ? 'طباعة/PDF' : 'Print / PDF'}</button>
          {onClose && <button onClick={onClose} className="inline-flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-white"><Download className="h-3.5 w-3.5" /> {ar ? 'إغلاق' : 'Close'}</button>}
        </div>
      </div>

      {/* Differentials */}
      <Section icon={Stethoscope} title={ar ? 'التشخيص التفريقي المرجّح' : 'Ranked Differential Diagnoses'} accent="from-primary to-primary-600">
        <div className="space-y-3">
          {report.differentials.map((d, i) => (
            <div key={d.id} className="rounded-xl border border-slate-200 p-3 dark:border-white/10">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 dark:text-white">{i + 1}. {d.name}</span>
                <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-bold text-primary">{d.confidence}%</span>
              </div>
              <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                <div className="h-full rounded-full bg-gradient-to-l from-primary to-secondary" style={{ width: `${d.confidence}%` }} />
              </div>
              <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{d.reasoning}</p>
              {d.matchedSymptoms.length > 0 && <p className="mt-1 text-xs text-slate-400">{ar ? 'أعراض مدعومة: ' : 'Supported symptoms: '}{d.matchedSymptoms.join(ar ? '، ' : ', ')}</p>}
            </div>
          ))}
          {report.differentials.length === 0 && <p className="text-sm text-slate-400">{ar ? 'لا توجد تشخيصات مرشّحة كافية — أدخل المزيد من الأعراض والعلامات.' : 'No sufficient candidate diagnoses — add more symptoms and signs.'}</p>}
        </div>
      </Section>

      <div className="grid gap-4 lg:grid-cols-2">
        <Section icon={FlaskConical} title={ar ? 'الفحوصات الموصى بها' : 'Recommended Investigations'} accent="from-secondary to-secondary-600">
          <List items={report.sections.investigations} ordered />
        </Section>

        <Section icon={AlertTriangle} title={ar ? 'الأعلام الحمراء' : 'Red Flags'} accent="from-red-500 to-rose-600">
          <ul className="space-y-1">
            {report.sections.redFlags.length === 0 && <li className="text-sm text-slate-400">—</li>}
            {report.sections.redFlags.map((f, k) => (
              <li key={k} className="flex items-start gap-2 rounded-lg bg-red-50 p-2 text-sm font-semibold text-red-700 dark:bg-red-500/10 dark:text-red-300">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {f}
              </li>
            ))}
          </ul>
        </Section>
      </div>

      <Section icon={HeartPulse} title={ar ? 'الخطة العلاجية القائمة على الأدلة' : 'Evidence-Based Treatment'} accent="from-emerald-500 to-teal-600">
        <div className="grid gap-3 sm:grid-cols-2">
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'الإدارة الأولية' : 'Initial Management'}</div><List items={report.sections.treatment.initial} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'العلاج الخط الأول' : 'First-line Therapy'}</div><List items={report.sections.treatment.firstLine} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'علاج بديل' : 'Alternative Therapy'}</div><List items={report.sections.treatment.alternative} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'موانع استعمال' : 'Contraindications'}</div><List items={report.sections.treatment.contraindications} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'المتابعة والمراقبة' : 'Monitoring & Follow-up'}</div><List items={[...report.sections.treatment.monitoring, ...report.sections.treatment.followUp]} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'معايير الدخول والعناية' : 'Admission & ICU Criteria'}</div><List items={[...report.sections.treatment.admission, ...report.sections.treatment.icu]} /></div>
        </div>
      </Section>

      <Section icon={HeartPulse} title={ar ? 'الرعاية التمريضية' : 'Nursing Management'} accent="from-pink-500 to-rose-500">
        <div className="space-y-4">
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '1) تشخيصات التمريض (NANDA)' : '1) Nursing Diagnoses (NANDA)'}</div>
            <div className="space-y-2">
              {report.sections.nursing.nanda.map((d, i) => (
                <div key={i} className="rounded-xl border border-pink-200 bg-pink-50/60 p-3 text-sm leading-relaxed text-slate-800 dark:border-pink-500/20 dark:bg-pink-500/5 dark:text-slate-100">
                  {d}
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '2) أهداف التمريض' : '2) Nursing Goals'}</div>
            <List ordered items={report.sections.nursing.goals} />
          </div>
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '3) التدخلات التمريضية (NIC)' : '3) Nursing Interventions (NIC)'}</div>
            <List items={report.sections.nursing.nic} />
            {report.sections.nursing.assessment?.length > 0 && (
              <div className="mt-2 text-sm text-slate-500"><span className="font-semibold">{ar ? 'التقييم: ' : 'Assessment: '}</span>{report.sections.nursing.assessment.join(' · ')}</div>
            )}
          </div>
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '4) التقييم' : '4) Evaluation'}</div>
            <List items={report.sections.nursing.evaluation} />
          </div>
          {report.sections.nursing.education?.length > 0 && (
            <div className="text-sm text-slate-500"><span className="font-semibold">{ar ? 'تثقيف المريض: ' : 'Patient Education: '}</span>{report.sections.nursing.education.join(' · ')}</div>
          )}
          {report.sections.nursing.discharge?.length > 0 && (
            <div className="text-sm text-slate-500"><span className="font-semibold">{ar ? 'تعليمات الخروج: ' : 'Discharge Instructions: '}</span>{report.sections.nursing.discharge.join(' · ')}</div>
          )}
        </div>
      </Section>

      <Section icon={Pill} title={ar ? 'معلومات الأدوية' : 'Drug Information'} accent="from-indigo-500 to-purple-600">
        <div className="space-y-3">
          {report.sections.drugs.length === 0 && <p className="text-sm text-slate-400">—</p>}
          {report.sections.drugs.map((d, k) => (
            <div key={k} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
              <div className="font-bold text-slate-900 dark:text-white">{d.generic} <span className="text-xs font-normal text-slate-400">({d.trade})</span></div>
              <div className="mt-1 grid gap-1 sm:grid-cols-2 text-slate-600 dark:text-slate-300">
                <div>{ar ? 'الجرعة البالغين: ' : 'Adult dose: '}{d.adultDose}</div><div>{ar ? 'جرعة الأطفال: ' : 'Pediatric dose: '}{d.pedDose}</div>
                <div>{ar ? 'الطريق: ' : 'Route: '}{d.route}</div><div>{ar ? 'التكرار: ' : 'Frequency: '}{d.frequency}</div>
                <div className="sm:col-span-2">{ar ? 'موانع: ' : 'Contraindications: '}{d.contraindications}</div>
                <div className="sm:col-span-2">{ar ? 'أعراض جانبية: ' : 'Side effects: '}{d.sideEffects}</div>
                <div className="sm:col-span-2">{ar ? 'تفاعلات: ' : 'Interactions: '}{d.interactions}</div>
                <div className="sm:col-span-2">{ar ? 'اعتبارات تمريضية: ' : 'Nursing considerations: '}{d.nursing}</div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {report.relatedPdfs.length > 0 && (
        <Section icon={FileText} title={ar ? 'ملفات ذات صلة من مكتبتك' : 'Related PDFs from Your Library'} accent="from-accent to-orange-500">
          <div className="grid gap-3 sm:grid-cols-2">
            {report.relatedPdfs.map((p) => (
              <a key={p.id} href={`/resource/${p.id}`} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 transition hover:border-primary dark:border-white/10">
                {p.cover ? <img src={p.cover} alt="" className="h-12 w-12 rounded-lg object-cover" /> : <BookOpen className="h-8 w-8 text-primary" />}
                <span className="text-sm font-semibold text-slate-800 dark:text-slate-100 line-clamp-2">{p.title}</span>
              </a>
            ))}
          </div>
        </Section>
      )}

      <Section icon={BookOpen} title={ar ? 'المراجع الموثوقة (RAG)' : 'Trusted References (RAG)'} accent="from-slate-600 to-slate-800">
        <ul className="space-y-1">
          {report.sections.references.map((rf, k) => (
            <li key={k}>
              <a href={rf.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
                {rf.abbr} <ExternalLink className="h-3 w-3" />
              </a>
              <span className="text-sm text-slate-600 dark:text-slate-300"> — {rf.note}</span>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}
