import { Loader2 } from 'lucide-react';

export default function Spinner({ label, className = '' }: { label?: string; className?: string }) {
  return (
    <div className={`flex items-center gap-3 text-slate-500 dark:text-slate-400 ${className}`}>
      <Loader2 className="h-5 w-5 animate-spin" />
      {label && <span className="text-sm">{label}</span>}
    </div>
  );
}
