import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Heart, LayoutDashboard, LogIn, Cross } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import ThemeToggle from './ThemeToggle';
import LiveSearch from './LiveSearch';

const LINKS = [
  { to: '/', label: 'الرئيسية' },
  { to: '/study', label: 'ملفات دراسية' },
  { to: '/books', label: 'كتب' },
  { to: '/interview', label: 'أسئلة المقابلات' },
  { to: '/ai-assistant', label: 'AI Assistant' },
];

export default function Navbar() {
  const { user } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-lg px-3 py-2 text-sm font-semibold transition ${isActive ? 'text-primary' : 'text-slate-600 hover:text-primary dark:text-slate-300'}`;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/70 glass dark:border-white/10">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link to="/" className="flex shrink-0 items-center gap-2.5">
          {settings.logoUrl ? (
            <img src={settings.logoUrl} alt={settings.siteName} className="h-10 w-10 rounded-xl object-cover" />
          ) : (
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary text-white shadow-lg shadow-primary/30">
              <Cross className="h-5 w-5" />
            </span>
          )}
          <span className="hidden text-lg font-extrabold tracking-tight text-slate-900 dark:text-white sm:block">{settings.siteName}</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => <NavLink key={l.to} to={l.to} className={linkClass} end={l.to === '/'}>{l.label}</NavLink>)}
        </nav>

        {/* Desktop search */}
        <div className="hidden flex-1 justify-center lg:flex"><LiveSearch /></div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Link to="/favorites" aria-label="المفضلة" className="hidden h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white/60 text-slate-600 transition hover:text-accent dark:border-white/10 dark:bg-white/5 dark:text-slate-300 sm:flex">
            <Heart className="h-5 w-5" />
          </Link>
          <ThemeToggle />
          <button
            onClick={() => navigate(user ? '/admin' : '/login')}
            className="hidden items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-primary/30 transition hover:opacity-90 sm:flex"
          >
            {user ? <LayoutDashboard className="h-4 w-4" /> : <LogIn className="h-4 w-4" />}
            {user ? 'لوحة التحكم' : 'تسجيل الدخول'}
          </button>
          <button onClick={() => setOpen(true)} className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-600 dark:border-white/10 dark:text-slate-300 lg:hidden" aria-label="القائمة">
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm lg:hidden" />
            <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'tween', duration: 0.28 }} className="fixed inset-y-0 end-0 z-50 flex w-72 flex-col bg-white p-5 shadow-2xl dark:bg-navy-800 lg:hidden">
              <div className="mb-5 flex items-center justify-between">
                <span className="text-lg font-extrabold text-slate-900 dark:text-white">{settings.siteName}</span>
                <button onClick={() => setOpen(false)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-white/10"><X className="h-5 w-5" /></button>
              </div>
              <div className="mb-4"><LiveSearch compact /></div>
              <nav className="flex flex-col gap-1">
                {LINKS.map((l) => (
                  <NavLink key={l.to} to={l.to} end={l.to === '/'} onClick={() => setOpen(false)} className={({ isActive }) => `rounded-lg px-3 py-2.5 text-sm font-semibold ${isActive ? 'bg-primary/10 text-primary' : 'text-slate-600 dark:text-slate-300'}`}>{l.label}</NavLink>
                ))}
                <NavLink to="/favorites" onClick={() => setOpen(false)} className={({ isActive }) => `flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold ${isActive ? 'bg-primary/10 text-primary' : 'text-slate-600 dark:text-slate-300'}`}><Heart className="h-4 w-4" /> المفضلة</NavLink>
              </nav>
              <button onClick={() => { setOpen(false); navigate(user ? '/admin' : '/login'); }} className="mt-auto flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-4 py-2.5 text-sm font-semibold text-white">
                {user ? <LayoutDashboard className="h-4 w-4" /> : <LogIn className="h-4 w-4" />}
                {user ? 'لوحة التحكم' : 'تسجيل الدخول'}
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
