import { isImageType, isPdfType } from '../lib/filetypes';
import { FileQuestion, Download } from 'lucide-react';

export default function PdfViewer({
  url,
  fileType,
  className = '',
}: {
  url: string;
  fileType?: string | null;
  className?: string;
}) {
  const image = isImageType(fileType) || isImageType(url);
  const pdf = isPdfType(fileType) || isPdfType(url);

  if (image) {
    return (
      <div className={`flex items-center justify-center overflow-auto bg-stone-100 ${className}`}>
        <img src={url} alt="Preview" className="max-h-full max-w-full object-contain" />
      </div>
    );
  }
  if (pdf) {
    return <iframe src={url} title="PDF preview" className={`w-full bg-stone-100 ${className}`} />;
  }
  return (
    <div className={`flex flex-col items-center justify-center gap-3 bg-stone-50 text-stone-500 ${className}`}>
      <FileQuestion className="h-10 w-10" />
      <p className="text-sm">Inline preview is not available for this file type.</p>
      <a
        href={url}
        target="_blank"
        rel="noreferrer"
        className="inline-flex items-center gap-2 rounded-lg border border-stone-300 bg-white px-3 py-1.5 text-sm font-medium text-stone-700 hover:bg-stone-50"
      >
        <Download className="h-4 w-4" /> Open file
      </a>
    </div>
  );
}
