import { ChevronRight, ChevronLeft } from 'lucide-react';

export default function Pagination({ page, totalPages, onChange }: { page: number; totalPages: number; onChange: (p: number) => void }) {
  if (totalPages <= 1) return null;
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1).filter(
    (p) => p === 1 || p === totalPages || Math.abs(p - page) <= 1
  );
  const out: (number | '...')[] = [];
  let last = 0;
  for (const p of pages) { if (p - last > 1) out.push('...'); out.push(p); last = p; }

  const btn = 'flex h-9 min-w-9 items-center justify-center rounded-lg border px-2 text-sm font-semibold transition';
  return (
    <div className="mt-10 flex items-center justify-center gap-1.5">
      <button disabled={page === 1} onClick={() => onChange(page - 1)} className={`${btn} border-slate-200 text-slate-500 disabled:opacity-40 hover:border-primary hover:text-primary dark:border-white/10`}><ChevronRight className="h-4 w-4" /></button>
      {out.map((p, i) => p === '...' ? (
        <span key={i} className="px-1 text-slate-400">…</span>
      ) : (
        <button key={i} onClick={() => onChange(p)} className={`${btn} ${p === page ? 'border-primary bg-primary text-white' : 'border-slate-200 text-slate-600 hover:border-primary hover:text-primary dark:border-white/10 dark:text-slate-300'}`}>{p}</button>
      ))}
      <button disabled={page === totalPages} onClick={() => onChange(page + 1)} className={`${btn} border-slate-200 text-slate-500 disabled:opacity-40 hover:border-primary hover:text-primary dark:border-white/10`}><ChevronLeft className="h-4 w-4" /></button>
    </div>
  );
}
