import { createContext, useContext, useState, useCallback } from 'react';
import type { ReactNode } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info';
interface Toast { id: number; type: ToastType; message: string; }

interface ToastValue {
  toast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastValue>({ toast: () => {} });

let counter = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const remove = useCallback((id: number) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const toast = useCallback((message: string, type: ToastType = 'info') => {
    const id = ++counter;
    setToasts((t) => [...t, { id, type, message }]);
    setTimeout(() => remove(id), 4200);
  }, [remove]);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-5 right-5 z-[100] flex flex-col gap-2 w-[calc(100vw-2.5rem)] max-w-sm">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="animate-fade-up flex items-start gap-3 rounded-xl border border-stone-200 bg-white px-4 py-3 shadow-lg shadow-stone-900/5"
          >
            {t.type === 'success' && <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />}
            {t.type === 'error' && <AlertCircle className="h-5 w-5 shrink-0 text-red-500" />}
            {t.type === 'info' && <Info className="h-5 w-5 shrink-0 text-stone-500" />}
            <p className="text-sm leading-snug text-stone-700 flex-1">{t.message}</p>
            <button onClick={() => remove(t.id)} className="text-stone-400 hover:text-stone-700">
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export const useToast = () => useContext(ToastContext);
