import type { NursingCategory, Section } from '../types';

export interface MetaForm {
  title: string;
  description: string;
  section: Section;
  category: string;
  year: string;
  subject: string;
  author: string;
  edition: string;
  tags: string;
  featured: boolean;
  popular: boolean;
  status: 'draft' | 'published' | 'scheduled';
  scheduled_at: string;
}

export function emptyMeta(section: Section = 'study'): MetaForm {
  return {
    title: '', description: '', section, category: '', year: '', subject: '',
    author: '', edition: '', tags: '', featured: false, popular: false,
    status: 'published', scheduled_at: '',
  };
}

const input = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white';
const label = 'mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200';

const SECTION_OPTS: { value: Section; label: string }[] = [
  { value: 'study', label: 'ملفات دراسية' },
  { value: 'books', label: 'كتب التمريض' },
  { value: 'interview', label: 'أسئلة الانترفيو' },
];

export default function FileMetaForm({
  value, onChange, categories, idPrefix,
}: { value: MetaForm; onChange: (v: MetaForm) => void; categories: NursingCategory[]; idPrefix: string }) {
  const set = (patch: Partial<MetaForm>) => onChange({ ...value, ...patch });
  const sectionCats = categories.filter((c) => c.section === value.section);

  return (
    <div className="space-y-4">
      <div>
        <label className={label}>العنوان <span className="text-red-500">*</span></label>
        <input className={input} value={value.title} onChange={(e) => set({ title: e.target.value })} placeholder="عنوان الملف" />
      </div>
      <div>
        <label className={label}>الوصف</label>
        <textarea className={`${input} min-h-20 resize-y`} value={value.description} onChange={(e) => set({ description: e.target.value })} placeholder="وصف مختصر يظهر للزوار" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className={label}>القسم</label>
          <select className={input} value={value.section} onChange={(e) => set({ section: e.target.value as Section, category: '' })}>
            {SECTION_OPTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <div>
          <label className={label}>{value.section === 'study' ? 'الفرقة / التصنيف' : 'التصنيف'}</label>
          <select className={input} value={value.category} onChange={(e) => set({ category: e.target.value })}>
            <option value="">بدون تصنيف</option>
            {sectionCats.map((c) => <option key={c.id} value={c.slug || ''}>{c.name}</option>)}
          </select>
        </div>
        {value.section === 'study' && (
          <div>
            <label className={label}>السنة الدراسية</label>
            <input className={input} value={value.year} onChange={(e) => set({ year: e.target.value })} placeholder="مثال: 2024/2025" />
          </div>
        )}
        {value.section !== 'books' && (
          <div>
            <label className={label}>المادة</label>
            <input className={input} value={value.subject} onChange={(e) => set({ subject: e.target.value })} placeholder="مثال: التشريح" />
          </div>
        )}
        {value.section === 'books' && (
          <>
            <div>
              <label className={label}>المؤلف</label>
              <input className={input} value={value.author} onChange={(e) => set({ author: e.target.value })} placeholder="اسم المؤلف" />
            </div>
            <div>
              <label className={label}>الإصدار</label>
              <input className={input} value={value.edition} onChange={(e) => set({ edition: e.target.value })} placeholder="مثال: الطبعة الثالثة" />
            </div>
          </>
        )}
      </div>
      <div>
        <label className={label}>وسوم <span className="font-normal text-slate-400">(مفصولة بفاصلة)</span></label>
        <input className={input} value={value.tags} onChange={(e) => set({ tags: e.target.value })} placeholder="امتحان, ملخص, 2024" />
      </div>
      <div className="flex flex-wrap gap-5">
        <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 dark:text-slate-200">
          <input type="checkbox" checked={value.featured} onChange={(e) => set({ featured: e.target.checked })} className="h-4 w-4 rounded accent-primary" /> مميز
        </label>
        <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 dark:text-slate-200">
          <input type="checkbox" checked={value.popular} onChange={(e) => set({ popular: e.target.checked })} className="h-4 w-4 rounded accent-primary" /> شائع
        </label>
      </div>
      <div>
        <label className={label}>حالة النشر</label>
        <div className="grid grid-cols-3 gap-2">
          {(['draft', 'published', 'scheduled'] as const).map((s) => (
            <button key={s} type="button" onClick={() => set({ status: s })} className={`rounded-lg border px-3 py-2 text-sm font-semibold transition ${value.status === s ? 'border-primary bg-primary text-white' : 'border-slate-300 bg-white text-slate-600 hover:bg-slate-50 dark:border-white/10 dark:bg-white/5 dark:text-slate-300'}`}>
              {s === 'draft' ? 'مسودة' : s === 'published' ? 'نشر' : 'جدولة'}
            </button>
          ))}
        </div>
        {value.status === 'scheduled' && (
          <input type="datetime-local" value={value.scheduled_at} onChange={(e) => set({ scheduled_at: e.target.value })} className={`${input} mt-2`} id={`${idPrefix}-sched`} />
        )}
      </div>
    </div>
  );
}
