import { useEffect, useMemo, useState } from 'react';
import { Save, Send, Sparkles, Trash2 } from 'lucide-react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useToast } from './Toast';
import { useAuth } from '../contexts/AuthContext';

export interface AIField {
  key: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'textarea' | 'multiselect';
  options?: { value: string; label: string }[];
  placeholder?: string;
  min?: number;
  max?: number;
  required?: boolean;
  hint?: string;
}

export interface AIConfig {
  key: string;
  title: string;
  titleEn: string;
  subtitleEn: string;
  subtitleAr: string;
  icon?: any;
  endpoint: string;
  fields: AIField[];
  renderResult: (data: any, lang: 'en' | 'ar') => React.ReactNode;
  sampleInput?: any;
  draftKey?: string;
}

export default function AITool({ config }: { config: AIConfig }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [lang, setLang] = useState<'en' | 'ar'>('en');
  const isAr = lang === 'ar';
  const [form, setForm] = useState<any>(config.sampleInput || {});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);

  const draftKey = `${config.draftKey || config.key}-${lang}`;
  useEffect(() => {
    try {
      const saved = localStorage.getItem(draftKey);
      if (saved) setForm(JSON.parse(saved));
    } catch {}
  }, [draftKey]);
  useEffect(() => {
    try { localStorage.setItem(draftKey, JSON.stringify(form)); } catch {}
  }, [form, draftKey]);

  const submit = async () => {
    setLoading(true); setResult(null);
    try {
      const langField = { lang };
      const res = await fetch(config.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, ...langField }) });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || 'Request failed');
      setResult(j);
      if (lang === 'ar' && user) toast('تم حفظ التحليل في سجلك', 'success');
    } catch (e: any) { toast(e.message || 'Request failed', 'error'); }
    finally { setLoading(false); }
  };

  const loadHistory = async () => {
    if (!user) { toast(isAr ? 'سجّل الدخول لعرض سجلك' : 'Log in to view history', 'error'); return; }
    try {
      setHistoryLoading(true); setShowHistory(true);
      const res = await fetch('/api/ai-history');
      const j = await res.json();
      setHistory(j || []);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setHistoryLoading(false); }
  };

  const set = (key: string, value: any) => setForm((f: any) => ({ ...f, [key]: value }));

  const Field = ({ f }: { f: AIField }) => {
    const common = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white';
    if (f.type === 'select') {
      return (
        <div>
          <label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">{f.label}{f.required ? ' *' : ''}</label>
          <select value={form[f.key] || ''} onChange={(e) => set(f.key, e.target.value)} className={common}>
            <option value="">{isAr ? 'اختر...' : 'Select...'}</option>
            {(f.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      );
    }
    if (f.type === 'textarea') {
      return (
        <div>
          <label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">{f.label}{f.required ? ' *' : ''}</label>
          <textarea className={`${common} min-h-20`} value={form[f.key] || ''} onChange={(e) => set(f.key, e.target.value)} placeholder={f.placeholder} />
        </div>
      );
    }
    if (f.type === 'multiselect') {
      const selected = new Set(form[f.key] || []);
      return (
        <div>
          <label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">{f.label}</label>
          <div className="flex flex-wrap gap-2">
            {(f.options || []).slice(0, 40).map((o) => {
              const on = selected.has(o.value);
              return (
                <button key={o.value} type="button" onClick={() => {
                  const next = new Set(selected);
                  if (on) next.delete(o.value); else next.add(o.value);
                  set(f.key, Array.from(next));
                }} className={`rounded-full px-3 py-1 text-xs font-semibold transition ${on ? 'bg-primary text-white' : 'border border-slate-300 dark:border-white/10'}`}>{o.label}</button>
              );
            })}
          </div>
        </div>
      );
    }
    return (
      <div>
        <label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">{f.label}{f.required ? ' *' : ''}</label>
        <input type={f.type === 'number' ? 'number' : 'text'} inputMode={f.type === 'number' ? 'decimal' : 'text'} min={f.min} max={f.max} className={common} value={form[f.key] || ''} onChange={(e) => set(f.key, f.type === 'number' ? Number(e.target.value) : e.target.value)} placeholder={f.placeholder} />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white sm:text-3xl">{isAr ? config.subtitleAr : config.titleEn}</h1>
            <p className="text-sm text-slate-500 dark:text-slate-300">{isAr ? config.subtitleAr : config.subtitleEn}</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setLang('en')} className={`rounded-full border px-3 py-1 text-sm font-bold ${!isAr ? 'bg-primary text-white border-primary' : 'border-slate-300 dark:border-white/10'}`}>EN</button>
            <button onClick={() => setLang('ar')} className={`rounded-full border px-3 py-1 text-sm font-bold ${isAr ? 'bg-primary text-white border-primary' : 'border-slate-300 dark:border-white/10'}`}>ع</button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
            <h2 className="mb-4 flex items-center gap-2 font-bold text-slate-900 dark:text-white"><Sparkles className="h-5 w-5 text-primary" /> {isAr ? 'المدخلات' : 'Inputs'}</h2>
            <div className="space-y-3">
              {config.fields.map((f, i) => <Field key={i} f={f} />)}
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <button onClick={submit} disabled={loading} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 disabled:opacity-60">
                {loading ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" /> : <Send className="h-4 w-4" />} {isAr ? 'تشغيل' : 'Run'}
              </button>
              <button onClick={loadHistory} className="inline-flex items-center gap-1 rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold hover:bg-slate-50 dark:border-white/10 dark:hover:bg-white/5"><Save className="h-4 w-4" /> {isAr ? 'سجلي' : 'History'}</button>
              <button onClick={() => setForm({})} className="inline-flex items-center gap-1 rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold hover:bg-slate-50 dark:border-white/10 dark:hover:bg-white/5"><Trash2 className="h-4 w-4" /> {isAr ? 'مسح' : 'Reset'}</button>
            </div>
          </div>

          <div className="lg:sticky lg:top-4 lg:self-start">
            {result ? (
              <div className="space-y-4">
                <div className="rounded-2xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">
                  {result.disclaimer || (isAr ? 'هذه الأداة لأغراض تعليمية فقط.' : 'For educational purposes only.')}
                </div>
                {config.renderResult(result, lang)}
              </div>
            ) : (
              <div className="flex min-h-[300px] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-white/10">
                <Sparkles className="h-12 w-12 text-slate-300 dark:text-slate-600" />
                <p className="mt-3 text-sm text-slate-400">{isAr ? 'أدخل البيانات واضغط «تشغيل»' : 'Enter your data and click Run.'}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {showHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowHistory(false)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5 dark:bg-navy-800" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between"><h3 className="font-bold text-slate-900 dark:text-white">{isAr ? 'سجل التحليلات' : 'Analysis History'}</h3><button onClick={() => setShowHistory(false)} className="text-slate-400 hover:text-slate-600">✕</button></div>
            {historyLoading ? <p className="text-sm text-slate-400">{isAr ? 'جارٍ التحميل…' : 'Loading…'}</p> : history.length === 0 ? <p className="text-sm text-slate-400">{isAr ? 'لا توجد تحليلات محفوظة.' : 'No saved analyses.'}</p> : (
              <ul className="space-y-2">
                {history.map((h) => (
                  <li key={h.id} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
                    <div className="font-semibold">{h.title}</div>
                    <div className="text-xs text-slate-400">{h.top_diagnosis} · {new Date(h.created_at).toLocaleString(isAr ? 'ar-EG' : 'en-US')}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
