import { useEffect } from 'react';
import type { ReactNode } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { trackEvent } from '../lib/api';

export default function PublicLayout({ children }: { children: ReactNode }) {
  useEffect(() => {
    try {
      if (!sessionStorage.getItem('visit-logged')) {
        sessionStorage.setItem('visit-logged', '1');
        trackEvent('visit', window.location.pathname);
      }
    } catch { /* ignore */ }
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
