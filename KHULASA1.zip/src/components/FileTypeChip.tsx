import { labelForFile } from '../lib/filetypes';

export default function FileTypeChip({ name }: { name: string | null | undefined }) {
  return (
    <span className="inline-flex items-center rounded-md bg-stone-900 px-1.5 py-0.5 text-[10px] font-semibold tracking-wide text-white">
      {labelForFile(name)}
    </span>
  );
}
