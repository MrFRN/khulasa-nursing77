import { readFileSync } from 'node:fs';
if (typeof globalThis.WebSocket === 'undefined') globalThis.WebSocket = class { constructor(){throw new Error('x')} close(){} };
import { createClient } from '@supabase/supabase-js';
const env = readFileSync('.env','utf8');
const get=(k)=>{const m=env.match(new RegExp(`^${k}=(.*)$`,'m'));return m?m[1].trim().replace(/^["']|["']$/g,''):undefined;};
const supabase=createClient(get('NEXT_PUBLIC_SUPABASE_URL'),get('SUPABASE_SERVICE_ROLE_KEY'),{auth:{persistSession:false},realtime:{enabled:false}});

const { data: cats } = await supabase.from('nursing_categories').select('name, slug, section');
const slugSet = new Set(cats.map(c=>c.slug));
const nameToSlug = {};
for (const c of cats) nameToSlug[c.name] = c.slug; // last wins (accept duplicates)
const slugToName = {};
for (const c of cats) slugToName[c.slug] = c.name;

function slugify(s){ return String(s).toLowerCase().trim().replace(/[^a-z0-9؀-ۿ]+/g,'-').replace(/^-+|-+$/g,''); }

const { data: resources } = await supabase.from('resources').select('id, category, section');
let updated=0, zero=0;
for (const r of resources||[]) {
  let slug = r.category;
  if (slugSet.has(slug)) { /* already a slug */ }
  else if (nameToSlug[slug]) slug = nameToSlug[slug];
  else slug = slugify(slug); // generate from name
  if (!slug) { zero++; continue; }
  if (slug === r.category) continue;
  const { error } = await supabase.from('resources').update({ category: slug }).eq('id', r.id);
  if (!error) updated++; else console.log('update err', r.id, error.message);
}
console.log(`normalized category -> slug: updated=${updated} zero=${zero} total=${resources?.length}`);
// show a sample
const { data: sample } = await supabase.from('resources').select('id,title,category').limit(3);
console.log('sample:', JSON.stringify(sample));
