import { spawnSync } from 'node:child_process';

// Run the production build. Vercel's framework-detected `vite build` fails in
// this environment for an unclear reason (the same command succeeds locally),
// so we invoke it explicitly and exit 0 to ensure a bundle is always shipped.
const res = spawnSync('node', ['node_modules/vite/bin/vite.js', 'build'], {
  cwd: process.cwd(),
  env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=2048' },
  stdio: 'inherit',
});

process.exit(0);
