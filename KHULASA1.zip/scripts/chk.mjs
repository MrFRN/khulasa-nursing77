import { readFileSync } from 'node:fs';
if (typeof globalThis.WebSocket === 'undefined') globalThis.WebSocket = class { constructor(){throw new Error('x')} close(){} };
import { createClient } from '@supabase/supabase-js';
const env = readFileSync('.env','utf8');
const get=(k)=>{const m=env.match(new RegExp(`^${k}=(.*)$`,'m'));return m?m[1].trim().replace(/^["']|["']$/g,''):undefined;};
const supabase=createClient(get('NEXT_PUBLIC_SUPABASE_URL'),get('SUPABASE_SERVICE_ROLE_KEY'),{auth:{persistSession:false},realtime:{enabled:false}});
const {data,error}=await supabase.from('resources').select('id,category,category_slug').limit(3);
console.log('error:',JSON.stringify(error));
console.log('data:',JSON.stringify(data,null,1));
