import { readFileSync } from 'node:fs';
if (typeof globalThis.WebSocket === 'undefined') globalThis.WebSocket = class { constructor(){throw new Error('x')} close(){} };
import { createClient } from '@supabase/supabase-js';
const env = readFileSync('.env','utf8');
const get=(k)=>{const m=env.match(new RegExp(`^${k}=(.*)$`,'m'));return m?m[1].trim().replace(/^["']|["']$/g,''):undefined;};
const supabase=createClient(get('NEXT_PUBLIC_SUPABASE_URL'),get('SUPABASE_SERVICE_ROLE_KEY'),{auth:{persistSession:false},realtime:{enabled:false}});

const { data: cats } = await supabase.from('nursing_categories').select('id, name, slug, section');
// find duplicate slugs
const bySlug = {};
for (const c of cats) (bySlug[c.slug] ||= []).push(c);
const remap = {}; // oldSlug -> newSlug
for (const [slug, list] of Object.entries(bySlug)) {
  if (list.length > 1) {
    for (const c of list) {
      const ns = `${c.section}-${c.slug}`;
      remap[c.slug] = remap[c.slug] || {};
      remap[c.slug][c.id] = ns;
    }
  }
}
console.log('duplicates to fix:', JSON.stringify(remap, null, 1));
// update categories
for (const c of cats) {
  let ns = c.slug;
  if (bySlug[c.slug]?.length > 1) ns = `${c.section}-${c.slug}`;
  if (ns !== c.slug) {
    await supabase.from('nursing_categories').update({ slug: ns }).eq('id', c.id);
  }
}
// update resources.category where it matches an old slug
const { data: res } = await supabase.from('resources').select('id, category');
let upd = 0;
for (const r of res || []) {
  if (r.category && remap[r.category]) {
    // need to know which section this resource belongs to
    const { data: full } = await supabase.from('resources').select('section').eq('id', r.id).single();
    const ns = remap[r.category][full?.section] || `${full?.section}-${r.category}`;
    if (ns !== r.category) { await supabase.from('resources').update({ category: ns }).eq('id', r.id); upd++; }
  }
}
console.log('resources updated:', upd);
const { data: cats2 } = await supabase.from('nursing_categories').select('slug, section').order('slug');
console.log('remaining dup check:', JSON.stringify(cats2.filter((c,i,a)=>a.findIndex(x=>x.slug===c.slug)!==i)));
