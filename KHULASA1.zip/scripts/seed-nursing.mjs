import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const env = {};
for (const line of fs.readFileSync('.env', 'utf8').split('\n')) {
  const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
  if (m) env[m[1]] = m[2].trim().replace(/^["']|["']$/g, '');
}
const URL = env.NEXT_PUBLIC_SUPABASE_URL || env.VITE_SUPABASE_URL;
const KEY = env.SUPABASE_SERVICE_ROLE_KEY;
const H = { apikey: KEY, Authorization: `Bearer ${KEY}` };
const uid = () => crypto.randomUUID();
const daysAgo = (n) => new Date(Date.now() - n * 86400000).toISOString();

function esc(s) { return String(s).replace(/[\\()]/g, '\\$&'); }
function makePdf(title, lines) {
  const objs = [];
  objs.push('<</Type/Catalog/Pages 2 0 R>>');
  objs.push('<</Type/Pages/Kids[3 0 R]/Count 1>>');
  objs.push('<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<</Font<</F1 5 0 R>>>>/Contents 4 0 R>>');
  let c = `BT /F1 22 Tf 72 720 Td (${esc(title)}) Tj ET\n`;
  let y = 680;
  for (const l of lines) { c += `BT /F1 12 Tf 72 ${y} Td (${esc(l)}) Tj ET\n`; y -= 22; }
  c += `BT /F1 10 Tf 72 90 Td (Al-Khulasa fi Al-Tamrid - Nursing Digital Library) Tj ET\n`;
  objs.push(`<</Length ${Buffer.byteLength(c, 'latin1')}>>\nstream\n${c}endstream`);
  objs.push('<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>');
  let pdf = '%PDF-1.4\n'; const off = [];
  objs.forEach((b, i) => { off.push(Buffer.byteLength(pdf, 'latin1')); pdf += `${i + 1} 0 obj\n${b}\nendobj\n`; });
  const xs = Buffer.byteLength(pdf, 'latin1');
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  off.forEach((o) => { pdf += String(o).padStart(10, '0') + ' 00000 n \n'; });
  pdf += `trailer\n<</Size ${objs.length + 1}/Root 1 0 R>>\nstartxref\n${xs}\n%%EOF`;
  return Buffer.from(pdf, 'latin1');
}
async function up(bucket, key, buf, ct) {
  const r = await fetch(`${URL}/storage/v1/object/${bucket}/${key}`, { method: 'POST', headers: { ...H, 'Content-Type': ct, 'x-upsert': 'true' }, body: buf });
  if (!r.ok) throw new Error(`up ${bucket} ${r.status} ${await r.text()}`);
  return `${URL}/storage/v1/object/public/${bucket}/${key}`;
}
async function ins(table, rows) {
  const r = await fetch(`${URL}/rest/v1/${table}`, { method: 'POST', headers: { ...H, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(rows) });
  if (!r.ok) throw new Error(`ins ${table} ${r.status} ${await r.text()}`);
  return r.json();
}
async function upsert(table, rows) {
  const r = await fetch(`${URL}/rest/v1/${table}`, { method: 'POST', headers: { ...H, 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=representation' }, body: JSON.stringify(rows) });
  if (!r.ok) throw new Error(`upsert ${table} ${r.status} ${await r.text()}`);
  return r.json();
}

async function main() {
  await fetch(`${URL}/rest/v1/resources?id=gt.0`, { method: 'DELETE', headers: H });
  await fetch(`${URL}/rest/v1/nursing_categories?id=gt.0`, { method: 'DELETE', headers: H });
  await fetch(`${URL}/rest/v1/events?id=gt.0`, { method: 'DELETE', headers: H });

  // Categories
  const cats = [
    ['\u0627\u0644\u0641\u0631\u0642\u0629 \u0627\u0644\u0623\u0648\u0644\u0649', 'year-1', 'study', 'GraduationCap'],
    ['\u0627\u0644\u0641\u0631\u0642\u0629 \u0627\u0644\u062b\u0627\u0646\u064a\u0629', 'year-2', 'study', 'GraduationCap'],
    ['\u0627\u0644\u0641\u0631\u0642\u0629 \u0627\u0644\u062b\u0627\u0644\u062b\u0629', 'year-3', 'study', 'GraduationCap'],
    ['\u0627\u0644\u0641\u0631\u0642\u0629 \u0627\u0644\u0631\u0627\u0628\u0639\u0629', 'year-4', 'study', 'GraduationCap'],
    ['\u0643\u062a\u0628 \u0637\u0628\u064a\u0629', 'medical-books', 'books', 'Stethoscope'],
    ['\u0643\u062a\u0628 \u062a\u0645\u0631\u064a\u0636', 'nursing-books', 'books', 'BookOpen'],
    ['\u0627\u0644\u0641\u0627\u0631\u0645\u0627\u0643\u0648\u0644\u0648\u062c\u064a', 'pharmacology', 'books', 'Pill'],
    ['\u0627\u0644\u0639\u0646\u0627\u064a\u0629 \u0627\u0644\u062d\u0631\u062c\u0629', 'critical-care', 'books', 'Activity'],
    ['\u0627\u0644\u0639\u0646\u0627\u064a\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u0629 ICU', 'icu', 'books', 'HeartPulse'],
    ['\u0627\u0644\u0637\u0648\u0627\u0631\u0626', 'emergency', 'books', 'Ambulance'],
    ['\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0637\u0641\u0627\u0644', 'pediatrics', 'books', 'Baby'],
    ['\u0627\u0644\u0628\u0627\u0637\u0646\u0629 \u0648\u0627\u0644\u062c\u0631\u0627\u062d\u0629', 'medical-surgical', 'books', 'ClipboardList'],
    ['\u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0646\u0641\u0633\u064a', 'psychiatric', 'books', 'Brain'],
    ['\u0635\u062d\u0629 \u0627\u0644\u0645\u062c\u062a\u0645\u0639', 'community', 'books', 'Users'],
    ['\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0645\u0648\u0645\u0629', 'maternity', 'books', 'HeartHandshake'],
    ['\u0627\u0644\u062a\u0634\u0631\u064a\u062d', 'anatomy', 'books', 'Bone'],
    ['\u0627\u0644\u0641\u0633\u064a\u0648\u0644\u0648\u062c\u064a', 'physiology', 'books', 'Activity'],
    ['\u0627\u0644\u0628\u0627\u062b\u0648\u0644\u0648\u062c\u064a', 'pathology', 'books', 'Microscope'],
    ['\u0627\u0644\u0625\u0646\u062c\u0644\u064a\u0632\u064a \u0627\u0644\u0637\u0628\u064a', 'medical-english', 'books', 'Languages'],
    ['\u0627\u0646\u062a\u0631\u0641\u064a\u0648 ICU', 'icu-interview', 'interview', 'HeartPulse'],
    ['\u0627\u0646\u062a\u0631\u0641\u064a\u0648 \u0627\u0644\u0637\u0648\u0627\u0631\u0626', 'er-interview', 'interview', 'Ambulance'],
    ['\u063a\u0631\u0641\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a', 'operating-room', 'interview', 'Scissors'],
    ['\u0627\u0644\u063a\u0633\u064a\u0644 \u0627\u0644\u0643\u0644\u0648\u064a', 'dialysis', 'interview', 'Droplet'],
    ['NICU \u062d\u062f\u064a\u062b\u064a \u0627\u0644\u0648\u0644\u0627\u062f\u0629', 'nicu', 'interview', 'Baby'],
    ['PICU \u0623\u0637\u0641\u0627\u0644', 'picu', 'interview', 'Baby'],
    ['\u0627\u0644\u0628\u0627\u0637\u0646\u0629 (Medical Ward)', 'medical-ward', 'interview', 'ClipboardList'],
    ['\u0627\u0644\u062c\u0631\u0627\u062d\u0629 (Surgical Ward)', 'surgical-ward', 'interview', 'Scissors'],
    ['\u0623\u0633\u0626\u0644\u0629 HR', 'hr', 'interview', 'Users'],
    ['\u0623\u0633\u0626\u0644\u0629 \u0633\u0644\u0648\u0643\u064a\u0629', 'behavioral', 'interview', 'MessageCircle'],
    ['\u0633\u064a\u0646\u0627\u0631\u064a\u0648\u0647\u0627\u062a \u0625\u0643\u0644\u064a\u0646\u064a\u0643\u064a\u0629', 'clinical-scenarios', 'interview', 'Activity'],
    ['MCQs', 'mcqs', 'interview', 'ListChecks'],
    ['\u0625\u062c\u0627\u0628\u0627\u062a \u0646\u0645\u0648\u0630\u062c\u064a\u0629', 'answers', 'interview', 'HelpCircle'],
    ['\u0646\u0635\u0627\u0626\u062d', 'tips', 'interview', 'Lightbulb'],
  ];
  await ins('nursing_categories', cats.map((c, i) => ({ name: c[0], slug: c[1], section: c[2], icon: c[3], sort: i })));
  console.log('categories seeded');

  // Covers
  const coverFiles = {
    nurse: 'cover-nurse.jpg', anatomy: 'cover-anatomy.jpg', books: 'cover-books.jpg', icu: 'cover-icu.jpg',
    pharma: 'cover-pharma.jpg', pediatric: 'cover-pediatric.jpg', emergency: 'cover-emergency.jpg',
    study: 'cover-study.jpg', surgery: 'cover-surgery.jpg', cardio: 'cover-cardio.jpg',
  };
  const cover = {};
  for (const [k, fn] of Object.entries(coverFiles)) {
    const p = path.join('public/seed', fn);
    if (fs.existsSync(p)) { const key = `${uid()}.jpg`; cover[k] = { url: await up('covers', key, fs.readFileSync(p), 'image/jpeg'), path: key }; }
  }
  console.log('covers uploaded');

  const S = (k) => cover[k] || null;
  const samples = [
    // STUDY
    { t: '\u0645\u0630\u0643\u0631\u0629 \u0627\u0644\u062a\u0634\u0631\u064a\u062d - \u0627\u0644\u062c\u0647\u0627\u0632 \u0627\u0644\u0647\u064a\u0643\u0644\u064a', sec: 'study', cat: 'year-1', subj: '\u0627\u0644\u062a\u0634\u0631\u064a\u062d', year: '2024/2025', cov: 'anatomy', feat: true, pop: false, dl: 512, d: '\u0645\u0644\u062e\u0635 \u0634\u0627\u0645\u0644 \u0644\u0644\u062c\u0647\u0627\u0632 \u0627\u0644\u0647\u064a\u0643\u0644\u064a \u0648\u0627\u0644\u0639\u0636\u0644\u064a \u0645\u0639 \u0627\u0644\u0631\u0633\u0648\u0645\u0627\u062a \u0627\u0644\u062a\u0648\u0636\u064a\u062d\u064a\u0629.', tags: ['\u062a\u0634\u0631\u064a\u062d', '\u0627\u0644\u0641\u0631\u0642\u0629 \u0627\u0644\u0623\u0648\u0644\u0649'] },
    { t: '\u0623\u0633\u0627\u0633\u064a\u0627\u062a \u0627\u0644\u062a\u0645\u0631\u064a\u0636 (Fundamentals)', sec: 'study', cat: 'year-1', subj: '\u0623\u0633\u0627\u0633\u064a\u0627\u062a \u0627\u0644\u062a\u0645\u0631\u064a\u0636', year: '2024/2025', cov: 'nurse', feat: false, pop: true, dl: 731, d: '\u0645\u0628\u0627\u062f\u0626 \u0627\u0644\u0631\u0639\u0627\u064a\u0629 \u0627\u0644\u062a\u0645\u0631\u064a\u0636\u064a\u0629 \u0648\u0627\u0644\u0639\u0644\u0627\u0645\u0627\u062a \u0627\u0644\u062d\u064a\u0648\u064a\u0629 \u0648\u0645\u0643\u0627\u0641\u062d\u0629 \u0627\u0644\u0639\u062f\u0648\u0649.', tags: ['\u0623\u0633\u0627\u0633\u064a\u0627\u062a'] },
    { t: '\u0645\u062d\u0627\u0636\u0631\u0627\u062a \u0627\u0644\u0641\u0627\u0631\u0645\u0627\u0643\u0648\u0644\u0648\u062c\u064a', sec: 'study', cat: 'year-2', subj: '\u0627\u0644\u0641\u0627\u0631\u0645\u0627\u0643\u0648\u0644\u0648\u062c\u064a', year: '2024/2025', cov: 'pharma', feat: false, pop: true, dl: 604, d: '\u062a\u0635\u0646\u064a\u0641 \u0627\u0644\u0623\u062f\u0648\u064a\u0629 \u0648\u0627\u0644\u062c\u0631\u0639\u0627\u062a \u0648\u0627\u0644\u0622\u062b\u0627\u0631 \u0627\u0644\u062c\u0627\u0646\u0628\u064a\u0629.', tags: ['\u0623\u062f\u0648\u064a\u0629'] },
    { t: '\u0645\u0644\u062e\u0635 \u0627\u0644\u0645\u064a\u0643\u0631\u0648\u0628\u064a\u0648\u0644\u0648\u062c\u064a', sec: 'study', cat: 'year-2', subj: '\u0627\u0644\u0645\u064a\u0643\u0631\u0648\u0628\u064a\u0648\u0644\u0648\u062c\u064a', year: '2024/2025', cov: 'study', feat: false, pop: false, dl: 288, d: '\u0627\u0644\u0628\u0643\u062a\u064a\u0631\u064a\u0627 \u0648\u0627\u0644\u0641\u064a\u0631\u0648\u0633\u0627\u062a \u0648\u0637\u0631\u0642 \u0627\u0644\u0639\u062f\u0648\u0649.', tags: ['\u0645\u064a\u0643\u0631\u0648\u0628\u0627\u062a'] },
    { t: '\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0637\u0641\u0627\u0644 - \u0645\u0644\u062e\u0635', sec: 'study', cat: 'year-3', subj: '\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0637\u0641\u0627\u0644', year: '2024/2025', cov: 'pediatric', feat: true, pop: false, dl: 415, d: '\u0631\u0639\u0627\u064a\u0629 \u0627\u0644\u0637\u0641\u0644 \u0627\u0644\u0633\u0644\u064a\u0645 \u0648\u0627\u0644\u0645\u0631\u064a\u0636 \u0648\u0627\u0644\u062a\u0637\u0639\u064a\u0645\u0627\u062a.', tags: ['\u0623\u0637\u0641\u0627\u0644'] },
    { t: '\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0645\u0648\u0645\u0629 \u0648\u0627\u0644\u0648\u0644\u0627\u062f\u0629', sec: 'study', cat: 'year-3', subj: '\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0645\u0648\u0645\u0629', year: '2024/2025', cov: 'nurse', feat: false, pop: false, dl: 342, d: '\u0645\u062a\u0627\u0628\u0639\u0629 \u0627\u0644\u062d\u0645\u0644 \u0648\u0627\u0644\u0648\u0644\u0627\u062f\u0629 \u0648\u0631\u0639\u0627\u064a\u0629 \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0648\u0644\u0627\u062f\u0629.', tags: ['\u0623\u0645\u0648\u0645\u0629'] },
    { t: '\u0627\u0644\u0639\u0646\u0627\u064a\u0629 \u0627\u0644\u062d\u0631\u062c\u0629 - \u0645\u062d\u0627\u0636\u0631\u0627\u062a', sec: 'study', cat: 'year-4', subj: '\u0627\u0644\u0639\u0646\u0627\u064a\u0629 \u0627\u0644\u062d\u0631\u062c\u0629', year: '2024/2025', cov: 'icu', feat: true, pop: true, dl: 890, d: '\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0645\u0631\u064a\u0636 \u0627\u0644\u062d\u0631\u062c \u0648\u0627\u0644\u0623\u062c\u0647\u0632\u0629 \u0648\u0627\u0644\u0623\u062f\u0648\u064a\u0629 \u0627\u0644\u0637\u0627\u0631\u0626\u0629.', tags: ['ICU', '\u0627\u0644\u0641\u0631\u0642\u0629 \u0627\u0644\u0631\u0627\u0628\u0639\u0629'] },
    { t: '\u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0646\u0641\u0633\u064a - \u0645\u0644\u062e\u0635', sec: 'study', cat: 'year-4', subj: '\u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0646\u0641\u0633\u064a', year: '2024/2025', cov: 'study', feat: false, pop: false, dl: 254, d: '\u0627\u0644\u0627\u0636\u0637\u0631\u0627\u0628\u0627\u062a \u0627\u0644\u0646\u0641\u0633\u064a\u0629 \u0648\u0627\u0644\u062a\u0639\u0627\u0645\u0644 \u0645\u0639 \u0627\u0644\u0645\u0631\u0636\u0649.', tags: ['\u0646\u0641\u0633\u064a'] },
    // BOOKS
    { t: 'Brunner & Suddarth Medical-Surgical Nursing', sec: 'books', cat: 'medical-surgical', author: 'Brunner & Suddarth', edition: '14th Edition', cov: 'books', feat: true, pop: true, dl: 1240, d: '\u0627\u0644\u0645\u0631\u062c\u0639 \u0627\u0644\u0623\u0634\u0647\u0631 \u0641\u064a \u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0628\u0627\u0637\u0646\u0629 \u0648\u0627\u0644\u062c\u0631\u0627\u062d\u0629.', tags: ['Med-Surg'] },
    { t: 'Lippincott Pharmacology', sec: 'books', cat: 'pharmacology', author: 'Karen Whalen', edition: '7th Edition', cov: 'pharma', feat: false, pop: true, dl: 980, d: '\u0645\u0631\u062c\u0639 \u0645\u0635\u0648\u0631 \u0644\u0639\u0644\u0645 \u0627\u0644\u0623\u062f\u0648\u064a\u0629.', tags: ['Pharma'] },
    { t: 'AACN Essentials of Critical Care Nursing', sec: 'books', cat: 'critical-care', author: 'Suzanne Burns', edition: '4th Edition', cov: 'icu', feat: true, pop: false, dl: 560, d: '\u0623\u0633\u0627\u0633\u064a\u0627\u062a \u0627\u0644\u0639\u0646\u0627\u064a\u0629 \u0627\u0644\u062d\u0631\u062c\u0629.', tags: ['Critical Care'] },
    { t: 'Emergency Nursing Core Curriculum', sec: 'books', cat: 'emergency', author: 'ENA', edition: '7th Edition', cov: 'emergency', feat: false, pop: true, dl: 623, d: '\u0645\u0646\u0647\u062c \u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0641\u064a \u0627\u0644\u0637\u0648\u0627\u0631\u0626.', tags: ['ER'] },
    { t: "Wong's Nursing Care of Infants and Children", sec: 'books', cat: 'pediatrics', author: 'Marilyn Hockenberry', edition: '11th Edition', cov: 'pediatric', feat: false, pop: false, dl: 402, d: '\u0645\u0631\u062c\u0639 \u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0623\u0637\u0641\u0627\u0644.', tags: ['Pediatrics'] },
    { t: 'Guyton and Hall Physiology', sec: 'books', cat: 'physiology', author: 'John Hall', edition: '14th Edition', cov: 'cardio', feat: true, pop: true, dl: 1105, d: '\u0623\u0634\u0647\u0631 \u0645\u0631\u0627\u062c\u0639 \u0639\u0644\u0645 \u0648\u0638\u0627\u0626\u0641 \u0627\u0644\u0623\u0639\u0636\u0627\u0621.', tags: ['Physiology'] },
    { t: "Gray's Anatomy for Students", sec: 'books', cat: 'anatomy', author: 'Richard Drake', edition: '4th Edition', cov: 'anatomy', feat: false, pop: false, dl: 715, d: '\u0645\u0631\u062c\u0639 \u0627\u0644\u062a\u0634\u0631\u064a\u062d \u0644\u0644\u0637\u0644\u0627\u0628.', tags: ['Anatomy'] },
    { t: 'Medical English for Nurses', sec: 'books', cat: 'medical-english', author: 'Oxford', edition: '2nd Edition', cov: 'study', feat: false, pop: false, dl: 336, d: '\u0645\u0635\u0637\u0644\u062d\u0627\u062a \u0637\u0628\u064a\u0629 \u0648\u0645\u062d\u0627\u062f\u062b\u0627\u062a \u0644\u0644\u062a\u0645\u0631\u064a\u0636.', tags: ['English'] },
    // INTERVIEW
    { t: '\u0623\u0633\u0626\u0644\u0629 \u0627\u0646\u062a\u0631\u0641\u064a\u0648 \u0627\u0644\u0639\u0646\u0627\u064a\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u0629 ICU', sec: 'interview', cat: 'icu-interview', subj: 'ICU', cov: 'icu', feat: true, pop: true, dl: 1520, d: '\u0623\u0643\u062b\u0631 \u0627\u0644\u0623\u0633\u0626\u0644\u0629 \u0634\u064a\u0648\u0639\u064b\u0627 \u0641\u064a \u0645\u0642\u0627\u0628\u0644\u0627\u062a ICU \u0645\u0639 \u0627\u0644\u0625\u062c\u0627\u0628\u0627\u062a.', tags: ['ICU', 'Interview'] },
    { t: '\u0623\u0633\u0626\u0644\u0629 \u0627\u0646\u062a\u0631\u0641\u064a\u0648 \u0627\u0644\u0637\u0648\u0627\u0631\u0626 ER', sec: 'interview', cat: 'er-interview', subj: 'ER', cov: 'emergency', feat: false, pop: true, dl: 998, d: '\u0623\u0633\u0626\u0644\u0629 \u0642\u0633\u0645 \u0627\u0644\u0637\u0648\u0627\u0631\u0626 \u0648\u0627\u0644\u0641\u0631\u0632 (Triage).', tags: ['ER'] },
    { t: '\u0623\u0633\u0626\u0644\u0629 \u063a\u0631\u0641\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a', sec: 'interview', cat: 'operating-room', subj: 'OR', cov: 'surgery', feat: false, pop: false, dl: 412, d: '\u062f\u0648\u0631 \u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0642\u0628\u0644 \u0648\u0623\u062b\u0646\u0627\u0621 \u0648\u0628\u0639\u062f \u0627\u0644\u062c\u0631\u0627\u062d\u0629.', tags: ['OR'] },
    { t: '\u0623\u0633\u0626\u0644\u0629 HR \u0627\u0644\u0634\u0627\u0626\u0639\u0629 \u0648\u0625\u062c\u0627\u0628\u0627\u062a\u0647\u0627', sec: 'interview', cat: 'hr', subj: 'HR', cov: 'nurse', feat: true, pop: false, dl: 876, d: '\u0623\u0633\u0626\u0644\u0629 \u0627\u0644\u0645\u0648\u0627\u0631\u062f \u0627\u0644\u0628\u0634\u0631\u064a\u0629 \u0648\u0643\u064a\u0641\u064a\u0629 \u0627\u0644\u0625\u062c\u0627\u0628\u0629 \u0628\u0627\u062d\u062a\u0631\u0627\u0641.', tags: ['HR'] },
    { t: '\u0633\u064a\u0646\u0627\u0631\u064a\u0648\u0647\u0627\u062a \u0625\u0643\u0644\u064a\u0646\u064a\u0643\u064a\u0629 \u0648\u062d\u0644\u0648\u0644\u0647\u0627', sec: 'interview', cat: 'clinical-scenarios', subj: 'Clinical', cov: 'cardio', feat: false, pop: true, dl: 734, d: '\u062d\u0627\u0644\u0627\u062a \u0625\u0643\u0644\u064a\u0646\u064a\u0643\u064a\u0629 \u0648\u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062a\u0635\u0631\u0641 \u0627\u0644\u0635\u062d\u064a\u062d.', tags: ['Scenarios'] },
    { t: '\u0646\u0635\u0627\u0626\u062d \u0630\u0647\u0628\u064a\u0629 \u0644\u0644\u0645\u0642\u0627\u0628\u0644\u0629 \u0627\u0644\u0634\u062e\u0635\u064a\u0629', sec: 'interview', cat: 'tips', subj: 'Tips', cov: 'study', feat: false, pop: false, dl: 528, d: '\u0625\u0631\u0634\u0627\u062f\u0627\u062a \u0644\u0644\u0627\u0633\u062a\u0639\u062f\u0627\u062f \u0648\u0644\u063a\u0629 \u0627\u0644\u062c\u0633\u062f \u0648\u0627\u0644\u062b\u0642\u0629.', tags: ['Tips'] },
  ];

  const rows = [];
  let di = 26;
  for (const s of samples) {
    const pdf = makePdf(s.t.replace(/[^\x00-\x7F]/g, '') || 'Nursing Document', [s.subj ? `Subject: ${s.subj}` : `Category: ${s.cat}`, 'Nursing Digital Library sample file.', 'Replace with your real content from the Admin Panel.']);
    const key = `${uid()}.pdf`;
    const fileUrl = await up('files', key, pdf, 'application/pdf');
    const c = S(s.cov);
    rows.push({
      title: s.t, description: s.d, section: s.sec, category: s.cat,
      year: s.year || null, subject: s.subj || null, author: s.author || null, edition: s.edition || null,
      tags: s.tags || [], file_name: `${s.cat}-${di}.pdf`, file_path: key, file_url: fileUrl,
      file_size: pdf.length, file_type: 'application/pdf',
      cover_image_url: c ? c.url : null, cover_path: c ? c.path : null,
      status: 'published', featured: !!s.feat, popular: !!s.pop, download_count: s.dl,
      created_at: daysAgo(di), updated_at: daysAgo(di),
    });
    di -= 1;
  }
  const inserted = await ins('resources', rows);
  console.log(`seeded ${inserted.length} resources`);

  // Analytics events (visits + downloads across 14 days)
  const events = [];
  for (let d = 0; d < 14; d++) {
    const visits = 6 + Math.floor(Math.random() * 22);
    for (let i = 0; i < visits; i++) events.push({ type: 'visit', resource_id: null, path: '/', created_at: daysAgo(d + Math.random() * 0.9) });
    const downloads = 2 + Math.floor(Math.random() * 10);
    for (let i = 0; i < downloads; i++) {
      const r = inserted[Math.floor(Math.random() * inserted.length)];
      events.push({ type: 'download', resource_id: r.id, path: null, created_at: daysAgo(d + Math.random() * 0.9) });
    }
  }
  // batch insert events
  for (let i = 0; i < events.length; i += 200) await ins('events', events.slice(i, i + 200));
  console.log(`seeded ${events.length} events`);

  // Settings
  await upsert('settings', [{
    id: 1,
    data: {
      siteName: '\u0627\u0644\u062e\u0644\u0627\u0635\u0629 \u0641\u064a \u0627\u0644\u062a\u0645\u0631\u064a\u0636',
      tagline: '\u0645\u0643\u062a\u0628\u0629 \u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0627\u0644\u0631\u0642\u0645\u064a\u0629',
      heroTitle: '\u0643\u0644 \u0645\u0627 \u064a\u062d\u062a\u0627\u062c\u0647 \u0637\u0627\u0644\u0628 \u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u0641\u064a \u0645\u0643\u0627\u0646 \u0648\u0627\u062d\u062f',
      heroSubtitle: '\u0645\u0644\u0641\u0627\u062a \u062f\u0631\u0627\u0633\u064a\u0629\u060c \u0648\u0643\u062a\u0628 \u0645\u062a\u062e\u0635\u0635\u0629\u060c \u0648\u0623\u0633\u0626\u0644\u0629 \u0627\u0646\u062a\u0631\u0641\u064a\u0648 \u0644\u0644\u0627\u0645\u062a\u064a\u0627\u0632 \u0648\u0633\u0648\u0642 \u0627\u0644\u0639\u0645\u0644 \u2014 \u062a\u0635\u0641\u0651\u062d \u0648\u062d\u0645\u0651\u0644 \u0645\u062c\u0627\u0646\u064b\u0627.',
      heroCta: '\u0627\u0628\u062f\u0623 \u0627\u0644\u062a\u0635\u0641\u0651\u062d',
      aboutText: '\u0645\u0646\u0635\u0629 \u062a\u0639\u0644\u064a\u0645\u064a\u0629 \u0645\u062c\u0627\u0646\u064a\u0629 \u062a\u062c\u0645\u0639 \u0623\u0641\u0636\u0644 \u0627\u0644\u0645\u0635\u0627\u062f\u0631 \u0644\u0637\u0644\u0627\u0628 \u0648\u062e\u0631\u064a\u062c\u064a \u0627\u0644\u062a\u0645\u0631\u064a\u0636.',
      logoUrl: '', bannerUrl: '',
      telegram: 'https://t.me/', facebook: 'https://facebook.com/', email: 'info@khulasa-nursing.com',
      footerText: '\u0627\u0644\u062e\u0644\u0627\u0635\u0629 \u0641\u064a \u0627\u0644\u062a\u0645\u0631\u064a\u0636 \u2014 \u0645\u0643\u062a\u0628\u0629 \u062a\u0639\u0644\u064a\u0645\u064a\u0629 \u0645\u062c\u0627\u0646\u064a\u0629 \u0644\u062f\u0639\u0645 \u0645\u062c\u062a\u0645\u0639 \u0627\u0644\u062a\u0645\u0631\u064a\u0636.',
    },
    updated_at: new Date().toISOString(),
  }]);
  console.log('settings seeded');
}

main().then(() => { console.log('DONE'); process.exit(0); }).catch((e) => { console.error(e); process.exit(1); });
