import { readFileSync } from 'node:fs';
if (typeof globalThis.WebSocket === 'undefined') globalThis.WebSocket = class { constructor(){throw new Error('x')} close(){} };
import { createClient } from '@supabase/supabase-js';
const env = readFileSync('.env','utf8');
const get=(k)=>{const m=env.match(new RegExp(`^${k}=(.*)$`,'m'));return m?m[1].trim().replace(/^["']|["']$/g,''):undefined;};
const supabase=createClient(get('NEXT_PUBLIC_SUPABASE_URL'),get('SUPABASE_SERVICE_ROLE_KEY'),{auth:{persistSession:false},realtime:{enabled:false}});
try {
  const { error } = await supabase.rpc('exec_sql', { sql: 'ALTER TABLE resources ADD COLUMN IF NOT EXISTS category_slug text;' });
  console.log('rpc exec_sql error:', JSON.stringify(error));
} catch (e) { console.log('rpc not available:', e.message); }
