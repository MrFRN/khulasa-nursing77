import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ---- Load env from .env ----
const env = {};
for (const line of fs.readFileSync('.env', 'utf8').split('\n')) {
  const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
  if (m) env[m[1]] = m[2].trim().replace(/^["']|["']$/g, '');
}
const URL = env.NEXT_PUBLIC_SUPABASE_URL || env.VITE_SUPABASE_URL;
const KEY = env.SUPABASE_SERVICE_ROLE_KEY;
if (!URL || !KEY) { console.error('Missing Supabase env'); process.exit(1); }

const H = { apikey: KEY, Authorization: `Bearer ${KEY}` };

// ---- Minimal valid PDF generator ----
function esc(s) { return String(s).replace(/[\\()]/g, '\\$&'); }
function makePdf(title, lines) {
  const objs = [];
  objs.push('<</Type/Catalog/Pages 2 0 R>>');
  objs.push('<</Type/Pages/Kids[3 0 R]/Count 1>>');
  objs.push('<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<</Font<</F1 5 0 R>>>>/Contents 4 0 R>>');
  let content = `BT /F1 26 Tf 72 720 Td (${esc(title)}) Tj ET\n`;
  let y = 678;
  for (const l of lines) { content += `BT /F1 13 Tf 72 ${y} Td (${esc(l)}) Tj ET\n`; y -= 24; }
  content += `BT /F1 10 Tf 72 90 Td (Generated sample document \u00b7 Filebase library) Tj ET\n`;
  objs.push(`<</Length ${Buffer.byteLength(content, 'latin1')}>>\nstream\n${content}endstream`);
  objs.push('<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>');

  let pdf = '%PDF-1.4\n';
  const offsets = [];
  objs.forEach((body, i) => {
    offsets.push(Buffer.byteLength(pdf, 'latin1'));
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xrefStart = Buffer.byteLength(pdf, 'latin1');
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((o) => { pdf += String(o).padStart(10, '0') + ' 00000 n \n'; });
  pdf += `trailer\n<</Size ${objs.length + 1}/Root 1 0 R>>\nstartxref\n${xrefStart}\n%%EOF`;
  return Buffer.from(pdf, 'latin1');
}

async function uploadStorage(bucket, key, buffer, contentType) {
  const res = await fetch(`${URL}/storage/v1/object/${bucket}/${key}`, {
    method: 'POST',
    headers: { ...H, 'Content-Type': contentType, 'x-upsert': 'true' },
    body: buffer,
  });
  if (!res.ok) throw new Error(`upload ${bucket}/${key} failed: ${res.status} ${await res.text()}`);
  return `${URL}/storage/v1/object/public/${bucket}/${key}`;
}

async function insert(table, rows) {
  const res = await fetch(`${URL}/rest/v1/${table}`, {
    method: 'POST',
    headers: { ...H, 'Content-Type': 'application/json', Prefer: 'return=representation' },
    body: JSON.stringify(rows),
  });
  if (!res.ok) throw new Error(`insert ${table} failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const uid = () => crypto.randomUUID();
const daysAgo = (n) => new Date(Date.now() - n * 86400000).toISOString();
const daysAhead = (n) => new Date(Date.now() + n * 86400000).toISOString();

async function main() {
  // Clear existing (idempotent reseed)
  await fetch(`${URL}/rest/v1/files?id=gt.0`, { method: 'DELETE', headers: H });
  await fetch(`${URL}/rest/v1/categories?id=gt.0`, { method: 'DELETE', headers: H });

  // ---- Categories ----
  const tops = await insert('categories', [
    { name: 'Lecture Notes', parent_id: null },
    { name: 'Past Papers', parent_id: null },
    { name: 'Textbooks', parent_id: null },
    { name: 'Worksheets', parent_id: null },
    { name: 'Presentations', parent_id: null },
  ]);
  const byName = Object.fromEntries(tops.map((c) => [c.name, c.id]));
  await insert('categories', [
    { name: 'Mathematics', parent_id: byName['Lecture Notes'] },
    { name: 'Physics', parent_id: byName['Lecture Notes'] },
    { name: 'Chemistry', parent_id: byName['Lecture Notes'] },
    { name: 'Biology', parent_id: byName['Lecture Notes'] },
    { name: '2023', parent_id: byName['Past Papers'] },
    { name: '2024', parent_id: byName['Past Papers'] },
  ]);
  console.log('categories seeded');

  // ---- Cover images upload ----
  const coverMap = {};
  const coverFiles = {
    math: 'cover-math.jpg', chem: 'cover-chem.jpg', physics: 'cover-physics.jpg',
    bio: 'cover-bio.jpg', stats: 'cover-stats.jpg', history: 'cover-history.jpg',
  };
  for (const [k, fname] of Object.entries(coverFiles)) {
    const p = path.join('public/seed', fname);
    if (fs.existsSync(p)) {
      const key = `${uid()}.jpg`;
      coverMap[k] = { url: await uploadStorage('covers', key, fs.readFileSync(p), 'image/jpeg'), path: key };
    }
  }
  console.log('covers uploaded');

  // ---- Sample files ----
  const samples = [
    {
      title: 'Calculus I \u2014 Complete Lecture Notes', fname: 'calculus-i-notes.pdf',
      description: 'A full set of lecture notes covering limits, derivatives, and the fundamental theorem of calculus with worked examples.',
      category: 'Lecture Notes', subcategory: 'Mathematics', subject: 'Mathematics', year: '2024\u20132025',
      tags: ['calculus', 'derivatives', 'limits', 'notes'], cover: 'math',
      status: 'published', featured: true, popular: false, downloads: 342, created: daysAgo(12),
      lines: ['Chapter 1 \u2014 Limits and continuity', 'Chapter 2 \u2014 The derivative', 'Chapter 3 \u2014 Rules of differentiation', 'Chapter 4 \u2014 Applications of derivatives', 'Chapter 5 \u2014 The definite integral'],
    },
    {
      title: 'Organic Chemistry Reaction Guide', fname: 'organic-chemistry-reactions.pdf',
      description: 'Quick-reference guide to the most common organic reaction mechanisms, arranged by functional group.',
      category: 'Lecture Notes', subcategory: 'Chemistry', subject: 'Chemistry', year: '2024\u20132025',
      tags: ['organic', 'reactions', 'mechanisms'], cover: 'chem',
      status: 'published', featured: false, popular: true, downloads: 517, created: daysAgo(9),
      lines: ['Substitution reactions (SN1 / SN2)', 'Elimination reactions (E1 / E2)', 'Addition to alkenes and alkynes', 'Aromatic substitution', 'Carbonyl chemistry'],
    },
    {
      title: 'Physics Past Paper 2024 (with solutions)', fname: 'physics-past-paper-2024.pdf',
      description: 'The 2024 final examination paper for introductory physics, complete with a full worked solution set.',
      category: 'Past Papers', subcategory: '2024', subject: 'Physics', year: '2023\u20132024',
      tags: ['exam', 'past paper', 'solutions', 'mechanics'], cover: 'physics',
      status: 'published', featured: false, popular: true, downloads: 689, created: daysAgo(6),
      lines: ['Section A \u2014 Mechanics', 'Section B \u2014 Thermodynamics', 'Section C \u2014 Waves and optics', 'Section D \u2014 Electromagnetism', 'Full marking scheme included'],
    },
    {
      title: 'Cell Biology Study Guide', fname: 'cell-biology-study-guide.pdf',
      description: 'Condensed study guide on cell structure, the cell cycle, and cellular respiration for exam revision.',
      category: 'Lecture Notes', subcategory: 'Biology', subject: 'Biology', year: '2024\u20132025',
      tags: ['cells', 'revision', 'study guide'], cover: 'bio',
      status: 'published', featured: true, popular: false, downloads: 205, created: daysAgo(4),
      lines: ['The cell membrane and transport', 'Organelles and their functions', 'The cell cycle and mitosis', 'Cellular respiration', 'Photosynthesis overview'],
    },
    {
      title: 'Linear Algebra Workbook', fname: 'linear-algebra-workbook.pdf',
      description: 'Practice problems and solutions covering vectors, matrices, and linear transformations.',
      category: 'Worksheets', subcategory: '', subject: 'Mathematics', year: '2024\u20132025',
      tags: ['linear algebra', 'matrices', 'practice'], cover: null,
      status: 'published', featured: false, popular: false, downloads: 128, created: daysAgo(3),
      lines: ['Set 1 \u2014 Vectors and vector spaces', 'Set 2 \u2014 Matrix operations', 'Set 3 \u2014 Determinants', 'Set 4 \u2014 Eigenvalues and eigenvectors'],
    },
    {
      title: 'Introduction to Statistics', fname: 'introduction-to-statistics.pdf',
      description: 'An accessible textbook introducing descriptive statistics, probability, and inference.',
      category: 'Textbooks', subcategory: '', subject: 'Statistics', year: '2024\u20132025',
      tags: ['statistics', 'probability', 'textbook'], cover: 'stats',
      status: 'published', featured: true, popular: false, downloads: 431, created: daysAgo(2),
      lines: ['Part I \u2014 Describing data', 'Part II \u2014 Probability', 'Part III \u2014 Sampling distributions', 'Part IV \u2014 Confidence intervals', 'Part V \u2014 Hypothesis testing'],
    },
    {
      title: 'Thermodynamics Summary Sheet', fname: 'thermodynamics-summary.pdf',
      description: 'A single-page summary of the laws of thermodynamics and key equations. Draft \u2014 not yet published.',
      category: 'Lecture Notes', subcategory: 'Physics', subject: 'Physics', year: '2024\u20132025',
      tags: ['thermodynamics', 'summary', 'physics'], cover: null,
      status: 'draft', featured: false, popular: false, downloads: 0, created: daysAgo(1),
      lines: ['Zeroth law \u2014 thermal equilibrium', 'First law \u2014 conservation of energy', 'Second law \u2014 entropy', 'Third law \u2014 absolute zero'],
    },
    {
      title: 'World History Timeline Presentation', fname: 'world-history-timeline.pdf',
      description: 'A visual timeline presentation of major world events. Scheduled to publish next week.',
      category: 'Presentations', subcategory: '', subject: 'History', year: '2024\u20132025',
      tags: ['history', 'timeline', 'presentation'], cover: 'history',
      status: 'scheduled', featured: false, popular: false, downloads: 0, created: daysAgo(0),
      scheduled_at: daysAhead(7),
      lines: ['Ancient civilizations', 'The classical era', 'The middle ages', 'The age of exploration', 'The modern world'],
    },
  ];

  const rows = [];
  for (const s of samples) {
    const pdf = makePdf(s.title, s.lines);
    const key = `${uid()}.pdf`;
    const fileUrl = await uploadStorage('files', key, pdf, 'application/pdf');
    const cover = s.cover ? coverMap[s.cover] : null;
    rows.push({
      title: s.title,
      description: s.description,
      category: s.category || null,
      subcategory: s.subcategory || null,
      subject: s.subject || null,
      academic_year: s.year || null,
      tags: s.tags,
      file_name: s.fname,
      file_path: key,
      file_url: fileUrl,
      file_size: pdf.length,
      file_type: 'application/pdf',
      cover_image_url: cover ? cover.url : null,
      cover_path: cover ? cover.path : null,
      status: s.status,
      featured: s.featured,
      popular: s.popular,
      download_count: s.downloads,
      scheduled_at: s.scheduled_at || null,
      created_at: s.created,
      updated_at: s.created,
    });
  }
  await insert('files', rows);
  console.log(`seeded ${rows.length} files`);
}

main().then(() => { console.log('DONE'); process.exit(0); }).catch((e) => { console.error(e); process.exit(1); });
