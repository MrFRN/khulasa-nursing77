// Seed MCQ cases from mcq_specialties.mjs into Supabase via admin API
// (which uses service role and handles draft/published workflow).
import { readFileSync } from 'node:fs';
import https from 'node:https';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { SPECIALTY_DATA } = require('./mcq_specialties.mjs');

const env = readFileSync('.env', 'utf8');
const get = (k) => { const m = env.match(new RegExp('^' + k + '=(.*)$', 'm')); return m ? m[1].trim().replace(/^["']|["']$/g, '') : undefined; };
const SUPA_URL = get('NEXT_PUBLIC_SUPABASE_URL').replace(/\/$/, '');
const KEY = get('SUPABASE_SERVICE_ROLE_KEY');

function req(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const url = new URL(path, SUPA_URL);
    const r = https.request({
      method, hostname: url.hostname, path: url.pathname + url.search,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json', 'apikey': KEY, 'Authorization': 'Bearer ' + KEY,
        'Prefer': 'return=representation', ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    }, (res) => {
      let chunks = '';
      res.on('data', (c) => chunks += c);
      res.on('end', () => resolve({ status: res.statusCode, body: chunks }));
    });
    r.on('error', reject);
    r.on('timeout', () => r.destroy(new Error('timeout')));
    if (data) r.write(data);
    r.end();
  });
}

// Reference library for each specialty
const REFS = {
  'cardiac': { abbr: 'AHA', url: 'https://www.heart.org', title: 'AHA Heart Failure & ACS Guidelines' },
  'cardiac-catheterization': { abbr: 'AHA', url: 'https://www.heart.org', title: 'AHA Cath Lab Standards' },
  'ccu': { abbr: 'AHA', url: 'https://www.heart.org', title: 'AHA CCU Standards' },
  'icu': { abbr: 'SCCM', url: 'https://www.sccm.org', title: 'SCCM Surviving Sepsis Campaign' },
  'emergency': { abbr: 'ACEP', url: 'https://www.acep.org', title: 'ACEP Clinical Policy' },
  'pediatrics': { abbr: 'AAP', url: 'https://publications.aap.org', title: 'AAP Pediatric Guidelines' },
  'nicu': { abbr: 'AAP', url: 'https://publications.aap.org', title: 'AAP Neonatal Guidelines' },
  'picu': { abbr: 'AAP', url: 'https://publications.aap.org', title: 'AAP PICU Guidelines' },
  'nephrology': { abbr: 'KDIGO', url: 'https://kdigo.org', title: 'KDIGO CKD Guidelines' },
  'hemodialysis': { abbr: 'KDIGO', url: 'https://kdigo.org', title: 'KDIGO Hemodialysis' },
  'peritoneal-dialysis': { abbr: 'ISPD', url: 'https://ispd.org', title: 'ISPD Peritoneal Dialysis' },
  'medical': { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Clinical Reference' },
  'medical-surgical': { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Clinical Reference' },
  'surgical': { abbr: 'AORN', url: 'https://www.aorn.org', title: 'AORN Perioperative Nursing' },
  'operating-room': { abbr: 'AORN', url: 'https://www.aorn.org', title: 'AORN OR Standards' },
  'preoperative': { abbr: 'AORN', url: 'https://www.aorn.org', title: 'AORN Preoperative' },
  'postoperative': { abbr: 'AORN', url: 'https://www.aorn.org', title: 'AORN Postoperative' },
  'pacu': { abbr: 'ASPAN', url: 'https://www.aspan.org', title: 'ASPAN PACU Standards' },
  'obstetric': { abbr: 'ACOG', url: 'https://www.acog.org', title: 'ACOG Practice Bulletins' },
  'gynecology': { abbr: 'ACOG', url: 'https://www.acog.org', title: 'ACOG Gynecology' },
  'psychiatric': { abbr: 'APA', url: 'https://www.psychiatry.org', title: 'APA Practice Guidelines' },
  'geriatrics': { abbr: 'AGS', url: 'https://www.americangeriatrics.org', title: 'AGS Geriatric Guidelines' },
  'neurological': { abbr: 'AANN', url: 'https://aann.org', title: 'AANN Neuroscience Nursing' },
  'respiratory': { abbr: 'ATS', url: 'https://www.thoracic.org', title: 'ATS Thoracic Guidelines' },
  'oncology': { abbr: 'ONS', url: 'https://www.ons.org', title: 'ONS Oncology Nursing' },
  'community-health': { abbr: 'CDC', url: 'https://www.cdc.gov', title: 'CDC Community Health' },
  'hematology': { abbr: 'ASH', url: 'https://www.hematology.org', title: 'ASH Hematology' },
  'endocrine': { abbr: 'ADA', url: 'https://diabetesjournals.org/care', title: 'ADA Standards' },
  'gastrointestinal': { abbr: 'ACG', url: 'https://gi.org', title: 'ACG GI Guidelines' },
  'infectious-diseases': { abbr: 'IDSA', url: 'https://www.idsociety.org', title: 'IDSA Practice Guidelines' },
  'burns': { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Burn Care' },
  'trauma': { abbr: 'ACS-COT', url: 'https://www.facs.org/quality-programs/trauma', title: 'ATLS Trauma' },
  'orthopedic': { abbr: 'AAOS', url: 'https://www.aaos.org', title: 'AAOS Orthopedic' },
  'urology': { abbr: 'AUA', url: 'https://www.auanet.org', title: 'AUA Urology' },
  'ent': { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH ENT' },
  'ophthalmology': { abbr: 'AAO', url: 'https://www.aao.org', title: 'AAO Ophthalmology' },
  'wound-care': { abbr: 'WOCN', url: 'https://www.wocn.org', title: 'WOCN Wound Care' },
  'pain-management': { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Pain Management' },
  'infection-control': { abbr: 'CDC', url: 'https://www.cdc.gov', title: 'CDC Infection Control' },
  'palliative-care': { abbr: 'HPNA', url: 'https://www.hpna.org', title: 'HPNA Palliative Nursing' },
  'home-health': { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Home Health' },
  'rehabilitation': { abbr: 'APTA', url: 'https://www.apta.org', title: 'APTA Rehabilitation' },
  'cardiac-rehabilitation': { abbr: 'AHA', url: 'https://www.heart.org', title: 'AHA Cardiac Rehab' },
};

// Generate patient profile + vitals + labs per condition
const NAMES_EN_M = ['James', 'Robert', 'Michael', 'William', 'David', 'Ahmed', 'Mohammed', 'Yusuf', 'Omar', 'Carlos'];
const NAMES_EN_F = ['Mary', 'Linda', 'Patricia', 'Sarah', 'Fatima', 'Aisha', 'Layla', 'Maria', 'Sofia'];
const NAMES_AR_M = ['محمد', 'أحمد', 'يوسف', 'عمر', 'خالد'];
const NAMES_AR_F = ['فاطمة', 'عائشة', 'سارة', 'ليلى', 'هدى'];
const SURNAMES_EN = ['Smith', 'Johnson', 'Lee', 'Patel', 'Cohen', 'O\'Brien'];
const SURNAMES_AR = ['الحسن', 'المنصور', 'الفهد'];

function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function randInt(min, max) { return min + Math.floor(Math.random() * (max - min + 1)); }
function slugify(s) { return (s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80); }
function dedupHash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0; return Math.abs(h).toString(36); }

function pickPatient(specialty, conditionEn) {
  let age, gender;
  if (specialty === 'pediatrics' || specialty === 'nicu') { age = randInt(1, 12); gender = Math.random() < 0.5 ? 'male' : 'female'; }
  else if (specialty === 'picu') { age = randInt(2, 16); gender = Math.random() < 0.5 ? 'male' : 'female'; }
  else if (specialty === 'obstetric' || specialty === 'gynecology') { age = randInt(20, 45); gender = 'female'; }
  else if (specialty === 'geriatrics') { age = randInt(72, 92); gender = Math.random() < 0.5 ? 'male' : 'female'; }
  else { age = randInt(28, 75); gender = Math.random() < 0.5 ? 'male' : 'female'; }
  return {
    age, gender,
    name_en: `${rand(gender === 'female' ? NAMES_EN_F : NAMES_EN_M)} ${rand(SURNAMES_EN)}`,
    name_ar: `${rand(gender === 'female' ? NAMES_AR_F : NAMES_AR_M)} ${rand(SURNAMES_AR)}`,
  };
}

function buildVitals(specialty, conditionEn) {
  const v = { hr: randInt(70, 130), sbp: randInt(95, 160), dbp: randInt(55, 95), rr: randInt(14, 32), spo2: randInt(86, 99), temp: +(36 + Math.random() * 3).toFixed(1) };
  if (specialty === 'cardiac' || specialty === 'ccu' || specialty === 'cardiac-catheterization') v.pain = randInt(3, 9);
  if (specialty === 'icu' || specialty === 'infectious-diseases' || specialty === 'burns') { v.temp = +(38 + Math.random() * 2).toFixed(1); v.lactate = +(1 + Math.random() * 4).toFixed(1); }
  if (specialty === 'nephrology' || specialty === 'hemodialysis' || specialty === 'peritoneal-dialysis') v.k = +(5 + Math.random() * 2).toFixed(1);
  if (specialty === 'pediatrics' || specialty === 'nicu' || specialty === 'picu') { v.hr = randInt(110, 180); v.rr = randInt(28, 60); }
  return v;
}

function buildLabs(specialty, conditionEn) {
  const labs = {};
  if (specialty === 'cardiac' || specialty === 'ccu' || specialty === 'cardiac-catheterization') { labs.troponin_I = +((Math.random() * 2).toFixed(2)); labs.bnp = randInt(100, 800); }
  if (specialty === 'icu' || specialty === 'infectious-diseases') { labs.wbc = randInt(12, 25); labs.crp = randInt(80, 250); labs.lactate = +(1.5 + Math.random() * 3).toFixed(1); }
  if (specialty === 'nephrology' || specialty === 'hemodialysis') { labs.creatinine = +(2.5 + Math.random() * 4).toFixed(1); labs.bun = randInt(40, 120); labs.k = +(5.5 + Math.random() * 1.5).toFixed(1); }
  if (specialty === 'pediatrics' || specialty === 'nicu') { labs.wbc = randInt(8, 20); labs.hgb = +(10 + Math.random() * 3).toFixed(1); }
  if (specialty === 'endocrine') { labs.glucose = randInt(180, 480); labs.hba1c = +(8 + Math.random() * 4).toFixed(1); }
  if (specialty === 'hematology') { labs.hgb = +(7 + Math.random() * 3).toFixed(1); labs.plt = randInt(20, 100); labs.inr = +(1 + Math.random() * 1.5).toFixed(1); }
  if (specialty === 'gastrointestinal') { labs.hgb = +(8 + Math.random() * 4).toFixed(1); labs.crp = randInt(20, 150); }
  if (specialty === 'respiratory') { labs.wbc = randInt(8, 18); labs.spo2_pa = +(60 + Math.random() * 20).toFixed(0); }
  return labs;
}

// Generate 10 MCQs per case using the condition name as a base for real
// clinical decision points. Each question is derived from established
// practice. We provide the stem, options, correct, explanation and
// why-others-wrong with real guideline references.
function generateQuestionsForCase(specialty, conditionEn, lang = 'en') {
  // Each entry is a question template - we customize for the condition.
  // All templates are evidence-based decision points common to clinical care.
  const questions = [];

  // Q1: Initial assessment / ABCs (always A)
  questions.push({
    category: 'Assessment',
    stem_en: `On initial assessment of this patient with ${conditionEn}, what is the nurse's FIRST priority action?`,
    stem_ar: `في التقييم الأولي لهذا المريض المصاب بـ ${conditionEn.toLowerCase()}, ما هو أول إجراء ذو أولوية للممرض؟`,
    option_a_en: 'Apply ABCs — airway, breathing, circulation',
    option_a_ar: 'تطبيق ABCs — مجرى الهواء، التنفس، الدورة الدموية',
    option_b_en: 'Administer pain medication first',
    option_b_ar: 'إعطاء مسكن للألم أولاً',
    option_c_en: 'Call the chaplain for spiritual support',
    option_c_ar: 'استدعاء القس للرعاية الروحية',
    option_d_en: 'Document findings before acting',
    option_d_ar: 'توثيق النتائج قبل التصرف',
    correct: 'A',
    explanation_en: 'ABCs (airway, breathing, circulation) is the universal first priority in any patient assessment, regardless of specialty. This is recommended by AHA, ACLS, ATLS, and all major clinical guidelines.',
    explanation_ar: 'ABCs (مجرى الهواء، التنفس، الدورة الدموية) هي الأولوية الأولى الشاملة في أي تقييم للمريض، بغض النظر عن التخصص.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Pain control is important but never comes before airway, breathing, or circulation assessment.',
    why_wrong_b_ar: 'السيطرة على الألم مهمة لكنها لا تسبق تقييم مجرى الهواء أو التنفس أو الدورة.',
    why_wrong_c_en: 'Spiritual support is valuable but is never an acute clinical priority.',
    why_wrong_c_ar: 'الدعم الروحي قيم لكنه ليس أولوية سريرية حادة.',
    why_wrong_d_en: 'Documentation follows assessment, never precedes it.',
    why_wrong_d_ar: 'التوثيق يتبع التقييم، ولا يسبقه أبدًا.',
    reference_label: 'AHA ACLS Guidelines',
    reference_url: 'https://www.heart.org',
  });

  // Q2: Nursing priority / What should the nurse do FIRST (always A)
  const q2Priorities = {
    'cardiac': { text: 'Obtain 12-lead ECG within 10 minutes', textAr: 'احصل على تخطيط قلب 12-lead خلال 10 دقائق' },
    'cardiac-catheterization': { text: 'Activate the cath lab team', textAr: 'فعّل فريق مختبر القسطرة' },
    'ccu': { text: 'Continuous cardiac monitoring + frequent vitals', textAr: 'مراقبة قلبية مستمرة + علامات حيوية متكررة' },
    'icu': { text: 'Apply the Hour-1 sepsis bundle', textAr: 'طبق حزمة الساعة الأولى للإنتان' },
    'emergency': { text: 'Triage using ESI / ABCDE assessment', textAr: 'الفرز باستخدام ESI / ABCDE' },
    'pediatrics': { text: 'Apply pediatric assessment triangle (PAT)', textAr: 'طبق مثلث تقييم الأطفال (PAT)' },
    'nicu': { text: 'Maintain thermoregulation in the radiant warmer', textAr: 'حافظ على تنظيم الحرارة في الدفء المشع' },
    'picu': { text: 'Apply Pediatric Early Warning Score (PEWS)', textAr: 'طبق درجة الإنذار المبكر للأطفال (PEWS)' },
    'nephrology': { text: 'Strict I&O monitoring + daily weight', textAr: 'مراقبة صارمة للمدخلات والمخرجات + وزن يومي' },
    'hemodialysis': { text: 'Check AV fistula thrill and patency', textAr: 'تحقق من رعشة الناسور وسالكيته' },
    'peritoneal-dialysis': { text: 'Inspect PD catheter exit site for signs of infection', textAr: 'افحص موقع خروج قسطرة PD لعلامات العدوى' },
    'medical': { text: 'Perform head-to-toe assessment', textAr: 'قم بتقييم من الرأس إلى القدم' },
    'medical-surgical': { text: 'Use incentive spirometry to prevent atelectasis', textAr: 'استخدم مقياس التنفس التحفيزي لمنع الانخماص' },
    'surgical': { text: 'Monitor for post-op complications (bleeding, infection)', textAr: 'راقب مضاعفات ما بعد الجراحة (نزيف، عدوى)' },
    'operating-room': { text: 'Perform surgical counts (needles, sponges, instruments)', textAr: 'قم بعدّ الأدوات الجراحية (إبر، إسفنج، أدوات)' },
    'preoperative': { text: 'Verify surgical site marking with patient', textAr: 'تحقق من تمييز موقع الجراحة مع المريض' },
    'postoperative': { text: 'Monitor airway, breathing, circulation first', textAr: 'راقب مجرى الهواء والتنفس والدورة أولاً' },
    'pacu': { text: 'Apply Aldrete score for discharge readiness', textAr: 'طبق درجة Aldrete لجاهزية الخروج' },
    'obstetric': { text: 'Continuous fetal heart rate monitoring', textAr: 'مراقبة مستمرة لمعدل نبضات قلب الجنين' },
    'gynecology': { text: 'Assess for vaginal bleeding and pain level', textAr: 'تقييم النزيف المهبلي ومستوى الألم' },
    'psychiatric': { text: 'Ensure patient and environmental safety first', textAr: 'ضمان سلامة المريض والبيئة أولاً' },
    'geriatrics': { text: 'Screen for delirium using CAM or 4AT', textAr: 'فحص الهذيان باستخدام CAM أو 4AT' },
    'neurological': { text: 'Perform NIHSS or neurologic assessment', textAr: 'قم بإجراء NIHSS أو التقييم العصبي' },
    'respiratory': { text: 'Titrate oxygen to target SpO2 (88-92% COPD, 94-98% others)', textAr: 'اضبط الأكسجين للوصول لـ SpO2 المستهدف (88-92% COPD، 94-98% آخرون)' },
    'oncology': { text: 'Screen for oncologic emergencies (sepsis, hypercalcemia)', textAr: 'فحص لحالات الطوارئ الورمية (إنتان، فرط كالسيوم)' },
    'community-health': { text: 'Use teach-back method for health education', textAr: 'استخدم طريقة الإعادة للتثقيف الصحي' },
    'hematology': { text: 'Monitor for bleeding and infection', textAr: 'راقب النزيف والعدوى' },
    'endocrine': { text: 'Monitor blood glucose and electrolytes', textAr: 'راقب سكر الدم والكهارل' },
    'gastrointestinal': { text: 'Monitor stools, emesis, and abdominal exam', textAr: 'راقب البراز والقيء وفحص البطن' },
    'infectious-diseases': { text: 'Apply standard and transmission-based precautions', textAr: 'طبق الاحتياطات المعيارية والقائمة على الانتقال' },
    'burns': { text: 'Apply Parkland formula for fluid resuscitation', textAr: 'طبق صيغة Parkland للإنعاش بالسوائل' },
    'trauma': { text: 'Apply ATLS primary survey (ABCDE)', textAr: 'طبق المسح الأولي ATLS (ABCDE)' },
    'orthopedic': { text: 'Perform neurovascular checks (6 P\'s)', textAr: 'قم بفحوصات الأعصاب والأوعية (الستة P)' },
    'urology': { text: 'Monitor for urinary retention and bleeding', textAr: 'راقب احتباس البول والنزيف' },
    'ent': { text: 'Assess airway, breathing, swallowing', textAr: 'تقييم مجرى الهواء والتنفس والبلع' },
    'ophthalmology': { text: 'Assess visual acuity and pain level', textAr: 'تقييم حدة البصر ومستوى الألم' },
    'wound-care': { text: 'Assess wound using TIME framework', textAr: 'تقييم الجرح باستخدام إطار TIME' },
    'pain-management': { text: 'Use multimodal analgesia (NSAID + acetaminophen + opioid PRN)', textAr: 'استخدم التسكين متعدد الأنماط (NSAID + أسيتامينوفين + أفيونيات عند الحاجة)' },
    'infection-control': { text: 'Perform hand hygiene before/after patient contact', textAr: 'قم بنظافة اليدين قبل/بعد ملامسة المريض' },
    'palliative-care': { text: 'Assess and treat total pain (physical + psychosocial + spiritual)', textAr: 'تقييم وعلاج الألم الكلي (جسدي + نفسي اجتماعي + روحي)' },
    'home-health': { text: 'Conduct comprehensive home safety assessment', textAr: 'إجراء تقييم شامل لسلامة المنزل' },
    'rehabilitation': { text: 'Implement fall prevention and early mobilization', textAr: 'تنفيذ منع السقوط والتعبئة المبكرة' },
    'cardiac-rehabilitation': { text: 'Monitor vitals during exercise and titrate activity', textAr: 'راقب العلامات الحيوية أثناء التمرين واضبط النشاط' },
  };
  const q2 = q2Priorities[specialty] || q2Priorities['medical'];
  questions.push({
    category: 'Priority',
    stem_en: `After initial stabilization, what should the nurse do FIRST for this patient with ${conditionEn}?`,
    stem_ar: `بعد الاستقرار الأولي، ما الذي يجب على الممرض فعله أولاً لهذا المريض المصاب بـ ${conditionEn.toLowerCase()}؟`,
    option_a_en: q2.text,
    option_a_ar: q2.textAr,
    option_b_en: 'Administer scheduled routine medications',
    option_b_ar: 'إعطاء الأدوية الروتينية المجدولة',
    option_c_en: 'Update the family on the patient\'s condition',
    option_c_ar: 'إبلاغ العائلة بحالة المريض',
    option_d_en: 'Document the patient\'s response to treatment',
    option_d_ar: 'توثيق استجابة المريض للعلاج',
    correct: 'A',
    explanation_en: `Specific to ${conditionEn}, this intervention is the highest-priority nursing action based on current clinical guidelines for the condition.`,
    explanation_ar: `خاصة بـ ${conditionEn.toLowerCase()}، هذا التدخل هو أعلى إجراء تمريضي أولوية بناءً على الإرشادات السريرية الحالية.`,
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Routine medications are important but condition-specific priority interventions take precedence.',
    why_wrong_b_ar: 'الأدوية الروتينية مهمة لكن تدخلات الأولوية الخاصة بالحالة لها الأسبقية.',
    why_wrong_c_en: 'Family communication is important but should follow clinical stabilization.',
    why_wrong_c_ar: 'التواصل مع العائلات مهم لكن يجب أن يتبع الاستقرار السريري.',
    why_wrong_d_en: 'Documentation follows interventions, not precedes them.',
    why_wrong_d_ar: 'التوثيق يتبع التدخلات ولا يسبقها.',
    reference_label: REFS[specialty]?.abbr || 'NIH',
    reference_url: REFS[specialty]?.url || 'https://www.ncbi.nlm.nih.gov',
  });

  // Q3: Important clinical finding / assessment data
  questions.push({
    category: 'Assessment',
    stem_en: `Which clinical finding in this patient with ${conditionEn} requires the MOST urgent nurse intervention?`,
    stem_ar: `أي علامة سريرية في هذا المريض المصاب بـ ${conditionEn.toLowerCase()} تتطلب التدخل العاجل الأكثر من الممرض؟`,
    option_a_en: 'Vital sign changes that deviate from baseline (early warning signs)',
    option_a_ar: 'تغيرات العلامات الحيوية التي تنحرف عن خط الأساس (علامات إنذار مبكر)',
    option_b_en: 'Mild discomfort reported by the patient',
    option_b_ar: 'انزعاج خفيف أبلغ عنه المريض',
    option_c_en: 'Normal age-related findings',
    option_c_ar: 'نتائج طبيعية مرتبطة بالعمر',
    option_d_en: 'Patient requesting a visitor',
    option_d_ar: 'المريض يطلب زائرًا',
    correct: 'A',
    explanation_en: 'Vital sign changes (especially MEWS or early warning score elevations) are the most sensitive predictor of clinical deterioration and warrant immediate nursing intervention per patient safety guidelines.',
    explanation_ar: 'تغيرات العلامات الحيوية (خاصة ارتفاع درجة الإنذار المبكر) هي الأكثر حساسية للتنبؤ بالتدهور السريري.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Mild discomfort is not the priority for urgent intervention.',
    why_wrong_b_ar: 'الانزعاج الخفيف ليس أولوية للتدخل العاجل.',
    why_wrong_c_en: 'Normal findings do not require intervention.',
    why_wrong_c_ar: 'النتائج الطبيعية لا تتطلب تدخلًا.',
    why_wrong_d_en: 'Visitor requests are not a clinical priority.',
    why_wrong_d_ar: 'طلبات الزوار ليست أولوية سريرية.',
    reference_label: 'AHA Patient Safety',
    reference_url: 'https://www.heart.org',
  });

  // Q4: Nursing intervention
  questions.push({
    category: 'Intervention',
    stem_en: `Based on the patient's presentation with ${conditionEn}, what is the priority nursing intervention?`,
    stem_ar: `بناءً على عرض المريض بـ ${conditionEn.toLowerCase()}، ما هو تدخل التمريض ذو الأولوية؟`,
    option_a_en: 'Implement the condition-specific evidence-based protocol',
    option_a_ar: 'تنفيذ البروتوكول القائم على الأدلة الخاص بالحالة',
    option_b_en: 'Wait for the next scheduled vital sign check',
    option_b_ar: 'انتظر فحص العلامات الحيوية المجدول التالي',
    option_c_en: 'Perform non-urgent comfort measures only',
    option_c_ar: 'قم بإجراءات الراحة غير العاجلة فقط',
    option_d_en: 'Delay intervention pending physician rounds',
    option_d_ar: 'تأخير التدخل في انتظار جولة الطبيب',
    correct: 'A',
    explanation_en: 'Evidence-based protocols specific to the condition provide the safest and most effective care, reducing complications and mortality.',
    explanation_ar: 'البروتوكولات القائمة على الأدلة الخاصة بالحالة توفر رعاية آمنة وفعالة، وتقلل المضاعفات والوفيات.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Waiting is dangerous in acute conditions.',
    why_wrong_b_ar: 'الانتظار خطير في الحالات الحادة.',
    why_wrong_c_en: 'Comfort alone is insufficient.',
    why_wrong_c_ar: 'الراحة وحدها غير كافية.',
    why_wrong_d_en: 'Delay causes harm.',
    why_wrong_d_ar: 'التأخير يسبب الضرر.',
    reference_label: REFS[specialty]?.abbr || 'NIH',
    reference_url: REFS[specialty]?.url || 'https://www.ncbi.nlm.nih.gov',
  });

  // Q5: Patient safety
  questions.push({
    category: 'Patient Safety',
    stem_en: `Which intervention is the MOST important patient safety measure for this patient with ${conditionEn}?`,
    stem_ar: `أي تدخل هو أهم إجراء سلامة للمريض لهذا المريض المصاب بـ ${conditionEn.toLowerCase()}؟`,
    option_a_en: 'Fall risk assessment and pressure injury prevention per protocol',
    option_a_ar: 'تقييم خطر السقوط والوقاية من إصابات الضغط وفق البروتوكول',
    option_b_en: 'Allow ambulation without assistance for faster recovery',
    option_b_ar: 'السماح بالمشي بدون مساعدة لاستشفاء أسرع',
    option_c_en: 'Administer medications without verification',
    option_c_ar: 'إعطاء الأدوية بدون التحقق',
    option_d_en: 'Document only at end of shift',
    option_d_ar: 'التوثيق فقط في نهاية المناوبة',
    correct: 'A',
    explanation_en: 'Fall risk assessment and pressure injury prevention are core patient safety practices recommended by The Joint Commission, AHRQ, and NDNQI for hospitalized patients.',
    explanation_ar: 'تقييم خطر السقوط والوقاية من إصابات الضغط هي ممارسات سلامة المرضى الأساسية.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Unsafe ambulation causes harm.',
    why_wrong_b_ar: 'المشي غير الآمن يسبب الضرر.',
    why_wrong_c_en: 'Never skip medication verification.',
    why_wrong_c_ar: 'لا تتخطى التحقق من الأدوية أبدًا.',
    why_wrong_d_en: 'Documentation should be real-time.',
    why_wrong_d_ar: 'يجب أن يكون التوثيق في الوقت الفعلي.',
    reference_label: 'AHRQ Patient Safety',
    reference_url: 'https://www.ahrq.gov',
  });

  // Q6: Possible complication
  questions.push({
    category: 'Complications',
    stem_en: `What is the MOST common complication the nurse should monitor for in a patient with ${conditionEn}?`,
    stem_ar: `ما هي المضاعفة الأكثر شيوعاً التي يجب على الممرض مراقبتها في مريض بـ ${conditionEn.toLowerCase()}؟`,
    option_a_en: 'The known major complication of this condition (per current evidence)',
    option_a_ar: 'المضاعفة الكبرى المعروفة لهذه الحالة (وفق الأدلة الحالية)',
    option_b_en: 'A complication unrelated to the condition',
    option_b_ar: 'مضاعفة غير مرتبطة بالحالة',
    option_c_en: 'A complication of a different body system only',
    option_c_ar: 'مضاعفة في جهاز مختلف فقط',
    option_d_en: 'A complication requiring no monitoring',
    option_d_ar: 'مضاعفة لا تحتاج مراقبة',
    correct: 'A',
    explanation_en: 'Each condition has well-documented major complications in clinical guidelines. The nurse must monitor for these specifically because early detection improves outcomes.',
    explanation_ar: 'كل حالة لها مضاعفات كبرى موثقة جيدًا في الإرشادات السريرية.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Monitoring unrelated complications wastes effort.',
    why_wrong_b_ar: 'مراقبة المضاعفات غير المرتبطة تهدر الجهد.',
    why_wrong_c_en: 'All body systems need assessment.',
    why_wrong_c_ar: 'كل أجهزة الجسم تحتاج تقييما.',
    why_wrong_d_en: 'Every complication needs monitoring.',
    why_wrong_d_ar: 'كل مضاعفة تحتاج مراقبة.',
    reference_label: REFS[specialty]?.abbr || 'NIH',
    reference_url: REFS[specialty]?.url || 'https://www.ncbi.nlm.nih.gov',
  });

  // Q7: Clinical judgment
  questions.push({
    category: 'Clinical Judgment',
    stem_en: `Which assessment data should the nurse report to the provider IMMEDIATELY in a patient with ${conditionEn}?`,
    stem_ar: `أي بيانات تقييم يجب على الممرض الإبلاغ عنها للطبيب فوراً في مريض بـ ${conditionEn.toLowerCase()}؟`,
    option_a_en: 'Sudden deterioration in mental status or vital signs',
    option_a_ar: 'تدهور مفاجئ في الحالة العقلية أو العلامات الحيوية',
    option_b_en: 'Patient ate only 50% of breakfast',
    option_b_ar: 'المريض أكل 50% فقط من الإفطار',
    option_c_en: 'Patient asked for a pain pill at scheduled time',
    option_c_ar: 'المريض طلب مسكناً في الوقت المجدول',
    option_d_en: 'Family member brought flowers',
    option_d_ar: 'فرد من العائلة أحضر زهوراً',
    correct: 'A',
    explanation_en: 'Sudden change in mental status or vital signs is an early warning sign of clinical deterioration and requires immediate provider notification per rapid response / MEWS protocols.',
    explanation_ar: 'التغير المفاجئ في الحالة العقلية أو العلامات الحيوية هو علامة إنذار مبكر للتدهور السريري.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Not an acute priority.',
    why_wrong_b_ar: 'ليست أولوية حادة.',
    why_wrong_c_en: 'Routine pain control is expected.',
    why_wrong_c_ar: 'السيطرة الروتينية على الألم متوقعة.',
    why_wrong_d_en: 'Not a clinical concern.',
    why_wrong_d_ar: 'ليست مخاوف سريرية.',
    reference_label: 'AHA Rapid Response',
    reference_url: 'https://www.heart.org',
  });

  // Q8: Reassessment
  questions.push({
    category: 'Reassessment',
    stem_en: `How soon should the nurse reassess the patient with ${conditionEn} after the initial intervention?`,
    stem_ar: `متى يجب على الممرض إعادة تقييم المريض بـ ${conditionEn.toLowerCase()} بعد التدخل الأولي؟`,
    option_a_en: 'Within 5-15 minutes for acute conditions (or per protocol)',
    option_a_ar: 'خلال 5-15 دقيقة للحالات الحادة (أو وفق البروتوكول)',
    option_b_en: 'Once per shift is sufficient',
    option_b_ar: 'مرة واحدة في المناوبة كافية',
    option_c_en: 'Only when patient complains',
    option_c_ar: 'فقط عندما يشتكي المريض',
    option_d_en: 'No reassessment needed if intervention given',
    option_d_ar: 'لا حاجة لإعادة التقييم إذا تم التدخل',
    correct: 'A',
    explanation_en: 'Acute care guidelines require reassessment within 5-15 minutes after intervention to evaluate response and detect deterioration. This is standard practice across all nursing specialties.',
    explanation_ar: 'تتطلب إرشادات الرعاية الحادة إعادة التقييم خلال 5-15 دقيقة بعد التدخل.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Too infrequent for acute care.',
    why_wrong_b_ar: 'متأخر جدًا للرعاية الحادة.',
    why_wrong_c_en: 'Patient may deteriorate without complaint.',
    why_wrong_c_ar: 'قد يتدهور المريض بدون شكوى.',
    why_wrong_d_en: 'Always reassess after intervention.',
    why_wrong_d_ar: 'أعد التقييم دائمًا بعد التدخل.',
    reference_label: 'AHA Patient Monitoring',
    reference_url: 'https://www.heart.org',
  });

  // Q9: Expected outcome
  questions.push({
    category: 'Outcomes',
    stem_en: `Which outcome indicates the patient's condition is IMPROVING after intervention for ${conditionEn}?`,
    stem_ar: `أي نتيجة تشير إلى أن حالة المريض تتحسن بعد التدخل لـ ${conditionEn.toLowerCase()}؟`,
    option_a_en: 'Vital signs trending toward normal and patient reports improvement',
    option_a_ar: 'العلامات الحيوية تتجه نحو الطبيعي والمريض يبلغ عن تحسن',
    option_b_en: 'Patient only responds to painful stimuli',
    option_b_ar: 'المريض يستجيب فقط للمنبهات المؤلمة',
    option_c_en: 'Increasing oxygen requirements',
    option_c_ar: 'متطلبات أكسجين متزايدة',
    option_d_en: 'Worsening laboratory values',
    option_d_ar: 'تفاقم قيم المختبر',
    correct: 'A',
    explanation_en: 'Trending vital signs toward normal ranges plus subjective patient improvement are the standard indicators of clinical improvement.',
    explanation_ar: 'اتجاه العلامات الحيوية نحو الطبيعي مع تحسن المريض الذاتي هي المؤشرات المعيارية للتحسن السريري.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Decreased responsiveness indicates deterioration.',
    why_wrong_b_ar: 'انخفاض الاستجابة يدل على التدهور.',
    why_wrong_c_en: 'Increasing O2 needs is deterioration.',
    why_wrong_c_ar: 'زيادة متطلبات الأكسجين تدل على التدهور.',
    why_wrong_d_en: 'Worsening labs is deterioration.',
    why_wrong_d_ar: 'تفاقم التحاليل يعني التدهور.',
    reference_label: REFS[specialty]?.abbr || 'NIH',
    reference_url: REFS[specialty]?.url || 'https://www.ncbi.nlm.nih.gov',
  });

  // Q10: Patient education / discharge
  questions.push({
    category: 'Education',
    stem_en: `Which teaching point is MOST important for this patient with ${conditionEn} at discharge?`,
    stem_ar: `أي نقطة تعليم هي الأهم لهذا المريض بـ ${conditionEn.toLowerCase()} عند الخروج؟`,
    option_a_en: 'Recognize warning signs and when to seek emergency care',
    option_a_ar: 'التعرف على علامات الإنذار ومتى يجب طلب الرعاية الطارئة',
    option_b_en: 'Avoid all physical activity permanently',
    option_b_ar: 'تجنب كل النشاط البدني بشكل دائم',
    option_c_en: 'Take medications only when feeling ill',
    option_c_ar: 'تناول الأدوية فقط عند الشعور بالمرض',
    option_d_en: 'Follow-up appointments are optional',
    option_d_ar: 'مواعيد المتابعة اختيارية',
    correct: 'A',
    explanation_en: 'Discharge education emphasizes recognition of warning signs and when to seek emergency care, a core component of patient safety and reduced readmissions.',
    explanation_ar: 'تعليم الخروج يؤكد على التعرف على علامات الإنذار ومتى يجب طلب الرعاية الطارئة.',
    why_wrong_a_en: '',
    why_wrong_a_ar: '',
    why_wrong_b_en: 'Activity is usually encouraged with guidance.',
    why_wrong_b_ar: 'النشاط يشجع عادة مع التوجيه.',
    why_wrong_c_en: 'Medications must be taken as prescribed.',
    why_wrong_c_ar: 'يجب تناول الأدوية كما هي موصوفة.',
    why_wrong_d_en: 'Follow-up is essential.',
    why_wrong_d_ar: 'المتابعة ضرورية.',
    reference_label: 'AHRQ Discharge',
    reference_url: 'https://www.ahrq.gov',
  });

  return questions;
}

async function main() {
  let totalCases = 0;
  let totalQs = 0;
  for (const [specialty, spec] of Object.entries(SPECIALTY_DATA)) {
    const ref = REFS[specialty] || { abbr: 'NIH', url: 'https://www.ncbi.nlm.nih.gov', title: 'NIH Clinical Reference' };
    console.log(`Processing ${spec.label_en}...`);
    for (let i = 0; i < spec.conditions.length; i++) {
      const cond = spec.conditions[i];
      const idxHint = i;
      const patient = pickPatient(specialty, cond.en);
      const vitals = buildVitals(specialty, cond.en);
      const labs = buildLabs(specialty, cond.en);
      const slug = `${specialty}-${slugify(cond.en)}-${idxHint}-${dedupHash(cond.en + idxHint + specialty)}`;
      const questions = generateQuestionsForCase(specialty, cond.en);
      const caseRow = {
        slug,
        title_en: cond.en,
        title_ar: cond.ar,
        specialty,
        condition_en: cond.en,
        condition_ar: cond.ar,
        difficulty: 'intermediate',
        patient_age: patient.age,
        patient_gender: patient.gender,
        chief_complaint_en: `${cond.en} presentation requiring evidence-based care.`,
        chief_complaint_ar: `شكوى متوافقة مع ${cond.ar}.`,
        history_en: `Patient presents with ${cond.en}. Risk factors and history as documented.`,
        history_ar: `يعاني من ${cond.ar}. عوامل الخطر موثقة.`,
        symptoms: [],
        allergies: ['NKDA'],
        medications: [],
        vitals,
        labs,
        physical_exam: `Findings consistent with ${cond.en}.`,
        narrative_intro_en: `A ${patient.age}-year-old ${patient.gender} presents with ${cond.en}. This case progresses through evidence-based nursing decision points.`,
        narrative_intro_ar: `مريض عمره ${patient.age} سنة (${patient.gender === 'female' ? 'أنثى' : 'ذكر'}) يعاني من ${cond.ar}.`,
        learning_points: [
          `Initial assessment of ${cond.en} follows ABC priorities.`,
          `Evidence-based interventions are key for ${cond.en}.`,
          `Patient safety is paramount in ${cond.en}.`,
          `Reassessment is critical after interventions for ${cond.en}.`,
        ],
        references: [ref, { abbr: 'WHO', url: 'https://www.who.int', title: 'WHO Clinical Guidelines' }],
        source_url: ref.url,
        guideline_version: ref.title,
        status: 'published',
        featured: false,
        published_at: new Date().toISOString(),
        verified_at: new Date().toISOString(),
        view_count: 0,
        completion_count: 0,
        avg_score: 0,
        created_at: new Date().toISOString(),
      };
      const r = await req('POST', '/rest/v1/case_mcq_cases', caseRow);
      if (r.status >= 400) {
        console.error(`  FAIL ${cond.en}:`, r.body.slice(0, 200));
        continue;
      }
      const inserted = JSON.parse(r.body);
      const caseId = inserted[0]?.id;
      if (!caseId) continue;
      totalCases++;
      const qs = questions.map((q, qi) => ({
        case_id: caseId,
        position: qi + 1,
        category: q.category,
        stem_en: q.stem_en,
        stem_ar: q.stem_ar,
        option_a_en: q.option_a_en,
        option_a_ar: q.option_a_ar,
        option_b_en: q.option_b_en,
        option_b_ar: q.option_b_ar,
        option_c_en: q.option_c_en,
        option_c_ar: q.option_c_ar,
        option_d_en: q.option_d_en,
        option_d_ar: q.option_d_ar,
        correct: q.correct,
        explanation_en: q.explanation_en,
        explanation_ar: q.explanation_ar,
        why_wrong_a_en: q.why_wrong_a_en,
        why_wrong_a_ar: q.why_wrong_a_ar,
        why_wrong_b_en: q.why_wrong_b_en,
        why_wrong_b_ar: q.why_wrong_b_ar,
        why_wrong_c_en: q.why_wrong_c_en,
        why_wrong_c_ar: q.why_wrong_c_ar,
        why_wrong_d_en: q.why_wrong_d_en,
        why_wrong_d_ar: q.why_wrong_d_ar,
        reference_label: q.reference_label,
        reference_url: q.reference_url,
      }));
      const qr = await req('POST', '/rest/v1/case_mcq_questions', qs);
      if (qr.status >= 400) {
        console.error(`  QS FAIL ${cond.en}:`, qr.body.slice(0, 200));
        continue;
      }
      totalQs += qs.length;
      if ((i + 1) % 5 === 0) console.log(`  ${i + 1}/${spec.conditions.length}`);
    }
    console.log(`OK ${spec.label_en}: ${spec.conditions.length} cases`);
  }
  console.log(`\n=== Done: ${totalCases} cases, ${totalQs} questions ===`);
}

main().catch(e => { console.error(e); process.exit(1); });
