import { readFileSync } from 'node:fs';
import https from 'node:https';
const env = readFileSync('.env', 'utf8');
const get = (k) => { const m = env.match(new RegExp('^' + k + '=(.*)$', 'm')); return m ? m[1].trim().replace(/^["']|["']$/g, '') : undefined; };
const SUPA_URL = get('NEXT_PUBLIC_SUPABASE_URL').replace(/\/$/, '');
const KEY = get('SUPABASE_SERVICE_ROLE_KEY');
console.log('URL:', SUPA_URL);
console.log('KEY len:', KEY.length);

const path = '/rest/v1/case_mcq_cases?select=id,slug,condition_en,patient_age,patient_gender,reference_url,reference_label&status=eq.published&order=id&limit=2';
const url = new URL(path, SUPA_URL);
console.log('Full URL:', url.toString());

await new Promise((resolve, reject) => {
  const r = https.request({ method: 'GET', hostname: url.hostname, path: url.pathname + url.search, headers: { apikey: KEY, Authorization: 'Bearer ' + KEY } }, (res) => {
    let c = ''; res.on('data', (d) => c += d); res.on('end', () => { console.log('Status:', res.statusCode); console.log('Body:', c.slice(0, 200)); resolve(); });
  });
  r.on('error', reject); r.end();
});
