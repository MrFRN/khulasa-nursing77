import { readFileSync } from 'node:fs';
import https from 'node:https';
const env = readFileSync('.env', 'utf8');
const get = (k) => { const m = env.match(new RegExp('^' + k + '=(.*)$', 'm')); return m ? m[1].trim().replace(/^["']|["']$/g, '') : undefined; };
const SUPA_URL = get('NEXT_PUBLIC_SUPABASE_URL').replace(/\/$/, '');
const KEY = get('SUPABASE_SERVICE_ROLE_KEY');
const path = '/rest/v1/case_mcq_cases?select=*&limit=1';
const url = new URL(path, SUPA_URL);
await new Promise((resolve, reject) => {
  const r = https.request({ method: 'GET', hostname: url.hostname, path: url.pathname + url.search, headers: { apikey: KEY, Authorization: 'Bearer ' + KEY } }, (res) => {
    let c = ''; res.on('data', (d) => c += d); res.on('end', () => { 
      const j = JSON.parse(c);
      if (j[0]) console.log('Cols:', Object.keys(j[0]).join(', '));
      else console.log('Empty:', c.slice(0, 200));
      resolve(); 
    });
  });
  r.on('error', reject); r.end();
});
